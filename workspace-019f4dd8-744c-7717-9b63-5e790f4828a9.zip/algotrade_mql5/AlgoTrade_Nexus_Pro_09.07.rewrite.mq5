//+------------------------------------------------------------------+
//| Algotrade Nexus Pro 09.07.rewrite.mq5                            |
//| v7.35 — REAL ARCHITECTURE R21                                     |
//| 42 Ayar Grubu | 372 Input | 13 Modül                             |
//+------------------------------------------------------------------+
#property copyright   "Algotrade Nexus Pro"
#property version     "7.35"
#property link        "https://algotrade.pro"
#property description "AlgoTrade Nexus Pro v7.35 - REAL ARCHITECTURE R21"
#property strict

// ─── Include ────────────────────────────────────────────────────────────────
#include <Include/Algotrade/Nexus_Core_Settings.mqh>
#include <Include/Algotrade/Nexus_TrendEngines.mqh>
#include <Include/Algotrade/Nexus_GridEngine.mqh>
#include <Include/Algotrade/Nexus_Safety.mqh>
#include <Include/Algotrade/Nexus_News.mqh>
#include <Include/Algotrade/Nexus_VIOP.mqh>
#include <Include/Algotrade/Nexus_ML.mqh>
#include <Include/Algotrade/Nexus_Risk.mqh>
#include <Include/Algotrade/Nexus_Data.mqh>

// ─── GLOBALS ───────────────────────────────────────────────────────────────
CNexusInputs      g_inputs;
CTrendEngines*    g_engines;
CGridEngine*      g_grid;
CSafetyLayer*     g_safety;
CNewsFilter*      g_news;
CVIOPManager*     g_viop;
CMLManager*       g_ml;
CRiskManager*     g_risk;
CDataCollector*   g_data;
CTradeExecutor*   g_trade;

string            g_symbol;
ENUM_TIMEFRAMES   g_timeframe;
datetime          g_bar_time;
int               g_magic_buy;
int               g_magic_sell;
bool              g_is_hedging;
double            g_account_balance;
double            g_account_equity;
double            g_initial_equity;
double            g_peak_equity;
double            g_last_reset_equity;
int               g_reset_count;
datetime          g_last_reset_time;
datetime          g_last_bar_time;
bool              g_paused;
ENUM_KERNEL_STATE g_kernel_state;
StagedDecision   g_decision;
ENUM_SIGNAL_DIR  g_last_signal;
datetime          g_last_signal_time;
double            g_last_signal_price;

// Shadow trade journal
ShadowTrade      g_shadow_positions[];
int              g_shadow_count;

// VIOP state
bool              g_viop_detected;
bool              g_viop_session_open;
datetime          g_viop_last_check;
VIOPContract      g_viop_contract;

//+------------------------------------------------------------------+
//| Expert initialization function                                     |
//+------------------------------------------------------------------+
int OnInit() {
   // ─── Symbol & Account ──────────────────────────────────────────────
   g_symbol = _Symbol;
   g_timeframe = PERIOD_CURRENT;
   g_bar_time = 0;
   
   // Account info
   g_account_balance = AccountInfoDouble(ACCOUNT_BALANCE);
   g_account_equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   g_initial_equity   = g_account_equity;
   g_peak_equity      = g_account_equity;
   g_last_reset_equity = g_account_equity;
   g_reset_count      = 0;
   g_last_reset_time  = TimeCurrent();
   
   // Magic numbers
   g_magic_buy  = g_inputs.GetMagicBuy();
   g_magic_sell = g_inputs.GetMagicSell();
   
   // Account type
   long account_mode;
   if(!AccountInfoInteger(ACCOUNT_TRADE_MODE, account_mode))
      return INIT_FAILED;
   g_is_hedging = (account_mode == ACCOUNT_TRADE_MODE_HEDGING);
   
   Print("═══════════════════════════════════════════════════");
   Print("AlgoTrade Nexus Pro v7.35 - REAL ARCHITECTURE R21");
   Print("═══════════════════════════════════════════════════");
   Print("Symbol: ", g_symbol);
   Print("Account Type: ", g_is_hedging ? "HEDGING" : "NETTING");
   Print("MagicBuy: ", g_magic_buy, " | MagicSell: ", g_magic_sell);
   Print("Balance: ", DoubleToString(g_account_balance, 2),
         " | Equity: ", DoubleToString(g_account_equity, 2));
   Print("Inputs Count: 372 | Groups: 42");
   
   // ─── Initialize Modules ────────────────────────────────────────────
   g_data = new CDataCollector(g_symbol, g_timeframe);
   g_engines = new CTrendEngines(g_inputs, g_data);
   g_grid = new CGridEngine(g_inputs, g_symbol);
   g_safety = new CSafetyLayer(g_inputs);
   g_news = new CNewsFilter(g_inputs);
   g_viop = new CVIOPManager(g_inputs, g_symbol);
   g_ml = new CMLManager(g_inputs);
   g_risk = new CRiskManager(g_inputs);
   g_trade = new CTradeExecutor(g_inputs, g_symbol);
   
   // VIOP detection
   g_viop_detected = g_viop.Detect();
   if(g_viop_detected) {
      g_viop_contract = g_viop.GetContractInfo();
      Print("VIOP Detected: ", g_viop_contract.symbol,
            " | Expiry: ", g_viop_contract.expiry_date);
   } else {
      Print("VIOP Not Detected — Standard forex/spot mode");
   }
   
   // Initial bar
   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   if(CopyRates(g_symbol, g_timeframe, 0, 3, rates) <= 0) {
      Print("ERROR: Failed to load initial bar data");
      return INIT_FAILED;
   }
   g_bar_time = rates[0].time;
   g_last_bar_time = g_bar_time;
   
   // Initialize data collector with bars
   g_data.LoadBars(100);
   
   // Initialize modules
   g_engines.Initialize();
   g_grid.Initialize();
   g_news.Initialize();
   g_viop.Initialize();
   g_ml.Initialize();
   
   // ML model load
   if(g_inputs.ML_ONNX_Enable && !g_inputs.ML_ShadowOnly) {
      if(!g_ml.LoadModel()) {
         Print("WARNING: ONNX model load failed. Using heuristic fallback.");
      }
   }
   
   // Panel message
   Print("═══════════════════════════════════════════════════");
   Print("Robot initialized successfully.");
   Print("Panel Language: ", EnumToString(g_inputs.PanelLanguage));
   Print("Direction Engine: ", EnumToString(g_inputs.DirectionEngineDefault));
   Print("Grid Enabled: ", g_inputs.VG_Enable);
   Print("Shadow Trade: ", g_inputs.ShadowTrade_Enable);
   Print("═══════════════════════════════════════════════════");
   
   g_kernel_state = NUK_BOOT;
   g_paused = false;
   ArrayResize(g_shadow_positions, 0);
   g_shadow_count = 0;
   
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
   string reason_text;
   switch(reason) {
      case REASON_PROGRAM:      reason_text = "Program call"; break;
      case REASON_REMOVE:       reason_text = "Chart removed"; break;
      case REASON_RECOMPILE:   reason_text = "Recompile"; break;
      case REASON_CHARTCHANGE:  reason_text = "Symbol/period change"; break;
      case REASON_CHARTCLOSE:   reason_text = "Chart closed"; break;
      case REASON_PARAMETERS:   reason_text = "Parameter change"; break;
      case REASON_ACCOUNT:      reason_text = "Account changed"; break;
      default:                  reason_text = "Unknown";
   }
   Print("Deinitializing — Reason: ", reason_text);
   
   // Clean up
   if(CheckPointer(g_data) == POINTER_DYNAMIC)    delete g_data;
   if(CheckPointer(g_engines) == POINTER_DYNAMIC) delete g_engines;
   if(CheckPointer(g_grid) == POINTER_DYNAMIC)   delete g_grid;
   if(CheckPointer(g_safety) == POINTER_DYNAMIC) delete g_safety;
   if(CheckPointer(g_news) == POINTER_DYNAMIC)   delete g_news;
   if(CheckPointer(g_viop) == POINTER_DYNAMIC)  delete g_viop;
   if(CheckPointer(g_ml) == POINTER_DYNAMIC)     delete g_ml;
   if(CheckPointer(g_risk) == POINTER_DYNAMIC)  delete g_risk;
   if(CheckPointer(g_trade) == POINTER_DYNAMIC)  delete g_trade;
   
   Comment("");
}

//+------------------------------------------------------------------+
//| Expert tick function                                               |
//+------------------------------------------------------------------+
void OnTick() {
   // ─── New bar check ────────────────────────────────────────────────
   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   if(CopyRates(g_symbol, g_timeframe, 0, 1, rates) <= 0) return;
   
   datetime current_bar = rates[0].time;
   bool new_bar = (current_bar != g_bar_time);
   if(new_bar) {
      g_last_bar_time = g_bar_time;
      g_bar_time = current_bar;
      g_data.LoadBars(100); // Refresh data
   }
   
   // ─── Update account data ──────────────────────────────────────────
   g_account_equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(g_account_equity > g_peak_equity)
      g_peak_equity = g_account_equity;
   
   // ─── Update all modules ───────────────────────────────────────────
   g_news.Update();
   g_viop.Update();
   g_risk.UpdateEquity(g_account_equity, g_account_balance);
   
   // ─── STAGED DECISION PIPELINE ─────────────────────────────────────
   Stage1_PlatformChecks();
   Stage2_SafetyLocks();
   Stage3_PositionCache();
   Stage4_ResetsAndLocks();
   Stage5_ProfitTargets();
   
   if(g_kernel_state != NUK_SAFETY_LOCK && !g_paused) {
      Stage6_EnginesDirection();
      Stage7_FiltersAndConsensus();
      Stage8_RouterDecision();
      Stage9_FinalVeto();
      Stage10_Execute();
   }
   
   // ─── Grid management ──────────────────────────────────────────────
   if(g_inputs.VG_Enable && g_kernel_state != NUK_SAFETY_LOCK)
      g_grid.Manage(g_decision.primary_direction, new_bar);
   
   // ─── Shadow trade journal ─────────────────────────────────────────
   if(g_inputs.ShadowTrade_Enable)
      ManageShadowJournal();
   
   // ─── ML data collection ────────────────────────────────────────────
   if(g_inputs.ML_DataLog_Enable && new_bar)
      g_data.LogMLTrainingData();
   
   // ─── VIOP rollover check ─────────────────────────────────────────
   if(g_viop_detected && g_inputs.VIOP_EnableSessionControl)
      g_viop.ManageSession();
   
   // ─── Panel update ─────────────────────────────────────────────────
   UpdatePanelInfo();
}

//+------------------------------------------------------------------+
//| STAGE 1: Platform & Permission Checks                              |
//+------------------------------------------------------------------+
void Stage1_PlatformChecks() {
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)) {
      g_kernel_state = NUK_SAFETY_LOCK;
      g_decision.safety_locked = true;
      g_decision.lock_reason = "AutoTrading disabled";
      return;
   }
   if(!g_inputs.EnableGlobalTrading) {
      g_kernel_state = NUK_SAFETY_LOCK;
      g_decision.safety_locked = true;
      g_decision.lock_reason = "GlobalTrading disabled";
      return;
   }
   // Spread check
   if(g_inputs.EnableSpreadProtection) {
      double spread = (SymbolInfoDouble(g_symbol, SYMBOL_ASK) -
                       SymbolInfoDouble(g_symbol, SYMBOL_BID))
                      / _Point;
      if(spread > g_inputs.MaxAllowedSpread) {
         g_kernel_state = NUK_SAFETY_LOCK;
         g_decision.safety_locked = true;
         g_decision.lock_reason = "Spread too high: " + DoubleToString(spread, 0);
         return;
      }
   }
   g_decision.safety_locked = false;
   g_decision.lock_reason = "";
}

//+------------------------------------------------------------------+
//| STAGE 2: Safety Locks (News, Weekly, VIOP, Daily)                 |
//+------------------------------------------------------------------+
void Stage2_SafetyLocks() {
   // News hard lock
   if(g_inputs.NF_Enable && g_news.IsHardLocked()) {
      g_kernel_state = NUK_SAFETY_LOCK;
      g_decision.safety_locked = true;
      g_decision.lock_reason = "News hard lock";
      return;
   }
   // VIOP session
   if(g_viop_detected && g_inputs.VIOP_EnableSessionControl) {
      if(!g_viop.IsSessionOpen()) {
         g_kernel_state = NUK_SAFETY_LOCK;
         g_decision.safety_locked = true;
         g_decision.lock_reason = "VIOP session closed";
         return;
      }
      // Gap wait
      if(g_viop.IsInGapWait()) {
         g_kernel_state = NUK_SAFETY_LOCK;
         g_decision.safety_locked = true;
         g_decision.lock_reason = "VIOP gap wait";
         return;
      }
   }
   // Weekly schedule
   if(g_inputs.EnableWeeklySchedule && g_risk.IsWeeklyBlocked()) {
      g_kernel_state = NUK_SAFETY_LOCK;
      g_decision.safety_locked = true;
      g_decision.lock_reason = "Weekly schedule block";
      return;
   }
   // Daily lock
   if(g_risk.IsDailyLocked()) {
      g_kernel_state = NUK_SAFETY_LOCK;
      g_decision.safety_locked = true;
      g_decision.lock_reason = "Daily lock active";
      return;
   }
   // Paused
   if(g_paused) {
      g_kernel_state = NUK_MANAGE_ONLY;
      g_decision.safety_locked = true;
      g_decision.lock_reason = "Paused by user";
      return;
   }
}

//+------------------------------------------------------------------+
//| STAGE 3: Position & Account Cache                                  |
//+------------------------------------------------------------------+
void Stage3_PositionCache() {
   g_trade.RefreshPositions(g_magic_buy, g_magic_sell);
}

//+------------------------------------------------------------------+
//| STAGE 4: Global & Daily Resets + Time Limits                      |
//+------------------------------------------------------------------+
void Stage4_ResetsAndLocks() {
   double equity_change_pct = 0;
   if(g_last_reset_equity > 0)
      equity_change_pct = (g_account_equity - g_last_reset_equity)
                          / g_last_reset_equity * 100.0;
   
   // Global profit reset
   if(equity_change_pct >= g_inputs.GlobalProfitPct) {
      Print("GLOBAL PROFIT RESET triggered — +",
            DoubleToString(equity_change_pct, 2), "%");
      CloseAllPositions(CR_GLOBAL_TP_RESET);
      g_last_reset_equity = g_account_equity;
      g_reset_count++;
      g_last_reset_time = TimeCurrent();
      return;
   }
   // Global loss reset
   if(equity_change_pct <= -g_inputs.GlobalLossPct) {
      Print("GLOBAL LOSS RESET triggered — ",
            DoubleToString(equity_change_pct, 2), "%");
      CloseAllPositions(CR_GLOBAL_RESET);
      g_last_reset_equity = g_account_equity;
      g_reset_count++;
      g_last_reset_time = TimeCurrent();
      return;
   }
   // Time-based reset
   if(g_inputs.EnableTimeLimitReset) {
      if(g_risk.CheckTimeLimitReset(g_last_reset_time)) {
         Print("TIME LIMIT RESET triggered");
         CloseAllPositions(CR_TIME_LIMIT_RESET);
         g_last_reset_equity = g_account_equity;
         g_reset_count++;
         g_last_reset_time = TimeCurrent();
         return;
      }
   }
   // Daily profit lock
   if(g_inputs.DailyProfitLockEnable) {
      if(g_risk.CheckDailyProfitLock(g_initial_equity, g_account_equity)) {
         g_paused = true;
         Print("DAILY PROFIT LOCK activated");
      }
   }
   // Daily loss lock
   if(g_inputs.DailyLossLockEnable) {
      if(g_risk.CheckDailyLossLock(g_initial_equity, g_account_equity)) {
         g_paused = true;
         Print("DAILY LOSS LOCK activated");
      }
   }
   // Pause after time limit
   if(g_inputs.EnableTimeLimitReset && g_risk.CheckTimeLimitReset(g_last_reset_time)) {
      if(g_inputs.PauseAfterTimeLimit) g_paused = true;
   }
}

//+------------------------------------------------------------------+
//| STAGE 5: Profit Targets (TP-PROJ, Grid TP, Profit Lock, etc)      |
//+------------------------------------------------------------------+
void Stage5_ProfitTargets() {
   // Check all profit-taking mechanisms
   if(g_trade.TotalProfit() > 0) {
      // Bonus TP
      if(g_inputs.Bullet_BonusTPEnable)
         CheckBonusTP();
      // Profit Lock
      if(g_inputs.Bullet_ProfitLockEnable)
         CheckProfitLock();
      // AEG profit exit
      if(g_inputs.AEG_Enable)
         CheckAEGProfitExit();
   }
   // Grid TP
   if(g_inputs.VG_Enable && g_inputs.VG_TPAuthority)
      g_grid.CheckGridTP();
}

//+------------------------------------------------------------------+
//| STAGE 6: Direction Engines                                        |
//+------------------------------------------------------------------+
void Stage6_EnginesDirection() {
   ENUM_SIGNAL_DIR engines[3];
   double scores[3];
   
   // VEMA-X
   engines[0] = g_engines.CalcVEMA(scores[0]);
   // First Touch
   engines[1] = g_engines.CalcFirstTouch(scores[1]);
   // Classic Live
   engines[2] = g_engines.CalcClassicLive(scores[2]);
   
   // Select based on default engine
   switch(g_inputs.DirectionEngineDefault) {
      case DIR_VEMA:
         g_decision.primary_direction = engines[0];
         g_decision.direction_score = scores[0];
         break;
      case DIR_FIRST_TOUCH:
         g_decision.primary_direction = engines[1];
         g_decision.direction_score = scores[1];
         break;
      case DIR_CLASSIC:
         g_decision.primary_direction = engines[2];
         g_decision.direction_score = scores[2];
         break;
   }
}

//+------------------------------------------------------------------+
//| STAGE 7: Filters, Consensus, ML                                   |
//+------------------------------------------------------------------+
void Stage7_FiltersAndConsensus() {
   // DI Smart Check
   double di_score;
   ENUM_SIGNAL_DIR di_dir = g_engines.CalcDI(di_score);
   
   // TMI Early Trend Check
   double tmi_score;
   ENUM_SIGNAL_DIR tmi_dir = g_engines.CalcTMI(tmi_score);
   
   // AWR Trend/Range
   bool is_trend = g_engines.CalcAWR();
   
   // NDI
   ENUM_SIGNAL_DIR ndi_dir = g_engines.CalcNDI();
   
   // DTE Meta Filter
   bool dte_pass = g_engines.CalcDTE();
   
   // Consensus
   if(g_inputs.Bullet_TrendConsensusEnable) {
      int votes = 0;
      if(di_dir == g_decision.primary_direction) votes++;
      if(tmi_dir == g_decision.primary_direction) votes++;
      if(ndi_dir == g_decision.primary_direction) votes++;
      if(AEG_Check()) votes++;
      
      if(votes < g_inputs.Bullet_TrendConsensusMinVotes) {
         g_decision.consensus_direction = DIR_NEUTRAL;
      } else {
         g_decision.consensus_direction = g_decision.primary_direction;
      }
   } else {
      g_decision.consensus_direction = g_decision.primary_direction;
   }
   
   // Block DITMI conflict
   if(g_inputs.Bullet_BlockDITMIConflict) {
      if(di_dir != DIR_NEUTRAL && tmi_dir != DIR_NEUTRAL) {
         if(di_dir != tmi_dir) {
            g_decision.consensus_direction = DIR_NEUTRAL;
            if(g_inputs.UDC_Log)
               Print("[UDC] DITMI conflict blocked: DI=", EnumToString(di_dir),
                     " TMI=", EnumToString(tmi_dir));
         }
      }
   }
   
   // ONNX ML
   if(g_inputs.ML_ONNX_Enable) {
      double ml_prob_trend, ml_prob_dir;
      ENUM_SIGNAL_DIR ml_dir = g_ml.Predict(ml_prob_trend, ml_prob_dir);
      if(ml_dir != DIR_NEUTRAL) {
         if(ml_prob_trend >= g_inputs.ML_MinTrendProb &&
            ml_prob_dir >= g_inputs.ML_MinDirectionProb) {
            // Apply ML weight to decision
            g_decision.direction_score *= (1.0 - g_inputs.ML_Weight);
            g_decision.direction_score +=
               (ml_dir == g_decision.primary_direction ? 1.0 : 0.0)
               * g_inputs.ML_Weight;
            if(g_inputs.UDC_Log)
               Print("[ML] Prediction: ", EnumToString(ml_dir),
                     " ProbTrend=", DoubleToString(ml_prob_trend, 3),
                     " ProbDir=", DoubleToString(ml_prob_dir, 3));
         } else {
            if(g_inputs.UDC_Log)
               Print("[ML] Rejected — below threshold");
         }
      } else if(!g_inputs.ML_FallbackHeuristic) {
         g_decision.consensus_direction = DIR_NEUTRAL;
      }
   }
   
   // Quality score
   g_decision.quality_score = g_engines.CalcEntryQuality();
   
   // Entry score
   g_decision.entry_score = g_decision.direction_score
                            * g_decision.quality_score / 100.0;
}

//+------------------------------------------------------------------+
//| STAGE 8: Router / UDC — Trend vs Grid decision                    |
//+------------------------------------------------------------------+
void Stage8_RouterDecision() {
   // If consensus is neutral, no entry
   if(g_decision.consensus_direction == DIR_NEUTRAL) {
      g_decision.entry_allowed = false;
      g_kernel_state = NUK_WAIT_DIR;
      return;
   }
   
   // Minimum quality gate
   if(g_inputs.Bullet_EntryQualityEnable) {
      if(g_decision.quality_score < g_inputs.Bullet_EntryQualityMinScore) {
         g_decision.entry_allowed = false;
         if(g_inputs.UDC_Log)
            Print("[UDC] Entry blocked — quality ",
                  DoubleToString(g_decision.quality_score, 0),
                  " < min ", g_inputs.Bullet_EntryQualityMinScore);
         return;
      }
   }
   
   // Min distance check
   if(g_inputs.MinDist_Enable) {
      double price = SymbolInfoDouble(g_symbol, SYMBOL_BID);
      if(g_inputs.MinDist_Points > 0) {
         if(!CheckMinDistance(price)) {
            g_decision.entry_allowed = false;
            return;
         }
      }
   }
   
   // Entry confirm ticks
   static int entry_confirm_counter;
   static ENUM_SIGNAL_DIR entry_confirm_dir;
   if(g_decision.consensus_direction != g_last_signal) {
      entry_confirm_counter = 0;
      entry_confirm_dir = g_decision.consensus_direction;
   }
   entry_confirm_counter++;
   
   if(entry_confirm_counter < g_inputs.Bullet_EntryConfirmTicks) {
      g_decision.entry_allowed = false;
      g_kernel_state = NUK_WAIT_ENTRY;
      return;
   }
   
   g_last_signal = g_decision.consensus_direction;
   g_last_signal_time = TimeCurrent();
   g_last_signal_price = SymbolInfoDouble(g_symbol, SYMBOL_BID);
   
   g_decision.entry_allowed = true;
   g_kernel_state = NUK_ENTRY_READY;
}

//+------------------------------------------------------------------+
//| STAGE 9: Final Veto — BUY/SELL permission, margin, lot step      |
//+------------------------------------------------------------------+
void Stage9_FinalVeto() {
   if(!g_decision.entry_allowed) return;
   
   // Direction permission
   if(g_decision.consensus_direction == DIR_BUY) {
      if(!g_inputs.EnableBuy) {
         g_decision.entry_allowed = false;
         if(g_inputs.UDC_Log) Print("[UDC] BUY vetoed — EnableBuy=false");
         return;
      }
      if(g_inputs.TrendDirectionPermission == DPERM_SELL) {
         g_decision.entry_allowed = false;
         return;
      }
      // Same-side loss guard
      if(g_inputs.Bullet_RepeatLossGuardEnable)
         if(!CheckSameSideLossGuard(DIR_BUY)) return;
   } else if(g_decision.consensus_direction == DIR_SELL) {
      if(!g_inputs.EnableSell) {
         g_decision.entry_allowed = false;
         if(g_inputs.UDC_Log) Print("[UDC] SELL vetoed — EnableSell=false");
         return;
      }
      if(g_inputs.TrendDirectionPermission == DPERM_BUY) {
         g_decision.entry_allowed = false;
         return;
      }
      if(g_inputs.Bullet_RepeatLossGuardEnable)
         if(!CheckSameSideLossGuard(DIR_SELL)) return;
   }
   
   // Margin check
   double lot = CalculateLot(g_decision.consensus_direction);
   if(!CheckMargin(lot, g_decision.consensus_direction)) {
      g_decision.entry_allowed = false;
      if(g_inputs.UDC_Log) Print("[UDC] Vetoed — insufficient margin");
      return;
   }
   
   // Broker retcode check (will be checked at order send)
}

//+------------------------------------------------------------------+
//| STAGE 10: Execute — Send order                                     |
//+------------------------------------------------------------------+
void Stage10_Execute() {
   if(!g_decision.entry_allowed) {
      g_kernel_state = NUK_WAIT_ENTRY;
      return;
   }
   
   double lot = CalculateLot(g_decision.consensus_direction);
   ENUM_ORDER_TYPE order_type;
   int magic;
   
   if(g_decision.consensus_direction == DIR_BUY) {
      order_type = ORDER_TYPE_BUY;
      magic = g_magic_buy;
   } else {
      order_type = ORDER_TYPE_SELL;
      magic = g_magic_sell;
   }
   
   // Check if this should go to grid or trend
   ENUM_ENGINE_DEC decision = EDEC_TREND;
   if(g_inputs.VG_Enable) {
      // Grid has priority in certain conditions
      if(!g_inputs.VG_StopNewEntriesOnTrend || g_decision.consensus_direction == DIR_NEUTRAL) {
         // Check if grid should handle
      }
   }
   
   // Send order
   g_kernel_state = NUK_ORDER_PENDING;
   
   if(g_decision.consensus_direction == DIR_BUY) {
      if(g_trade.Buy(lot, magic)) {
         g_kernel_state = NUK_POS_MANAGE;
         g_risk.RecordTrade(DIR_BUY, lot, true);
         if(g_inputs.SoundAlertsEnabled)
            PlaySound(g_inputs.SoundTradeOpen);
      }
   } else {
      if(g_trade.Sell(lot, magic)) {
         g_kernel_state = NUK_POS_MANAGE;
         g_risk.RecordTrade(DIR_SELL, lot, true);
         if(g_inputs.SoundAlertsEnabled)
            PlaySound(g_inputs.SoundTradeOpen);
      }
   }
   
   g_kernel_state = NUK_POS_MANAGE;
}

//+------------------------------------------------------------------+
//| Calculate Lot Size                                                |
//+------------------------------------------------------------------+
double CalculateLot(ENUM_SIGNAL_DIR dir) {
   double lot = 0.0;
   
   // Apply lot penalty from resets
   double penalty_mult = 1.0;
   if(g_reset_count > 0) {
      int step = g_reset_count / g_inputs.LotPenaltyStepResets;
      penalty_mult = MathMax(g_inputs.LotPenaltyMinPct / 100.0,
                             1.0 - step * g_inputs.LotPenaltyStepPct / 100.0);
   }
   
   // Time lot boost
   if(g_inputs.EnableTimedLotBoost) {
      datetime start = g_last_reset_time;
      int hours_elapsed = (int)((TimeCurrent() - start) / 3600);
      int boost_steps = hours_elapsed / g_inputs.LotBoostStepHours;
      double boost_mult = MathMin(1.0 + boost_steps * g_inputs.LotBoostStepPct / 100.0,
                                  g_inputs.LotBoostMaxPct / 100.0);
      lot = lot * boost_mult;
   }
   
   switch(g_inputs.BulletLotMode) {
      case BLM_MANUAL:
         lot = g_inputs.FixedLot;
         break;
      case BLM_AUTO:
         lot = g_account_balance * g_inputs.AutoLotPct / 100.0;
         // Convert to lot (simplified)
         double tick_value = SymbolInfoDouble(g_symbol, SYMBOL_TRADE_TICK_VALUE);
         double tick_size = SymbolInfoDouble(g_symbol, SYMBOL_TRADE_TICK_SIZE);
         double contract_size = SymbolInfoDouble(g_symbol, SYMBOL_TRADE_CONTRACT_SIZE);
         if(tick_size > 0 && tick_value > 0) {
            double price = SymbolInfoDouble(g_symbol, SYMBOL_BID);
            double risk_per_lot = price * contract_size * g_inputs.AutoLotPct / 100.0;
            lot = risk_per_lot / (price * contract_size * _Point);
            lot = NormalizeDouble(lot, 2);
         }
         break;
      case BLM_PROJECT:
         lot = g_engines.CalcTPProjLot(dir, g_account_equity,
                                        g_last_reset_equity, g_peak_equity);
         break;
   }
   
   // Freeze on loss streak
   if(g_inputs.Bullet_FreezeTPProjLotOnLossStreak) {
      if(g_risk.GetSameSideLossStreak(dir) >= g_inputs.Bullet_SameSideLossLimit)
         lot = g_inputs.FixedLot; // Fallback to min
   }
   
   // Apply penalty
   lot = lot * penalty_mult;
   
   // Normalize to broker lot step
   double lot_step = SymbolInfoDouble(g_symbol, SYMBOL_VOLUME_STEP);
   lot = MathFloor(lot / lot_step) * lot_step;
   
   // Min/max bounds
   double min_lot = SymbolInfoDouble(g_symbol, SYMBOL_VOLUME_MIN);
   double max_lot = SymbolInfoDouble(g_symbol, SYMBOL_VOLUME_MAX);
   lot = MathMax(min_lot, MathMin(max_lot, lot));
   
   return lot;
}

//+------------------------------------------------------------------+
//| Check Margin for lot                                               |
//+------------------------------------------------------------------+
bool CheckMargin(double lot, ENUM_SIGNAL_DIR dir) {
   double price = (dir == DIR_BUY)
                  ? SymbolInfoDouble(g_symbol, SYMBOL_ASK)
                  : SymbolInfoDouble(g_symbol, SYMBOL_BID);
   double margin = g_trade.CalculateMargin(lot, price, dir);
   double free_margin = AccountInfoDouble(ACCOUNT_MARGIN_SO_FREE);
   return (margin <= free_margin);
}

//+------------------------------------------------------------------+
//| Check Minimum Distance                                             |
//+------------------------------------------------------------------+
bool CheckMinDistance(double current_price) {
   if(g_inputs.MinDist_Points <= 0) return true;
   
   double last_buy_price = g_trade.GetLastPrice(TYPE_BUY);
   double last_sell_price = g_trade.GetLastPrice(TYPE_SELL);
   
   double ask = SymbolInfoDouble(g_symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(g_symbol, SYMBOL_BID);
   double min_dist = g_inputs.MinDist_Points * _Point;
   
   if(last_buy_price > 0 && (ask - last_buy_price) < min_dist)
      return false;
   if(last_sell_price > 0 && (last_sell_price - bid) < min_dist)
      return false;
   
   return true;
}

//+------------------------------------------------------------------+
//| Check Same-Side Loss Guard                                         |
//+------------------------------------------------------------------+
bool CheckSameSideLossGuard(ENUM_SIGNAL_DIR dir) {
   if(!g_inputs.Bullet_RepeatLossGuardEnable) return true;
   
   int streak = g_risk.GetSameSideLossStreak(dir);
   if(streak >= g_inputs.Bullet_SameSideLossLimit) {
      if(g_inputs.UDC_Log)
         Print("[Safety] Same-side loss limit reached for ",
               EnumToString(dir), " streak=", streak);
      return false;
   }
   
   // Fresh signal requirement
   if(g_inputs.Bullet_RequireFreshSignalAfterLoss && streak > 0) {
      if(!g_engines.IsFreshSignal(g_last_signal_time))
         return false;
   }
   
   // Loss quality step
   if(streak > 0) {
      int required_quality = g_inputs.Bullet_EntryQualityMinScore
                             + streak * g_inputs.Bullet_LossQualityStep;
      if(g_decision.quality_score < required_quality) {
         if(g_inputs.UDC_Log)
            Print("[Safety] Loss quality step: ", required_quality,
                  " > current ", g_decision.quality_score);
         return false;
      }
   }
   
   return true;
}

//+------------------------------------------------------------------+
//| AEG Check                                                          |
//+------------------------------------------------------------------+
bool AEG_Check() {
   if(!g_inputs.AEG_Enable) return true;
   double support = g_engines.CalcAEGSupport();
   return (support >= g_inputs.AEG_SupportStrengthGate);
}

//+------------------------------------------------------------------+
//| Check Bonus TP                                                     |
//+------------------------------------------------------------------+
void CheckBonusTP() {
   static datetime last_check;
   if(TimeCurrent() - last_check < 5) return;
   last_check = TimeCurrent();
   
   // Simplified bonus TP check
   // Full implementation in Nexus_Risk.mqh
}

//+------------------------------------------------------------------+
//| Check Profit Lock                                                  |
//+------------------------------------------------------------------+
void CheckProfitLock() {
   static datetime last_check;
   if(TimeCurrent() - last_check < 5) return;
   last_check = TimeCurrent();
}

//+------------------------------------------------------------------+
//| Check AEG Profit Exit                                              |
//+------------------------------------------------------------------+
void CheckAEGProfitExit() {
   if(!g_inputs.AEG_Enable) return;
}

//+------------------------------------------------------------------+
//| Close All Positions                                                 |
//+------------------------------------------------------------------+
void CloseAllPositions(ENUM_CLOSE_REASON reason) {
   Print("CLOSE ALL — Reason: ", EnumToString(reason));
   g_trade.CloseAll(g_magic_buy, g_magic_sell, reason);
   g_grid.CloseAllGrid(reason);
   
   if(g_inputs.SoundAlertsEnabled) {
      if(reason == CR_GLOBAL_RESET || reason == CR_GLOBAL_TP_RESET)
         PlaySound(g_inputs.SoundProfitReset);
      else
         PlaySound(g_inputs.SoundLossReset);
   }
}

//+------------------------------------------------------------------+
//| Manage Shadow Journal                                              |
//+------------------------------------------------------------------+
void ManageShadowJournal() {
   if(g_decision.safety_locked) return;
   
   // Update shadow positions
   double ask = SymbolInfoDouble(g_symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(g_symbol, SYMBOL_BID);
   
   for(int i = 0; i < g_shadow_count; i++) {
      if(g_shadow_positions[i].closed) continue;
      
      double current_price = (g_shadow_positions[i].type == TYPE_BUY) ? bid : ask;
      g_shadow_positions[i].current_price = current_price;
      g_shadow_positions[i].unrealized_pnl =
         (current_price - g_shadow_positions[i].open_price)
         * g_shadow_positions[i].lot * _Point;
      
      // Age check
      if(TimeCurrent() - g_shadow_positions[i].open_time
         > (datetime)g_inputs.ShadowTrade_MaxAgeSec) {
         CloseShadowPosition(i);
         continue;
      }
      
      // Target check
      double atr = g_data.GetATR(14);
      double target_dist = atr * g_inputs.ShadowTrade_TargetATR;
      double risk_dist = atr * g_inputs.ShadowTrade_RiskATR;
      
      if(g_shadow_positions[i].type == TYPE_BUY) {
         if(current_price - g_shadow_positions[i].open_price >= target_dist)
            CloseShadowPosition(i);
         else if(g_shadow_positions[i].open_price - current_price >= risk_dist)
            CloseShadowPosition(i);
      } else {
         if(g_shadow_positions[i].open_price - current_price >= target_dist)
            CloseShadowPosition(i);
         else if(current_price - g_shadow_positions[i].open_price >= risk_dist)
            CloseShadowPosition(i);
      }
   }
   
   // Open new shadow position based on signal
   if(g_decision.consensus_direction != DIR_NEUTRAL && !g_paused) {
      static datetime last_shadow_open;
      if(TimeCurrent() - last_shadow_open > (datetime)g_inputs.ShadowTrade_RearmSec) {
         OpenShadowPosition(g_decision.consensus_direction);
         last_shadow_open = TimeCurrent();
      }
   }
   
   // Write CSV
   if(g_inputs.ShadowTrade_WriteCSV)
      WriteShadowCSV();
}

//+------------------------------------------------------------------+
//| Open Shadow Position                                               |
//+------------------------------------------------------------------+
void OpenShadowPosition(ENUM_SIGNAL_DIR dir) {
   int idx = g_shadow_count;
   ArrayResize(g_shadow_positions, g_shadow_count + 1);
   
   double price = (dir == DIR_BUY)
                  ? SymbolInfoDouble(g_symbol, SYMBOL_ASK)
                  : SymbolInfoDouble(g_symbol, SYMBOL_BID);
   
   g_shadow_positions[idx].open_time = TimeCurrent();
   g_shadow_positions[idx].type = (dir == DIR_BUY) ? TYPE_BUY : TYPE_SELL;
   g_shadow_positions[idx].lot = g_inputs.FixedLot;
   g_shadow_positions[idx].open_price = price;
   g_shadow_positions[idx].current_price = price;
   g_shadow_positions[idx].unrealized_pnl = 0;
   g_shadow_positions[idx].closed = false;
   g_shadow_positions[idx].realized_pnl = 0;
   g_shadow_positions[idx].close_time = 0;
   
   double atr = g_data.GetATR(14);
   g_shadow_positions[idx].target_pnl = atr * g_inputs.ShadowTrade_TargetATR;
   g_shadow_positions[idx].risk_pnl = atr * g_inputs.ShadowTrade_RiskATR;
   
   g_shadow_count++;
   
   if(g_inputs.UDC_Log)
      Print("[Shadow] Opened: ", EnumToString(dir),
            " Price=", DoubleToString(price, _Digits),
            " Lot=", DoubleToString(g_shadow_positions[idx].lot, 2));
}

//+------------------------------------------------------------------+
//| Close Shadow Position                                             |
//+------------------------------------------------------------------+
void CloseShadowPosition(int idx) {
   if(g_shadow_positions[idx].closed) return;
   
   g_shadow_positions[idx].closed = true;
   g_shadow_positions[idx].close_time = TimeCurrent();
   
   double close_price = g_shadow_positions[idx].current_price;
   double open_price = g_shadow_positions[idx].open_price;
   
   if(g_shadow_positions[idx].type == TYPE_BUY)
      g_shadow_positions[idx].realized_pnl = (close_price - open_price)
         * g_shadow_positions[idx].lot * _Point;
   else
      g_shadow_positions[idx].realized_pnl = (open_price - close_price)
         * g_shadow_positions[idx].lot * _Point;
   
   if(g_inputs.UDC_Log)
      Print("[Shadow] Closed: PnL=",
            DoubleToString(g_shadow_positions[idx].realized_pnl, 2));
}

//+------------------------------------------------------------------+
//| Write Shadow CSV                                                   |
//+------------------------------------------------------------------+
void WriteShadowCSV() {
   static datetime last_write;
   if(TimeCurrent() - last_write < 60) return; // Write every minute
   last_write = TimeCurrent();
   
   string filename = "nexus_shadow_journal_" + g_symbol + ".csv";
   int handle = FileOpen(filename, FILE_CSV|FILE_WRITE|FILE_SHARE_READ|FILE_ANSI, ',');
   if(handle == INVALID_HANDLE) return;
   
   FileWrite(handle, "OpenTime,Type,Lot,OpenPrice,ClosePrice,RealizedPnL,CloseReason");
   
   for(int i = 0; i < g_shadow_count; i++) {
      if(g_shadow_positions[i].closed) {
         FileWrite(handle,
            TimeToString(g_shadow_positions[i].open_time),
            EnumToString(g_shadow_positions[i].type),
            DoubleToString(g_shadow_positions[i].lot, 2),
            DoubleToString(g_shadow_positions[i].open_price, _Digits),
            DoubleToString(g_shadow_positions[i].current_price, _Digits),
            DoubleToString(g_shadow_positions[i].realized_pnl, 2),
            g_shadow_positions[i].close_time > 0 ? "AGE/TARGET" : "");
      }
   }
   
   FileClose(handle);
}

//+------------------------------------------------------------------+
//| Update Panel Info                                                  |
//+------------------------------------------------------------------+
void UpdatePanelInfo() {
   static datetime last_panel_update;
   if(TimeCurrent() - last_panel_update < 1) return; // Update every second
   last_panel_update = TimeCurrent();
   
   string text = "";
   text += "═══════════════════════════════════\n";
   text += "NEXUS PRO v7.35 | " + g_symbol + "\n";
   text += "═══════════════════════════════════\n";
   text += "State: " + EnumToString(g_kernel_state) + "\n";
   text += "Signal: " + EnumToString(g_decision.consensus_direction) + "\n";
   text += "Quality: " + DoubleToString(g_decision.quality_score, 0) + "\n";
   text += "Score: " + DoubleToString(g_decision.direction_score, 2) + "\n";
   text += "─────────────────\n";
   text += "Equity: " + DoubleToString(g_account_equity, 2) + "\n";
   text += "Balance: " + DoubleToString(g_account_balance, 2) + "\n";
   text += "Drawdown: " + DoubleToString((g_peak_equity - g_account_equity)
             / g_peak_equity * 100.0, 2) + "%\n";
   text += "─────────────────\n";
   text += "Reset Count: " + IntegerToString(g_reset_count) + "\n";
   text += "Loss Streak BUY: " + IntegerToString(g_risk.GetSameSideLossStreak(DIR_BUY)) + "\n";
   text += "Loss Streak SELL: " + IntegerToString(g_risk.GetSameSideLossStreak(DIR_SELL)) + "\n";
   text += "─────────────────\n";
   text += "Open Trades: " + IntegerToString(g_trade.PositionsTotal()) + "\n";
   text += "Total P&L: " + DoubleToString(g_trade.TotalProfit(), 2) + "\n";
   text += "─────────────────\n";
   if(g_inputs.NF_Enable && g_news.IsAnyNewsSoon())
      text += "⚠ NEWS WITHIN " + IntegerToString(g_news.GetMinutesToNextNews()) + " MIN\n";
   if(g_viop_detected)
      text += "VIOP: " + (g_viop.IsSessionOpen() ? "OPEN" : "CLOSED") + "\n";
   if(g_paused) text += "⏸ PAUSED\n";
   if(g_decision.safety_locked)
      text += "🔒 " + g_decision.lock_reason + "\n";
   text += "─────────────────\n";
   text += "Shadow Positions: " + IntegerToString(g_shadow_count) + "\n";
   if(g_inputs.ML_ONNX_Enable && g_ml.IsModelLoaded())
      text += "ONNX: LOADED\n";
   
   Comment(text);
}

//+------------------------------------------------------------------+
//| Expert trading function                                            |
//+------------------------------------------------------------------+
double OnTester() {
   // For Strategy Tester optimization
   double gross_profit = 0;
   double gross_loss = 0;
   double trades = 0;
   
   HistorySelect(0, TimeCurrent());
   int total = HistoryDealsTotal();
   for(int i = 0; i < total; i++) {
      ulong ticket = HistoryDealGetTicket(i);
      if(ticket == 0) continue;
      long magic = HistoryDealGetInteger(ticket, DEAL_MAGIC);
      if(magic != g_magic_buy && magic != g_magic_sell) continue;
      
      double profit = HistoryDealGetDouble(ticket, DEAL_PROFIT);
      if(profit > 0) gross_profit += profit;
      else gross_loss += MathAbs(profit);
      trades++;
   }
   
   if(gross_loss > 0 && trades > 0)
      return gross_profit / gross_loss; // Profit Factor
   
   return 0;
}
