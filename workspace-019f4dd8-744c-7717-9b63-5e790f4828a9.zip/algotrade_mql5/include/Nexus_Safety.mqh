//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — Safety Layer                                |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>

//+------------------------------------------------------------------+
//| Safety Layer Class                                                |
//+------------------------------------------------------------------+
class CSafetyLayer {
private:
   CNexusInputs&     m_inputs;
   
   // Spread tracking
   double            m_spread_history[];
   int               m_spread_count;
   double            m_avg_spread;
   double            m_spike_threshold;
   datetime          m_last_spread_check;
   
   // Min distance
   double            m_last_buy_entry_price;
   double            m_last_sell_entry_price;
   datetime          m_last_buy_entry_time;
   datetime          m_last_sell_entry_time;
   
public:
   CSafetyLayer(CNexusInputs& inputs)
      : m_inputs(inputs), m_spread_count(0), m_avg_spread(0),
        m_spike_threshold(0), m_last_spread_check(0) {
      ArrayResize(m_spread_history, 0);
      m_last_buy_entry_price = 0;
      m_last_sell_entry_price = 0;
   }
   
   // ─── Spread Check ──────────────────────────────────────────────
   bool CheckSpread(string symbol) {
      if(!m_inputs.EnableSpreadProtection) return true;
      
      datetime now = TimeCurrent();
      if(now - m_last_spread_check < 1) return true; // Check every second
      m_last_spread_check = now;
      
      double bid = SymbolInfoDouble(symbol, SYMBOL_BID);
      double ask = SymbolInfoDouble(symbol, SYMBOL_ASK);
      double spread = (ask - bid) / _Point;
      
      // Add to history
      ArrayResize(m_spread_history, m_spread_count + 1);
      m_spread_history[m_spread_count] = spread;
      m_spread_count++;
      
      // Keep last 100 spread values
      const int MAX_SPREAD_HISTORY = 100;
      if(m_spread_count > MAX_SPREAD_HISTORY) {
         for(int i = 0; i < m_spread_count - 1; i++)
            m_spread_history[i] = m_spread_history[i + 1];
         m_spread_count = MAX_SPREAD_HISTORY;
      }
      
      // Calculate average
      double sum = 0;
      for(int i = 0; i < m_spread_count; i++) sum += m_spread_history[i];
      m_avg_spread = sum / m_spread_count;
      
      // Spike threshold
      m_spike_threshold = m_avg_spread * (1.0 + m_inputs.AutoSpreadSpikePct / 100.0);
      
      if(spread > m_inputs.MaxAllowedSpread) {
         Print("[Safety] Spread too high: ", DoubleToString(spread, 1),
               " > max ", m_inputs.MaxAllowedSpread);
         return false;
      }
      
      if(spread > m_spike_threshold && m_inputs.EnableAutoSpread) {
         Print("[Safety] Spread spike detected: ",
               DoubleToString(spread, 1), " avg=",
               DoubleToString(m_avg_spread, 1));
         return false;
      }
      
      return true;
   }
   
   // ─── Slippage Check ───────────────────────────────────────────
   bool CheckSlippage(string symbol, ENUM_ORDER_TYPE order_type,
                      double request_price, double exec_price) {
      if(!m_inputs.EnableSlippageProtection) return true;
      
      double slippage_points = MathAbs(exec_price - request_price) / _Point;
      
      if(slippage_points > m_inputs.MaxSlippage) {
         Print("[Safety] Slippge too high: ",
               DoubleToString(slippage_points, 0), " > max ",
               m_inputs.MaxSlippage);
         return false;
      }
      
      return true;
   }
   
   // ─── Min Distance Check ────────────────────────────────────────
   bool CheckMinDistance(string symbol, ENUM_ORDER_TYPE order_type,
                         double current_price) {
      if(!m_inputs.MinDist_Enable) return true;
      
      double min_distance_points = m_inputs.MinDist_Points;
      if(min_distance_points <= 0) return true;
      
      double min_distance_price = min_distance_points * _Point;
      
      if(order_type == ORDER_TYPE_BUY && m_last_buy_entry_price > 0) {
         if(current_price - m_last_buy_entry_price < min_distance_price) {
            if(m_inputs.MinDist_Log)
               Print("[Safety] BUY min distance not met: ",
                     DoubleToString(current_price - m_last_buy_entry_price, _Digits),
                     " < ", DoubleToString(min_distance_price, _Digits));
            return false;
         }
      }
      
      if(order_type == ORDER_TYPE_SELL && m_last_sell_entry_price > 0) {
         if(m_last_sell_entry_price - current_price < min_distance_price) {
            if(m_inputs.MinDist_Log)
               Print("[Safety] SELL min distance not met");
            return false;
         }
      }
      
      return true;
   }
   
   void RecordEntry(ENUM_ORDER_TYPE order_type, double price, datetime time) {
      if(order_type == ORDER_TYPE_BUY) {
         m_last_buy_entry_price = price;
         m_last_buy_entry_time = time;
      } else {
         m_last_sell_entry_price = price;
         m_last_sell_entry_time = time;
      }
   }
   
   // ─── Entry Quality ──────────────────────────────────────────────
   int CheckEntryQuality(int base_quality, string symbol) {
      int quality = base_quality;
      
      // Spread quality
      double spread = (SymbolInfoDouble(symbol, SYMBOL_ASK) -
                      SymbolInfoDouble(symbol, SYMBOL_BID)) / _Point;
      double atr = GetATR(symbol, 14);
      double spread_ratio = (atr > 0) ? spread * _Point / atr : 0;
      
      if(spread_ratio > 0.05) // 5% of ATR
         quality -= 10;
      
      // Time of day quality
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      // Low liquidity periods (major session overlaps)
      if((dt.hour >= 0 && dt.hour < 3) || (dt.hour >= 17 && dt.hour < 20))
         quality -= 5;
      
      return MathMax(0, quality);
   }
   
   double GetATR(string symbol, int period) {
      MqlRates rates[];
      if(CopyRates(symbol, PERIOD_CURRENT, 0, period + 1, rates) <= 0)
         return _Point * 100;
      double sum = 0;
      for(int i = 0; i < period; i++) {
         double tr = MathMax(rates[i].high - rates[i].low,
                    MathMax(MathAbs(rates[i].high - rates[i+1].close),
                            MathAbs(rates[i].low - rates[i+1].close)));
         sum += tr;
      }
      return sum / period;
   }
   
   double GetAvgSpread() { return m_avg_spread; }
   double GetSpreadThreshold() { return m_spike_threshold; }
};
