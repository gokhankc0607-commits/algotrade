//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — Trade Executor                              |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>

//+------------------------------------------------------------------+
//| Trade Executor Class                                              |
//+------------------------------------------------------------------+
class CTradeExecutor {
private:
   CNexusInputs&     m_inputs;
   string            m_symbol;
   long               m_last_error;
   
   // Position cache
   ulong             m_positions[];
   int               m_position_count;
   double            m_total_profit;
   double            m_total_lot_buy;
   double            m_total_lot_sell;
   
public:
   CTradeExecutor(CNexusInputs& inputs, string symbol)
      : m_inputs(inputs), m_symbol(symbol) {
      m_last_error = 0;
      m_position_count = 0;
      m_total_profit = 0;
      m_total_lot_buy = 0;
      m_total_lot_sell = 0;
      ArrayResize(m_positions, 0);
   }
   
   // ─── Refresh Position Cache ───────────────────────────────────
   void RefreshPositions(int magic_buy, int magic_sell) {
      m_position_count = 0;
      m_total_profit = 0;
      m_total_lot_buy = 0;
      m_total_lot_sell = 0;
      ArrayResize(m_positions, 0);
      
      int total = PositionsTotal();
      for(int i = 0; i < total; i++) {
         if(PositionGetSymbol(i) != m_symbol) continue;
         ulong magic = PositionGetInteger(POSITION_MAGIC);
         
         bool is_our_pos = (magic == magic_buy || magic == magic_sell
                          || magic == m_inputs.GetMagicGridBuy()
                          || magic == m_inputs.GetMagicGridSell()
                          || magic == m_inputs.GetMagicManualHedge()
                          || magic == m_inputs.GetMagicDDEdge()
                          || magic == m_inputs.GetMagicNFHedge());
         
         if(is_our_pos) {
            ArrayResize(m_positions, m_position_count + 1);
            m_positions[m_position_count] = PositionGetInteger(POSITION_TICKET);
            m_position_count++;
            
            if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
               m_total_lot_buy += PositionGetDouble(POSITION_VOLUME);
            else
               m_total_lot_sell += PositionGetDouble(POSITION_VOLUME);
            
            m_total_profit += PositionGetDouble(POSITION_PROFIT)
                            + PositionGetDouble(POSITION_SWAP)
                            - PositionGetDouble(POSITION_COMMISSION);
         }
      }
   }
   
   // ─── BUY ─────────────────────────────────────────────────────
   bool Buy(double lot, int magic) {
      double price = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
      double sl = 0, tp = 0;
      
      MqlTradeRequest request = {};
      MqlTradeResult result = {};
      
      request.action = TRADE_ACTION_DEAL;
      request.symbol = m_symbol;
      request.volume = lot;
      request.type = ORDER_TYPE_BUY;
      request.price = price;
      request.sl = sl;
      request.tp = tp;
      request.deviation = 10;
      request.magic = magic;
      request.comment = "NexusBuy";
      
      if(!OrderSend(request, result)) {
         m_last_error = GetLastError();
         Print("[Trade] BUY Error: ", m_last_error,
               " Retcode: ", result.retcode,
               " Deal: ", result.deal);
         return false;
      }
      
      if(result.retcode != TRADE_RETCODE_DONE) {
         Print("[Trade] BUY Retcode error: ", result.retcode,
               " Retcode comment: ", result.comment);
         return false;
      }
      
      Print("[Trade] BUY opened: Lot=", DoubleToString(lot, 2),
            " Price=", DoubleToString(price, _Digits),
            " Deal=", result.deal);
      return true;
   }
   
   // ─── SELL ─────────────────────────────────────────────────────
   bool Sell(double lot, int magic) {
      double price = SymbolInfoDouble(m_symbol, SYMBOL_BID);
      double sl = 0, tp = 0;
      
      MqlTradeRequest request = {};
      MqlTradeResult result = {};
      
      request.action = TRADE_ACTION_DEAL;
      request.symbol = m_symbol;
      request.volume = lot;
      request.type = ORDER_TYPE_SELL;
      request.price = price;
      request.sl = sl;
      request.tp = tp;
      request.deviation = 10;
      request.magic = magic;
      request.comment = "NexusSell";
      
      if(!OrderSend(request, result)) {
         m_last_error = GetLastError();
         Print("[Trade] SELL Error: ", m_last_error,
               " Retcode: ", result.retcode);
         return false;
      }
      
      if(result.retcode != TRADE_RETCODE_DONE) {
         Print("[Trade] SELL Retcode error: ", result.retcode);
         return false;
      }
      
      Print("[Trade] SELL opened: Lot=", DoubleToString(lot, 2),
            " Price=", DoubleToString(price, _Digits),
            " Deal=", result.deal);
      return true;
   }
   
   // ─── Close Single Position ────────────────────────────────────
   bool ClosePosition(ulong ticket, ENUM_CLOSE_REASON reason) {
      if(!PositionSelectByTicket(ticket)) return false;
      
      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double lot = PositionGetDouble(POSITION_VOLUME);
      double price = (type == POSITION_TYPE_BUY)
                     ? SymbolInfoDouble(m_symbol, SYMBOL_BID)
                     : SymbolInfoDouble(m_symbol, SYMBOL_ASK);
      
      MqlTradeRequest request = {};
      MqlTradeResult result = {};
      
      request.action = TRADE_ACTION_DEAL;
      request.symbol = m_symbol;
      request.volume = lot;
      request.type = (type == POSITION_TYPE_BUY) ? ORDER_TYPE_SELL : ORDER_TYPE_BUY;
      request.price = price;
      request.deviation = 10;
      request.ticket = ticket;
      request.comment = "NexusClose_" + EnumToString(reason);
      
      if(!OrderSend(request, result)) {
         Print("[Trade] Close Error: ", GetLastError(), " Retcode: ", result.retcode);
         return false;
      }
      
      Print("[Trade] Closed: Ticket=", ticket,
            " Reason=", EnumToString(reason),
            " Retcode=", result.retcode);
      return true;
   }
   
   // ─── Close All ────────────────────────────────────────────────
   int CloseAll(int magic_buy, int magic_sell, ENUM_CLOSE_REASON reason) {
      int closed = 0;
      
      int total = PositionsTotal();
      for(int i = total - 1; i >= 0; i--) {
         if(PositionGetSymbol(i) != m_symbol) continue;
         ulong magic = PositionGetInteger(POSITION_MAGIC);
         
         bool is_our = (magic == magic_buy || magic == magic_sell
                     || magic == m_inputs.GetMagicGridBuy()
                     || magic == m_inputs.GetMagicGridSell()
                     || magic == m_inputs.GetMagicManualHedge()
                     || magic == m_inputs.GetMagicNFHedge());
         
         if(is_our) {
            ulong ticket = PositionGetInteger(POSITION_TICKET);
            if(ClosePosition(ticket, reason)) closed++;
         }
      }
      
      Print("[Trade] CloseAll: ", closed, " positions closed, reason=",
            EnumToString(reason));
      return closed;
   }
   
   // ─── Close Profit / Loss Only ────────────────────────────────
   int CloseWinners(int magic_buy, int magic_sell) {
      int closed = 0;
      int total = PositionsTotal();
      for(int i = total - 1; i >= 0; i--) {
         if(PositionGetSymbol(i) != m_symbol) continue;
         ulong magic = PositionGetInteger(POSITION_MAGIC);
         
         bool is_our = (magic == magic_buy || magic == magic_sell
                     || magic == m_inputs.GetMagicGridBuy()
                     || magic == m_inputs.GetMagicGridSell());
         
         if(is_our) {
            double profit = PositionGetDouble(POSITION_PROFIT);
            if(profit > 0) {
               ulong ticket = PositionGetInteger(POSITION_TICKET);
               if(ClosePosition(ticket, CR_PANEL_FORCE)) closed++;
            }
         }
      }
      return closed;
   }
   
   int CloseLosers(int magic_buy, int magic_sell) {
      int closed = 0;
      int total = PositionsTotal();
      for(int i = total - 1; i >= 0; i--) {
         if(PositionGetSymbol(i) != m_symbol) continue;
         ulong magic = PositionGetInteger(POSITION_MAGIC);
         
         bool is_our = (magic == magic_buy || magic == magic_sell
                     || magic == m_inputs.GetMagicGridBuy()
                     || magic == m_inputs.GetMagicGridSell());
         
         if(is_our) {
            double profit = PositionGetDouble(POSITION_PROFIT);
            if(profit < 0) {
               ulong ticket = PositionGetInteger(POSITION_TICKET);
               if(ClosePosition(ticket, CR_PANEL_FORCE)) closed++;
            }
         }
      }
      return closed;
   }
   
   // ─── Margin Calculation ───────────────────────────────────────
   double CalculateMargin(double lot, double price, ENUM_POSITION_TYPE type) {
      double contract_size = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_CONTRACT_SIZE);
      double margin_rate = SymbolInfoDouble(m_symbol, SYMBOL_MARGIN_RATE);
      double margin = lot * contract_size * price * margin_rate;
      return margin;
   }
   
   double CalculateMargin(double lot, double price, ENUM_SIGNAL_DIR dir) {
      ENUM_POSITION_TYPE type = (dir == DIR_BUY) ? POSITION_TYPE_BUY : POSITION_TYPE_SELL;
      return CalculateMargin(lot, price, type);
   }
   
   // ─── Getters ──────────────────────────────────────────────────
   int PositionsTotal() { return m_position_count; }
   double TotalProfit() { return m_total_profit; }
   double TotalLotBuy() { return m_total_lot_buy; }
   double TotalLotSell() { return m_total_lot_sell; }
   long LastError() { return m_last_error; }
   
   double GetLastPrice(ENUM_POSITION_TYPE type) {
      int total = PositionsTotal();
      for(int i = 0; i < total; i++) {
         if(!PositionSelectByTicket(m_positions[i])) continue;
         if(PositionGetInteger(POSITION_TYPE) == type)
            return PositionGetDouble(POSITION_PRICE_OPEN);
      }
      return 0;
   }
   
   double GetLastPrice(int type) {
      return GetLastPrice((ENUM_POSITION_TYPE)type);
   }
   
   double GetPositionProfit(ulong ticket) {
      if(!PositionSelectByTicket(ticket)) return 0;
      return PositionGetDouble(POSITION_PROFIT);
   }
   
   // ─── Panel Actions ────────────────────────────────────────────
   void PanelGlobalForce() {
      CloseAll(m_inputs.GetMagicBuy(), m_inputs.GetMagicSell(), CR_PANEL_GLOBAL_FORCE);
      Print("[Trade] Panel Global Force — all positions closed");
   }
   
   void PanelCloseAll() {
      CloseAll(m_inputs.GetMagicBuy(), m_inputs.GetMagicSell(), CR_PANEL_FORCE);
      Print("[Trade] Panel Close All");
   }
   
   void PanelCloseWinners() {
      int n = CloseWinners(m_inputs.GetMagicBuy(), m_inputs.GetMagicSell());
      Print("[Trade] Panel Closed winners: ", n);
   }
   
   void PanelCloseLosers() {
      int n = CloseLosers(m_inputs.GetMagicBuy(), m_inputs.GetMagicSell());
      Print("[Trade] Panel Closed losers: ", n);
   }
   
   void TogglePause(bool& paused) {
      paused = !paused;
      Print("[Trade] Robot ", paused ? "PAUSED" : "RESUMED");
   }
   
   void ToggleBuy(bool& enable_buy) {
      enable_buy = !enable_buy;
      Print("[Trade] BUY ", enable_buy ? "ENABLED" : "DISABLED");
   }
   
   void ToggleSell(bool& enable_sell) {
      enable_sell = !enable_sell;
      Print("[Trade] SELL ", enable_sell ? "ENABLED" : "DISABLED");
   }
};
