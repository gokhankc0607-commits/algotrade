//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — R21 Grid Engine                            |
//| SANAL GAPLESS TWO-SIDED LATTICE GRID                              |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>
#include <Include/Algotrade/Nexus_Data.mqh>

//+------------------------------------------------------------------+
//| Grid Level Structure                                              |
//+------------------------------------------------------------------+
struct GridLevelData {
   double            price;
   double            lot;
   ENUM_POSITION_TYPE type;
   bool              triggered;
   bool              filled;
   ulong             ticket;
   datetime          trigger_time;
   double            trigger_price;
   double            pnl_at_trigger;
};

class CGridEngine {
private:
   CNexusInputs&     m_inputs;
   string            m_symbol;
   bool               m_initialized;
   
   // Lattice state
   double            m_lattice_anchor;
   double            m_lattice_buy_step;
   double            m_lattice_sell_step;
   bool              m_lattice_initialized;
   datetime          m_lattice_init_time;
   
   // Grid levels
   GridLevelData     m_buy_levels[];
   GridLevelData     m_sell_levels[];
   int               m_buy_count;
   int               m_sell_count;
   int               m_buy_filled;
   int               m_sell_filled;
   
   // Grid state
   double            m_net_buy_lot;
   double            m_net_sell_lot;
   double            m_net_buy_price;
   double            m_net_sell_price;
   double            m_last_buy_price;
   double            m_last_sell_price;
   
   // TP state
   double            m_grid_tp_buy;
   double            m_grid_tp_sell;
   bool              m_tp_buy_triggered;
   bool              m_tp_sell_triggered;
   
public:
   CGridEngine(CNexusInputs& inputs, string symbol)
      : m_inputs(inputs), m_symbol(symbol) {
      m_initialized = false;
      m_lattice_initialized = false;
      m_buy_count = 0;
      m_sell_count = 0;
      m_buy_filled = 0;
      m_sell_filled = 0;
      m_net_buy_lot = 0;
      m_net_sell_lot = 0;
      m_net_buy_price = 0;
      m_net_sell_price = 0;
      m_last_buy_price = 0;
      m_last_sell_price = 0;
      m_tp_buy_triggered = false;
      m_tp_sell_triggered = false;
      ArrayResize(m_buy_levels, 0);
      ArrayResize(m_sell_levels, 0);
   }
   
   void Initialize() {
      m_initialized = true;
      Print("[Grid] R21 Virtual Gapless Lattice initialized");
      Print("[Grid] LotMode=", EnumToString(m_inputs.VG_LotMode),
            " StepValue=", DoubleToString(m_inputs.VG_StepValue, 1),
            " TPValue=", DoubleToString(m_inputs.VG_TPValue, 2),
            " TPAuthority=", m_inputs.VG_TPAuthority);
      Print("[Grid] PyramidBuy=", m_inputs.VG_PyramidBuy,
            " PyramidSell=", m_inputs.VG_PyramidSell,
            " NettingSingleSide=", m_inputs.VG_NettingSingleSide);
   }
   
   // ─── Calculate Grid STEP ────────────────────────────────────────
   double GetGridStep(ENUM_POSITION_TYPE type) {
      double base_step = m_inputs.VG_StepValue * _Point;
      
      if(type == POSITION_TYPE_BUY) {
         if(m_inputs.VG_BuyStepValue > 0)
            return m_inputs.VG_BuyStepValue * _Point;
      } else {
         if(m_inputs.VG_SellStepValue > 0)
            return m_inputs.VG_SellStepValue * _Point;
      }
      
      switch(m_inputs.VG_StepMode) {
         case GST_RANGE_MULT: {
            // Range-based step
            double atr = GetATR14();
            return atr * m_inputs.VG_StepValue / 100.0;
         }
         case GST_PRICE_PCT: {
            double price = SymbolInfoDouble(m_symbol, SYMBOL_BID);
            return price * m_inputs.VG_StepValue / 100.0;
         }
         default:
            return base_step;
      }
   }
   
   double GetATR14() {
      MqlRates r[];
      if(CopyRates(m_symbol, PERIOD_CURRENT, 0, 14, r) <= 0) return _Point * 100;
      double sum = 0;
      for(int i = 0; i < 13; i++) {
         double tr = MathMax(r[i].high - r[i].low,
                    MathMax(MathAbs(r[i].high - r[i+1].close),
                            MathAbs(r[i].low - r[i+1].close)));
         sum += tr;
      }
      return sum / 13.0;
   }
   
   // ─── Calculate Grid TP ─────────────────────────────────────────
   double GetGridTP(ENUM_POSITION_TYPE type) {
      double base_tp = m_inputs.VG_TPValue * _Point;
      
      switch(m_inputs.VG_TPMode) {
         case GTP_SPREAD_MULT: {
            double spread = SymbolInfoDouble(m_symbol, SYMBOL_SPREAD) * _Point;
            return spread * m_inputs.VG_TPValue;
         }
         case GTP_BALANCE_PCT: {
            double bal = AccountInfoDouble(ACCOUNT_BALANCE);
            return bal * m_inputs.VG_TPValue / 100.0 / 100.0;
         }
         case GTP_FIXED_PTS:
            return m_inputs.VG_TPValue * _Point;
         case GTP_PRICE_PCT: {
            double price = SymbolInfoDouble(m_symbol, SYMBOL_BID);
            return price * m_inputs.VG_TPValue / 100.0;
         }
         default:
            return base_tp;
      }
   }
   
   // ─── Calculate Grid Lot ─────────────────────────────────────────
   double GetGridLot(ENUM_POSITION_TYPE type) {
      double base_lot = m_inputs.VG_LotValue;
      
      switch(m_inputs.VG_LotMode) {
         case GLM_BALANCE_PCT: {
            double bal = AccountInfoDouble(ACCOUNT_BALANCE);
            return bal * m_inputs.VG_LotValue / 100.0;
         }
         case GLM_EQUITY_PCT: {
            double eq = AccountInfoDouble(ACCOUNT_EQUITY);
            return eq * m_inputs.VG_LotValue / 100.0;
         }
         default:
            return base_lot;
      }
   }
   
   // ─── Main Grid Management ───────────────────────────────────────
   void Manage(ENUM_SIGNAL_DIR trend_direction, bool new_bar) {
      if(!m_initialized || !m_inputs.VG_Enable) return;
      
      double bid = SymbolInfoDouble(m_symbol, SYMBOL_BID);
      double ask = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
      double spread = (ask - bid) / _Point;
      
      // Initialize lattice on first run or new bar
      if(!m_lattice_initialized || new_bar) {
         InitializeLattice(bid, ask);
      }
      
      // Trend adaptive direction
      bool is_trend = (trend_direction != DIR_NEUTRAL);
      if(is_trend && m_inputs.VG_StopNewEntriesOnTrend) {
         // Trend mode: don't add new grid levels
         return;
      }
      
      // ─── Check BUY side ────────────────────────────────────────
      if(m_inputs.GridDirectionPermission != DPERM_SELL) {
         CheckAndTriggerBuyLevel(bid, ask, spread);
         CheckPyramidBuy(bid);
      }
      
      // ─── Check SELL side ───────────────────────────────────────
      if(m_inputs.GridDirectionPermission != DPERM_BUY) {
         CheckAndTriggerSellLevel(bid, ask, spread);
         CheckPyramidSell(bid);
      }
      
      // ─── Update TP targets ──────────────────────────────────────
      UpdateGridTP();
      
      // ─── Check filled levels for TP ────────────────────────────
      if(m_inputs.VG_TPAuthority)
         CheckGridTPOnFilledLevels();
      
      // ─── Grid TP management ────────────────────────────────────
      if(m_inputs.VG_TPManageStrictOff) return;
      ManageGridTP();
   }
   
   void InitializeLattice(double bid, double ask) {
      if(!m_lattice_initialized) {
         m_lattice_anchor = bid;
         m_lattice_buy_step = GetGridStep(POSITION_TYPE_BUY);
         m_lattice_sell_step = GetGridStep(POSITION_TYPE_SELL);
         
         // Build initial levels
         BuildInitialLevels(bid, ask);
         
         m_lattice_initialized = true;
         m_lattice_init_time = TimeCurrent();
      }
   }
   
   void BuildInitialLevels(double bid, double ask) {
      // Clear old levels
      m_buy_count = 0;
      m_sell_count = 0;
      ArrayResize(m_buy_levels, 0);
      ArrayResize(m_sell_levels, 0);
      
      double buy_step = m_lattice_buy_step;
      double sell_step = m_lattice_sell_step;
      double lot = GetGridLot(POSITION_TYPE_BUY);
      double sell_lot = GetGridLot(POSITION_TYPE_SELL);
      
      // Netting single side: only one direction
      if(m_inputs.VG_NettingSingleSide) {
         // For netting, start on flat — create symmetric levels
         int levels = 10;
         ArrayResize(m_buy_levels, levels);
         ArrayResize(m_sell_levels, levels);
         
         for(int i = 0; i < levels; i++) {
            m_buy_levels[i].price = m_lattice_anchor - (i + 1) * buy_step;
            m_buy_levels[i].lot = lot;
            m_buy_levels[i].type = POSITION_TYPE_BUY;
            m_buy_levels[i].triggered = false;
            m_buy_levels[i].filled = false;
            m_buy_levels[i].ticket = 0;
            
            m_sell_levels[i].price = m_lattice_anchor + (i + 1) * sell_step;
            m_sell_levels[i].lot = sell_lot;
            m_sell_levels[i].type = POSITION_TYPE_SELL;
            m_sell_levels[i].triggered = false;
            m_sell_levels[i].filled = false;
            m_sell_levels[i].ticket = 0;
         }
         m_buy_count = levels;
         m_sell_count = levels;
      } else {
         // Hedging: separate grids
         int levels = 10;
         ArrayResize(m_buy_levels, levels);
         for(int i = 0; i < levels; i++) {
            m_buy_levels[i].price = m_lattice_anchor - (i + 1) * buy_step;
            m_buy_levels[i].lot = lot;
            m_buy_levels[i].type = POSITION_TYPE_BUY;
            m_buy_levels[i].triggered = false;
            m_buy_levels[i].filled = false;
         }
         ArrayResize(m_sell_levels, levels);
         for(int i = 0; i < levels; i++) {
            m_sell_levels[i].price = m_lattice_anchor + (i + 1) * sell_step;
            m_sell_levels[i].lot = sell_lot;
            m_sell_levels[i].type = POSITION_TYPE_SELL;
            m_sell_levels[i].triggered = false;
            m_sell_levels[i].filled = false;
         }
         m_buy_count = levels;
         m_sell_count = levels;
      }
      
      Print("[Grid] Lattice built: Anchor=",
            DoubleToString(m_lattice_anchor, _Digits),
            " BuyStep=", DoubleToString(buy_step / _Point, 1),
            " SellStep=", DoubleToString(sell_step / _Point, 1),
            " BuyLevels=", m_buy_count,
            " SellLevels=", m_sell_count);
   }
   
   void CheckAndTriggerBuyLevel(double bid, double ask, double spread) {
      for(int i = 0; i < m_buy_count; i++) {
         if(m_buy_levels[i].triggered) continue;
         
         // Trigger condition: price crosses or reaches level
         if(bid <= m_buy_levels[i].price) {
            m_buy_levels[i].triggered = true;
            m_buy_levels[i].trigger_time = TimeCurrent();
            m_buy_levels[i].trigger_price = bid;
            
            // Send market BUY order
            ulong ticket = OrderSend(m_symbol, ORDER_TYPE_BUY,
                m_buy_levels[i].lot, ask, 10, 0, 0,
                "NexusGridBuy", m_inputs.GetMagicGridBuy(), 0, clrBlue);
            
            if(ticket > 0) {
               m_buy_levels[i].filled = true;
               m_buy_levels[i].ticket = ticket;
               m_buy_levels[i].pnl_at_trigger = 0;
               m_buy_levels[i].trigger_price = ask;
               m_net_buy_lot += m_buy_levels[i].lot;
               m_last_buy_price = ask;
               
               if(m_net_buy_lot > 0)
                  m_net_buy_price = (m_net_buy_price * (m_net_buy_lot - m_buy_levels[i].lot)
                                     + ask * m_buy_levels[i].lot) / m_net_buy_lot;
               
               Print("[Grid] BUY Level triggered: #", i,
                     " Price=", DoubleToString(m_buy_levels[i].price, _Digits),
                     " Lot=", DoubleToString(m_buy_levels[i].lot, 2),
                     " Ticket=", ticket);
            }
         }
      }
   }
   
   void CheckAndTriggerSellLevel(double bid, double ask, double spread) {
      for(int i = 0; i < m_sell_count; i++) {
         if(m_sell_levels[i].triggered) continue;
         
         // Trigger condition: price crosses or reaches level
         if(ask >= m_sell_levels[i].price) {
            m_sell_levels[i].triggered = true;
            m_sell_levels[i].trigger_time = TimeCurrent();
            m_sell_levels[i].trigger_price = ask;
            
            // Send market SELL order
            ulong ticket = OrderSend(m_symbol, ORDER_TYPE_SELL,
                m_sell_levels[i].lot, bid, 10, 0, 0,
                "NexusGridSell", m_inputs.GetMagicGridSell(), 0, clrRed);
            
            if(ticket > 0) {
               m_sell_levels[i].filled = true;
               m_sell_levels[i].ticket = ticket;
               m_sell_levels[i].pnl_at_trigger = 0;
               m_sell_levels[i].trigger_price = bid;
               m_net_sell_lot += m_sell_levels[i].lot;
               m_last_sell_price = bid;
               
               if(m_net_sell_lot > 0)
                  m_net_sell_price = (m_net_sell_price * (m_net_sell_lot - m_sell_levels[i].lot)
                                      + bid * m_sell_levels[i].lot) / m_net_sell_lot;
               
               Print("[Grid] SELL Level triggered: #", i,
                     " Price=", DoubleToString(m_sell_levels[i].price, _Digits),
                     " Lot=", DoubleToString(m_sell_levels[i].lot, 2),
                     " Ticket=", ticket);
            }
         }
      }
   }
   
   void CheckPyramidBuy(double bid) {
      if(!m_inputs.VG_PyramidBuy) return;
      // Pyramid: add same-direction level if profitable
      // Simplified implementation
   }
   
   void CheckPyramidSell(double ask) {
      if(!m_inputs.VG_PyramidSell) return;
      // Pyramid: add same-direction level if profitable
   }
   
   void UpdateGridTP() {
      if(m_net_buy_lot > 0 && m_net_buy_price > 0) {
         m_grid_tp_buy = m_net_buy_price + GetGridTP(POSITION_TYPE_BUY);
      }
      if(m_net_sell_lot > 0 && m_net_sell_price > 0) {
         m_grid_tp_sell = m_net_sell_price - GetGridTP(POSITION_TYPE_SELL);
      }
   }
   
   void CheckGridTPOnFilledLevels() {
      double bid = SymbolInfoDouble(m_symbol, SYMBOL_BID);
      double ask = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
      
      // Check BUY TP
      if(m_net_buy_lot > 0 && m_grid_tp_buy > 0) {
         if(ask >= m_grid_tp_buy) {
            // Close all BUY positions
            CloseGridDirection(POSITION_TYPE_BUY, CR_GRID_TP);
            m_tp_buy_triggered = true;
            Print("[Grid] BUY TP hit: ", DoubleToString(m_grid_tp_buy, _Digits));
            
            // Replace levels (gapless)
            if(!m_inputs.VG_StopNewEntriesOnTrend)
               RebuildGridSide(POSITION_TYPE_BUY);
         }
      }
      
      // Check SELL TP
      if(m_net_sell_lot > 0 && m_grid_tp_sell > 0) {
         if(bid <= m_grid_tp_sell) {
            CloseGridDirection(POSITION_TYPE_SELL, CR_GRID_TP);
            m_tp_sell_triggered = true;
            Print("[Grid] SELL TP hit: ", DoubleToString(m_grid_tp_sell, _Digits));
            
            if(!m_inputs.VG_StopNewEntriesOnTrend)
               RebuildGridSide(POSITION_TYPE_SELL);
         }
      }
   }
   
   void ManageGridTP() {
      // Comprehensive TP management
      CheckGridTPOnFilledLevels();
   }
   
   void CheckGridTP() {
      CheckGridTPOnFilledLevels();
   }
   
   void CloseGridDirection(ENUM_POSITION_TYPE type, ENUM_CLOSE_REASON reason) {
      int total = PositionsTotal();
      int magic_buy = m_inputs.GetMagicGridBuy();
      int magic_sell = m_inputs.GetMagicGridSell();
      
      for(int i = total - 1; i >= 0; i--) {
         if(PositionGetSymbol(i) != m_symbol) continue;
         ulong ticket = PositionGetInteger(POSITION_TICKET);
         ulong magic = PositionGetInteger(POSITION_MAGIC);
         
         bool is_grid_pos = (type == POSITION_TYPE_BUY && magic == magic_buy)
                          || (type == POSITION_TYPE_SELL && magic == magic_sell);
         
         if(is_grid_pos) {
            double price = (type == POSITION_TYPE_BUY)
                           ? SymbolInfoDouble(m_symbol, SYMBOL_BID)
                           : SymbolInfoDouble(m_symbol, SYMBOL_ASK);
            OrderClose(ticket, PositionGetDouble(POSITION_VOLUME),
                       price, 10, clrNONE);
         }
      }
      
      if(type == POSITION_TYPE_BUY) {
         m_net_buy_lot = 0;
         m_net_buy_price = 0;
         m_tp_buy_triggered = false;
         for(int i = 0; i < m_buy_count; i++)
            m_buy_levels[i].filled = false;
      } else {
         m_net_sell_lot = 0;
         m_net_sell_price = 0;
         m_tp_sell_triggered = false;
         for(int i = 0; i < m_sell_count; i++)
            m_sell_levels[i].filled = false;
      }
   }
   
   void RebuildGridSide(ENUM_POSITION_TYPE type) {
      double bid = SymbolInfoDouble(m_symbol, SYMBOL_BID);
      double ask = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
      double step = (type == POSITION_TYPE_BUY) ? m_lattice_buy_step : m_lattice_sell_step;
      double lot = (type == POSITION_TYPE_BUY) ? GetGridLot(POSITION_TYPE_BUY)
                                                : GetGridLot(POSITION_TYPE_SELL);
      
      if(type == POSITION_TYPE_BUY) {
         // Rebuild: shift all levels down by one step
         for(int i = m_buy_count - 1; i > 0; i--) {
            m_buy_levels[i].price = m_buy_levels[i-1].price;
            m_buy_levels[i].lot = m_buy_levels[i-1].lot;
            m_buy_levels[i].triggered = m_buy_levels[i-1].triggered;
            m_buy_levels[i].filled = m_buy_levels[i-1].filled;
         }
         m_buy_levels[0].price = bid - step;
         m_buy_levels[0].lot = lot;
         m_buy_levels[0].triggered = false;
         m_buy_levels[0].filled = false;
         m_buy_levels[0].ticket = 0;
      } else {
         for(int i = m_sell_count - 1; i > 0; i--) {
            m_sell_levels[i].price = m_sell_levels[i-1].price;
            m_sell_levels[i].lot = m_sell_levels[i-1].lot;
            m_sell_levels[i].triggered = m_sell_levels[i-1].triggered;
            m_sell_levels[i].filled = m_sell_levels[i-1].filled;
         }
         m_sell_levels[0].price = ask + step;
         m_sell_levels[0].lot = lot;
         m_sell_levels[0].triggered = false;
         m_sell_levels[0].filled = false;
         m_sell_levels[0].ticket = 0;
      }
   }
   
   void CloseAllGrid(ENUM_CLOSE_REASON reason) {
      CloseGridDirection(POSITION_TYPE_BUY, reason);
      CloseGridDirection(POSITION_TYPE_SELL, reason);
      m_lattice_initialized = false;
   }
   
   // ─── Getters ───────────────────────────────────────────────────
   double NetBuyLot() { return m_net_buy_lot; }
   double NetSellLot() { return m_net_sell_lot; }
   double NetBuyPrice() { return m_net_buy_price; }
   double NetSellPrice() { return m_net_sell_price; }
   bool IsLatticeInitialized() { return m_lattice_initialized; }
};
