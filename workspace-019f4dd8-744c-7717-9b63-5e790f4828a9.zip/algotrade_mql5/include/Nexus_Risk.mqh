//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — Risk & Money Management                     |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>

//+------------------------------------------------------------------+
//| Trade Record                                                       |
//+------------------------------------------------------------------+
struct TradeRecord {
   datetime          open_time;
   datetime          close_time;
   ENUM_SIGNAL_DIR   direction;
   double            lot;
   double            open_price;
   double            close_price;
   double            profit;
   bool              was_win;
   int               hold_seconds;
};

//+------------------------------------------------------------------+
//| Risk Manager Class                                                |
//+------------------------------------------------------------------+
class CRiskManager {
private:
   CNexusInputs&     m_inputs;
   
   // Equity tracking
   double            m_peak_equity;
   double            m_last_reset_equity;
   double            m_current_equity;
   double            m_current_balance;
   double            m_initial_equity;
   datetime          m_equity_peak_time;
   double            m_max_drawdown_pct;
   double            m_current_drawdown_pct;
   
   // Daily tracking
   datetime          m_daily_start_time;
   double            m_daily_start_equity;
   double            m_daily_peak_equity;
   double            m_daily_open_equity;
   bool               m_daily_locked;
   
   // Weekly schedule
   bool               m_weekly_blocked;
   
   // Loss streaks
   int               m_buy_loss_streak;
   int               m_sell_loss_streak;
   int               m_buy_win_streak;
   int               m_sell_win_streak;
   
   // Trade history
   TradeRecord       m_trades[];
   int               m_trade_count;
   double            m_total_profit;
   double            m_total_loss;
   int               m_win_count;
   int               m_loss_count;
   
   // Reset tracking
   datetime          m_last_reset_time;
   int               m_reset_count;
   
public:
   CRiskManager(CNexusInputs& inputs)
      : m_inputs(inputs) {
      Reset();
   }
   
   void Reset() {
      m_peak_equity = 0;
      m_last_reset_equity = 0;
      m_current_equity = 0;
      m_current_balance = 0;
      m_initial_equity = 0;
      m_equity_peak_time = 0;
      m_max_drawdown_pct = 0;
      m_current_drawdown_pct = 0;
      m_daily_start_time = 0;
      m_daily_start_equity = 0;
      m_daily_peak_equity = 0;
      m_daily_open_equity = 0;
      m_daily_locked = false;
      m_weekly_blocked = false;
      m_buy_loss_streak = 0;
      m_sell_loss_streak = 0;
      m_buy_win_streak = 0;
      m_sell_win_streak = 0;
      m_trade_count = 0;
      m_total_profit = 0;
      m_total_loss = 0;
      m_win_count = 0;
      m_loss_count = 0;
      m_reset_count = 0;
      m_last_reset_time = 0;
      ArrayResize(m_trades, 0);
   }
   
   void Initialize() {
      m_current_balance = AccountInfoDouble(ACCOUNT_BALANCE);
      m_current_equity = AccountInfoDouble(ACCOUNT_EQUITY);
      m_initial_equity = m_current_equity;
      m_peak_equity = m_current_equity;
      m_last_reset_equity = m_current_equity;
      m_daily_start_equity = m_current_equity;
      m_daily_peak_equity = m_current_equity;
      m_daily_open_equity = m_current_equity;
      
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      dt.hour = 0; dt.min = 0; dt.sec = 0;
      m_daily_start_time = StructToTime(dt);
      
      Print("[Risk] Initial Equity: ", DoubleToString(m_initial_equity, 2),
            " Balance: ", DoubleToString(m_current_balance, 2));
   }
   
   // ─── Update Equity ────────────────────────────────────────────
   void UpdateEquity(double equity, double balance) {
      m_current_equity = equity;
      m_current_balance = balance;
      
      if(equity > m_peak_equity) {
         m_peak_equity = equity;
         m_equity_peak_time = TimeCurrent();
      }
      
      if(equity > m_daily_peak_equity)
         m_daily_peak_equity = equity;
      
      // Current drawdown
      if(m_peak_equity > 0) {
         m_current_drawdown_pct = (m_peak_equity - equity) / m_peak_equity * 100.0;
         if(m_current_drawdown_pct > m_max_drawdown_pct)
            m_max_drawdown_pct = m_current_drawdown_pct;
      }
      
      // Check daily reset
      CheckDailyReset();
   }
   
   void CheckDailyReset() {
      datetime now = TimeCurrent();
      MqlDateTime dt;
      TimeToStruct(now, dt);
      datetime today_start;
      dt.hour = 0; dt.min = 0; dt.sec = 0;
      today_start = StructToTime(dt);
      
      if(today_start != m_daily_start_time) {
         // New day
         m_daily_start_time = today_start;
         m_daily_start_equity = m_current_equity;
         m_daily_peak_equity = m_current_equity;
         m_daily_locked = false;
      }
   }
   
   // ─── Record Trade ─────────────────────────────────────────────
   void RecordTrade(ENUM_SIGNAL_DIR dir, double lot, bool is_open) {
      // For closed trades, this would be called from order close
      // Simplified: track streaks
   }
   
   void RecordClosedTrade(ENUM_SIGNAL_DIR dir, double lot,
                         double open_price, double close_price,
                         double profit, datetime open_time) {
      ArrayResize(m_trades, m_trade_count + 1);
      m_trades[m_trade_count].open_time = open_time;
      m_trades[m_trade_count].close_time = TimeCurrent();
      m_trades[m_trade_count].direction = dir;
      m_trades[m_trade_count].lot = lot;
      m_trades[m_trade_count].open_price = open_price;
      m_trades[m_trade_count].close_price = close_price;
      m_trades[m_trade_count].profit = profit;
      m_trades[m_trade_count].was_win = profit > 0;
      m_trades[m_trade_count].hold_seconds =
         (int)(m_trades[m_trade_count].close_time - open_time);
      
      m_trade_count++;
      m_total_profit += (profit > 0) ? profit : 0;
      m_total_loss += (profit < 0) ? MathAbs(profit) : 0;
      
      if(profit > 0) {
         m_win_count++;
         if(dir == DIR_BUY) {
            m_buy_win_streak++;
            m_buy_loss_streak = 0;
         } else {
            m_sell_win_streak++;
            m_sell_loss_streak = 0;
         }
      } else {
         m_loss_count++;
         if(dir == DIR_BUY) {
            m_buy_loss_streak++;
            m_buy_win_streak = 0;
         } else {
            m_sell_loss_streak++;
            m_sell_win_streak = 0;
         }
      }
   }
   
   // ─── Global Reset Checks ──────────────────────────────────────
   bool CheckGlobalReset() {
      double equity_change = (m_last_reset_equity > 0)
         ? (m_current_equity - m_last_reset_equity)
           / m_last_reset_equity * 100.0 : 0;
      
      if(equity_change >= m_inputs.GlobalProfitPct) return true;
      if(equity_change <= -m_inputs.GlobalLossPct) return true;
      
      return false;
   }
   
   // ─── Time Limit Reset ─────────────────────────────────────────
   bool CheckTimeLimitReset(datetime last_reset) {
      if(!m_inputs.EnableTimeLimitReset) return false;
      
      datetime now = TimeCurrent();
      int minutes_elapsed = (int)((now - last_reset) / 60);
      
      return (minutes_elapsed >= m_inputs.TimeLimitMinutes);
   }
   
   // ─── Daily Locks ──────────────────────────────────────────────
   bool CheckDailyProfitLock(double initial, double current) {
      if(!m_inputs.DailyProfitLockEnable) return false;
      
      double change_pct = (current - initial) / initial * 100.0;
      return (change_pct >= m_inputs.DailyProfitTargetPct);
   }
   
   bool CheckDailyLossLock(double initial, double current) {
      if(!m_inputs.DailyLossLockEnable) return false;
      
      double change_pct = (initial - current) / initial * 100.0;
      return (change_pct >= m_inputs.DailyLossTargetPct);
   }
   
   bool IsDailyLocked() { return m_daily_locked; }
   
   void LockDaily() { m_daily_locked = true; }
   void UnlockDaily() {
      m_daily_locked = false;
      m_daily_start_equity = m_current_equity;
      m_daily_peak_equity = m_current_equity;
   }
   
   // ─── Weekly Schedule ──────────────────────────────────────────
   bool IsWeeklyBlocked() {
      if(!m_inputs.EnableWeeklySchedule) return false;
      
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      string periods[4];
      
      switch(dt.day_of_week) {
         case 1: // Monday
            periods[0] = m_inputs.Mon_P1; periods[1] = m_inputs.Mon_P2;
            periods[2] = m_inputs.Mon_P3; periods[3] = m_inputs.Mon_P4; break;
         case 2: // Tuesday
            periods[0] = m_inputs.Tue_P1; periods[1] = m_inputs.Tue_P2;
            periods[2] = m_inputs.Tue_P3; periods[3] = m_inputs.Tue_P4; break;
         case 3: // Wednesday
            periods[0] = m_inputs.Wed_P1; periods[1] = m_inputs.Wed_P2;
            periods[2] = m_inputs.Wed_P3; periods[3] = m_inputs.Wed_P4; break;
         case 4: // Thursday
            periods[0] = m_inputs.Thu_P1; periods[1] = m_inputs.Thu_P2;
            periods[2] = m_inputs.Thu_P3; periods[3] = m_inputs.Thu_P4; break;
         case 5: // Friday
            periods[0] = m_inputs.Fri_P1; periods[1] = m_inputs.Fri_P2;
            periods[2] = m_inputs.Fri_P3; periods[3] = m_inputs.Fri_P4; break;
         case 6: // Saturday
            periods[0] = m_inputs.Sat_P1; periods[1] = m_inputs.Sat_P2;
            periods[2] = m_inputs.Sat_P3; periods[3] = m_inputs.Sat_P4; break;
         case 0: // Sunday
            periods[0] = m_inputs.Sun_P1; periods[1] = m_inputs.Sun_P2;
            periods[2] = m_inputs.Sun_P3; periods[3] = m_inputs.Sun_P4; break;
      }
      
      int current_minutes = dt.hour * 60 + dt.min;
      
      for(int i = 0; i < 4; i++) {
         if(periods[i] == "00:00-00:00") continue; // Closed period
         if(periods[i] == "00:00-23:59") return false; // Open period
         
         // Parse period
         string parts[];
         if(StringSplit(periods[i], '-', parts) == 2) {
            string start_parts[], end_parts[];
            StringSplit(parts[0], ':', start_parts);
            StringSplit(parts[1], ':', end_parts);
            
            int start_min = StringToInteger(start_parts[0]) * 60
                           + StringToInteger(start_parts[1]);
            int end_min = StringToInteger(end_parts[0]) * 60
                         + StringToInteger(end_parts[1]);
            
            if(current_minutes >= start_min && current_minutes < end_min)
               return false; // Trading allowed
         }
      }
      
      return true; // Trading blocked
   }
   
   // ─── Loss Streaks ─────────────────────────────────────────────
   int GetSameSideLossStreak(ENUM_SIGNAL_DIR dir) {
      return (dir == DIR_BUY) ? m_buy_loss_streak : m_sell_loss_streak;
   }
   
   // ─── Drawdown Hedge ────────────────────────────────────────────
   bool CheckDrawdownHedgeTrigger() {
      if(!m_inputs.EnableAutoDDHedge) return false;
      
      double drawdown_pct = (m_peak_equity > 0)
         ? (m_peak_equity - m_current_equity) / m_peak_equity * 100.0 : 0;
      
      return (drawdown_pct >= m_inputs.AutoDDHedgePct);
   }
   
   // ─── Statistics ───────────────────────────────────────────────
   double GetProfitFactor() {
      if(m_total_loss > 0)
         return m_total_profit / m_total_loss;
      return (m_total_profit > 0) ? 999 : 0;
   }
   
   double GetWinRate() {
      int total = m_win_count + m_loss_count;
      return (total > 0) ? (double)m_win_count / total * 100.0 : 0;
   }
   
   double GetMaxDrawdown() { return m_max_drawdown_pct; }
   double GetCurrentDrawdown() { return m_current_drawdown_pct; }
   double GetPeakEquity() { return m_peak_equity; }
   double GetCurrentEquity() { return m_current_equity; }
   int GetResetCount() { return m_reset_count; }
   datetime GetLastResetTime() { return m_last_reset_time; }
   
   void SetResetCount(int count) { m_reset_count = count; }
   void SetLastResetEquity(double equity) { m_last_reset_equity = equity; }
   void SetLastResetTime(datetime t) { m_last_reset_time = t; }
};
