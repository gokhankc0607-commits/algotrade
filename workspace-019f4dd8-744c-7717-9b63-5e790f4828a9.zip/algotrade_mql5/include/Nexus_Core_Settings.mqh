//+------------------------------------------------------------------+
//| Algotrade Nexus Pro 7.35 - CORE SETTINGS                        |
//| 42 Ayar Grubu | 372 Input | R21 Architecture                   |
//| Sürüm: 7.35 | Build: REAL_ARCHITECTURE_R21                    |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"
#property link     "https://algotrade.pro"
#property icon      ""

// ─── STRATEGY PANEL ───────────────────────────────────────────────
enum ENUM_PANEL_TAB   { TAB_CTRL, TAB_TOOLS, TAB_NEWS, TAB_PARAM, TAB_QUALITY };
enum ENUM_DASH_PAGE   { DASH_STRATEGY, DASH_TREND, DASH_SYSTEM, DASH_RESET };
enum ENUM_KERNEL_STATE {
   NUK_BOOT, NUK_SAFETY_LOCK, NUK_MANAGE_ONLY,
   NUK_WAIT_DIR, NUK_WAIT_ENTRY, NUK_ENTRY_READY,
   NUK_ORDER_PENDING, NUK_POS_MANAGE, NUK_COOLDOWN
};
enum ENUM_CLOSE_REASON {
   CR_OTHER, CR_GRID_TP, CR_GLOBAL_TP_RESET, CR_GLOBAL_RESET,
   CR_PROJECT_TP_RESET, CR_PANEL_FORCE, CR_PANEL_GLOBAL_FORCE,
   CR_TIME_LIMIT_RESET, CR_FORCED_RESET, CR_TREND_FLIP,
   CR_NEWS_HEDGE, CR_MANUAL_HEDGE, CR_TIME_FILTER,
   CR_NEWS_CLOSE_ALL, CR_VIOP_EXPIRY, CR_DAILY_PROFIT_LOCK,
   CR_DAILY_LOSS_LOCK, CR_TREND_PROFIT_FLIP, CR_TREND_BONUS_TP,
   CR_TREND_PROFIT_LOCK, CR_AEG_PROFIT_EXIT, CR_TIME_FILTER_PROFIT,
   CR_TIME_LIMIT_PROFIT, CR_HEDGE_PROFIT_TARGET
};

// ─── LANGUAGE ────────────────────────────────────────────────────
enum ENUM_LANG {
   LANG_EN=0, LANG_TR=1, LANG_KU=2, LANG_RU=3, LANG_HI=4,
   LANG_ZH=5, LANG_FR=6, LANG_AR=7, LANG_FA=8, LANG_DE=9,
   LANG_IT=10, LANG_PT=11, LANG_ES=12
};

// ─── DIRECTION ENGINE ────────────────────────────────────────────
enum ENUM_DIR_ENGINE    { DIR_VEMA=0, DIR_FIRST_TOUCH=1, DIR_CLASSIC=2 };
enum ENUM_SIGNAL_DIR    { DIR_NEUTRAL=0, DIR_BUY=1, DIR_SELL=2 };
enum ENUM_ENGINE_DEC    { EDEC_GRID=0, EDEC_TREND=1 };

// ─── LOT & MONEY ─────────────────────────────────────────────────
enum ENUM_LOT_TYPE      { LOT_FIXED=0, LOT_AUTO=1 };
enum ENUM_BULLET_LOT    { BLM_AUTO=0, BLM_MANUAL=1, BLM_PROJECT=2 };
enum ENUM_GRID_LOT      { GLM_FIXED=0, GLM_BALANCE_PCT=1, GLM_EQUITY_PCT=2 };
enum ENUM_GRID_TP       { GTP_SPREAD_MULT=0, GTP_BALANCE_PCT=1, GTP_FIXED_PTS=2, GTP_PRICE_PCT=3 };
enum ENUM_GRID_STEP     { GST_FIXED_PTS=0, GST_RANGE_MULT=1, GST_PRICE_PCT=2 };
enum ENUM_GRID_TREND_SRC { VGTS_MICRO_FLOW=0, VGTS_TREND_ENGINE=1 };

// ─── TP-PROJ ─────────────────────────────────────────────────────
enum ENUM_TPP_REGIME    {
   TPP_FIXED=0, TPP_BALANCE_PCT=1, TPP_TARGET_DEFICIT=2,
   TPP_CONTROLLED_REC=3, TPP_NET_VOL=4, TPP_SOLVER=5
};
enum ENUM_TPP_START     { TPP_START_FIXED=0, TPP_START_PROJECTED=1 };
enum ENUM_TPP_GRESET    { TPP_GRESET_KEEP=0, TPP_GRESET_FIXED=1, TPP_GRESET_PROJ=2 };

// ─── DIRECTION FILTERS ───────────────────────────────────────────
enum ENUM_NDI_PROFILE   { NDI_MORE_TRADES=0, NDI_BALANCED=1, NDI_SELECTIVE=2 };
enum ENUM_NDI_FLIP      { NDI_FLIP_NORMAL=0, NDI_FLIP_STRONG=1, NDI_FLIP_VSTRONG=2 };
enum ENUM_AWR_REGIME_SRC { AWR_SRC_VR_TF=0, AWR_SRC_PULSE=1, AWR_SRC_ENSEMBLE=2 };

// ─── VIOP / FUTURES ─────────────────────────────────────────────
enum ENUM_VIOP_DETECT   { VIOP_AUTO=0, VIOP_FORCE_ON=1, VIOP_FORCE_OFF=2 };
enum ENUM_VIOP_ROLLOVER { VIOP_ROLL_OFF=0, VIOP_ROLL_SUGGEST=1, VIOP_ROLL_AUTO=2 };

// ─── TIME FILTERS ───────────────────────────────────────────────
enum ENUM_TIME_ACTION    { TFA_BLOCK_NEW=0, TFA_CLOSE_PROFIT=1, TFA_CLOSE_ALL=2, TFA_NET_HEDGE=3 };
enum ENUM_TIME_CLOCK     { TFC_BROKER=0, TFC_LOCAL=1, TFC_UTC=2 };
enum ENUM_TIME_RESET     { TR_CLOSE_ALL=0, TR_CLOSE_PROFIT=1, TR_CLOSE_LOSS=2 };
enum ENUM_DAILY_SCOPE   { DGS_ROBOT=0, DGS_ACCOUNT=1 };
enum ENUM_DAILY_CLOCK   { DGC_BROKER=0, DGC_LOCAL=1 };

// ─── AUTO TUNE ──────────────────────────────────────────────────
enum ENUM_RISK_PROFILE  {
   RISK_ULTRA_SAFE=0, RISK_CONSERVATIVE=1,
   RISK_BALANCED=2, RISK_AGGRESSIVE=3, RISK_ULTRA_AGGR=4
};

// ─── PERMISSION ─────────────────────────────────────────────────
enum ENUM_DIR_PERM { DPERM_BOTH=0, DPERM_BUY=1, DPERM_SELL=2 };
enum ENUM_PURE_SH_BYPASS { PSB_STRATEGY=0, PSB_ENGINES=1, PSB_NONE=2 };

// ─── FEATURE GATES ─────────────────────────────────────────────
enum ENUM_PCLOSE_FEAT {
   PCF_MASTER, PCF_TREND_FLIP, PCF_AEG, PCF_GRID_TP, PCF_TP_PROJ,
   PCF_GLOBAL_PROFIT, PCF_DAILY_PROFIT, PCF_TIME_FILTER_PROFIT,
   PCF_TIME_LIMIT_PROFIT, PCF_HEDGE_PROFIT, PCF_BONUS_TP,
   PCF_PROFIT_LOCK, PCF_CLOSE_WINNERS, PCF_NEWS_PROFIT, PCF_OTHER
};
enum ENUM_LCLOSE_FEAT {
   LCF_MASTER, LCF_TREND_FLIP, LCF_GLOBAL_LOSS, LCF_DAILY_LOSS,
   LCF_TIME_FILTER_LOSS, LCF_TIME_LIMIT_LOSS, LCF_NEWS_LOSS,
   LCF_VIOP_LOSS, LCF_FORCED_LOSS, LCF_HEDGE_LOSS, LCF_OTHER
};

// ─────────────────────────────────────────────────────────────────────────────
// STRUCTURES
// ─────────────────────────────────────────────────────────────────────────────

struct StagedDecision {
   ENUM_KERNEL_STATE kernel_state;
   ENUM_SIGNAL_DIR   primary_direction;
   ENUM_SIGNAL_DIR   consensus_direction;
   double            direction_score;
   double            quality_score;
   double            entry_score;
   bool              entry_allowed;
   bool              safety_locked;
   string            lock_reason;
   datetime          last_update;
};

struct PositionInfo {
   ulong             ticket;
   ENUM_DIRECTION    type;        // TYPE_BUY / TYPE_SELL
   double            lot;
   double            open_price;
   datetime          open_time;
   double            profit;
   double            swap;
   double            commission;
   ulong             magic;
};

struct GridLevel {
   double            price;
   double            lot;
   ENUM_DIRECTION    type;
   bool              triggered;
   bool              filled;
   ulong             ticket;
   datetime          trigger_time;
};

struct ShadowTrade {
   datetime          open_time;
   ENUM_DIRECTION    type;
   double            lot;
   double            open_price;
   double            current_price;
   double            unrealized_pnl;
   double            target_pnl;
   double            risk_pnl;
   bool              closed;
   double            realized_pnl;
   datetime          close_time;
};

struct NewsEvent {
   datetime          event_time;
   string            currency;
   string            name;
   double            impact;      // 1=Low, 2=Medium, 3=High
   bool              handled;
};

struct VIOPContract {
   string            symbol;
   datetime          expiry_date;
   datetime          first_trade;
   datetime          last_trade;
   double            contract_size;
   bool              is_option;
   bool              is_futures;
};

struct TickData {
   datetime          time;
   double            bid;
   double            ask;
   double            last;
   long              volume;
   double            spread;
};

struct BarData {
   datetime          time;
   double            open;
   double            high;
   double            low;
   double            close;
   long              tick_volume;
   int               spread;
   long              real_volume;
};

//+------------------------------------------------------------------+
//| WRAPPER — TÜM 372 INPUT                                           |
//+------------------------------------------------------------------+
class CNexusInputs {
public:

   // GROUP 1: DISPLAY (2)
   ENUM_LANG          PanelLanguage;
   double             InpPanelScale;

   // GROUP 2: SOUND ALERTS (6)
   bool               SoundAlertsEnabled;
   string             SoundTradeOpen;
   string             SoundProfitClose;
   string             SoundLossClose;
   string             SoundProfitReset;
   string             SoundLossReset;

   // GROUP 3: DOM (4)
   bool               DOM_Enable;
   int                DOM_TopLevels;
   int                DOM_FreshMs;
   double             DOM_Weight;

   // GROUP 4: CPU (2)
   bool               CPU_Optimization;
   int                CPU_SignalRefreshMs;

   // GROUP 5: ML / LIVE (12)
   bool               ML_ONNX_Enable;
   string             ML_ONNX_ModelFile;
   int                ML_UpdateMs;
   int                ML_FeatureCount;
   int                ML_OutputCount;
   double             ML_MinTrendProb;
   double             ML_MinDirectionProb;
   double             ML_Weight;
   bool               ML_FallbackHeuristic;
   bool               ML_ShadowOnly;
   bool               ML_AutoModelReload;
   int                ML_AutoModelReloadSec;

   // GROUP 6: ML DATA LOGGER (7)
   bool               ML_DataLog_Enable;
   string             ML_DataLog_FileName;
   bool               ML_DataLog_AutoPerChart;
   int                ML_DataLog_IntervalMs;
   int                ML_DataLog_LabelHorizonSec;
   double             ML_DataLog_MinMoveATR;
   int                ML_DataLog_MaxPending;

   // GROUP 7: SHADOW TRADE JOURNAL (6)
   bool               ShadowTrade_Enable;
   int                ShadowTrade_MaxAgeSec;
   double             ShadowTrade_TargetATR;
   double             ShadowTrade_RiskATR;
   int                ShadowTrade_RearmSec;
   bool               ShadowTrade_WriteCSV;

   // GROUP 8: DIRECTION ENGINE SELECTOR (10)
   ENUM_DIR_ENGINE    DirectionEngineDefault;
   bool               TrendReverseSignalDefault;
   bool               MicroTrendReverseDefault;
   double             PureShadowSpreadMult;
   ENUM_PURE_SH_BYPASS PureShadowBypassDefault;
   bool               PureShadowPriceFollowEnable;
   double             PureShadowProfitFollowMult;
   bool               PureShadowNetSpreadCloseEnable;
   double             PureShadowNetProfitSpreadMult;
   double             PureShadowNetLossSpreadMult;

   // GROUP 9: VEMA-X (3)
   double             EMA15_FlatSpreadMult;
   int                EMA15_ConfirmBars;
   int                EMA_VirtualBarSeconds;

   // GROUP 10: FIRST TOUCH (8)
   int                FT_LookbackSeconds;
   int                FT_HorizonSeconds;
   int                FT_LaunchEverySeconds;
   double             FT_BarrierSpreadMult;
   double             FT_BarrierMoveMult;
   int                FT_MinResolved;
   double             FT_MinProbability;
   double             FT_ConfidenceZ;

   // GROUP 11: CLASSIC LIVE (10)
   int                ClassicLiveWindowSeconds;
   int                ClassicLiveFastSeconds;
   int                ClassicLiveWarmupSeconds;
   int                ClassicLiveEntryConfirmMs;
   int                ClassicLiveFlipConfirmMs;
   double             ClassicLiveDirectionGate;
   double             ClassicLiveEfficiencyGate;
   double             ClassicLivePullbackMin;
   double             ClassicLivePullbackMax;
   double             ClassicLiveReclaimRatio;

   // GROUP 12: MAIN TRADING (14)
   bool               EnableGlobalTrading;
   bool               EnableBuy;
   bool               EnableSell;
   ENUM_DIR_PERM      GridDirectionPermission;
   ENUM_DIR_PERM      TrendDirectionPermission;
   bool               EnableSpreadProtection;
   int                MaxAllowedSpread;
   bool               EnableSlippageProtection;
   int                MaxSlippage;
   int                MaxResetCount;
   double             GlobalProfitPct;
   double             GlobalLossPct;
   bool               WithdrawalNeutralForLossReset;
   bool               AllowResetWhenPaused;

   // GROUP 13: BASIC LOT (3)
   ENUM_LOT_TYPE      LotType;
   double             FixedLot;
   double             AutoLotPct;

   // GROUP 14: LOT CUT (3)
   int                LotPenaltyStepResets;
   double             LotPenaltyStepPct;
   double             LotPenaltyMinPct;

   // GROUP 15: TIME LOT BOOST (4)
   bool               EnableTimedLotBoost;
   int                LotBoostStepHours;
   double             LotBoostStepPct;
   double             LotBoostMaxPct;

   // GROUP 16: DRAWDOWN HEDGE (5)
   bool               EnableAutoDDHedge;
   bool               EnableMultiSymbolHedge;
   double             AutoDDHedgePct;
   double             DDHedgeExitProfit;
   bool               DDHedgePauseTrading;

   // GROUP 17: TREND ENGINE (28)
   ENUM_BULLET_LOT    BulletLotMode;
   double             BulletLotValue;
   ENUM_TPP_REGIME    TPProjVolumeRegime;
   ENUM_TPP_START     TPProjStartMode;
   ENUM_TPP_GRESET    TPProjAfterProfitReset;
   ENUM_TPP_GRESET    TPProjAfterLossReset;
   bool               Bullet_AutoVolume;
   bool               Bullet_LossBlockEnable;
   int                Bullet_LossBlockCount;
   int                Bullet_SampleSec;
   int                Bullet_ConfirmCount;
   double             Bullet_Sensitivity;
   double             Bullet_TolerancePricePct;
   double             Bullet_HardRiskPct;
   int                Bullet_ProfitIncubationSec;
   int                Bullet_LossIncubationSec;
   int                Bullet_FlipCooldownSec;
   int                Bullet_ProfitCooldownAfterCount;
   int                Bullet_LossCooldownSec;
   int                Bullet_LossCooldownAfterCount;
   bool               Bullet_BonusTPEnable;
   double             Bullet_BonusTP_Mult;
   bool               Bullet_ProfitLockEnable;
   double             Bullet_ProfitLockPullbackPct;
   int                Bullet_EntryConfirmTicks;
   bool               Bullet_EntryQualityEnable;
   int                Bullet_EntryQualityMinScore;
   double             Bullet_MinEdgeSpreadMult;

   // GROUP 18: HEG (12)
   bool               HEG_Enable;
   int                HEG_ScoutEdgeScore;
   int                HEG_FullEdgeScore;
   double             HEG_ScoutLotPct;
   int                HEG_FastAbortSec;
   double             HEG_FastAbortATR;
   bool               HEG_VirtualScout;
   bool               HEG_VirtualFastPromote;
   double             HEG_VirtualFastPromoteR;
   double             HEG_VirtualInvalidateR;
   double             HEG_VirtualNoChaseR;
   int                HEG_VirtualMaxAgeSec;

   // GROUP 19: AEG (7)
   bool               AEG_Enable;
   int                AEG_MinHoldSec;
   double             AEG_HardLossBandMult;
   double             AEG_ProfitFloorBandMult;
   double             AEG_ProfitRunBandMult;
   double             AEG_ProfitRunPullbackPct;
   double             AEG_SupportStrengthGate;

   // GROUP 20: DTE (8)
   bool               DTE_Enable;
   int                DTE_MinSamples;
   double             DTE_MetaEdgePenalty;
   double             DTE_MetaEdgeBoost;
   double             DTE_ScoutOnlyPenalty;
   double             DTE_LateEntryAdverseRatio;
   double             DTE_NoiseMaxATR;
   double             DTE_EwmaAlpha;

   // GROUP 21: NDI (3)
   bool               NDI_Enable;
   ENUM_NDI_PROFILE   NDI_Profile;
   ENUM_NDI_FLIP      NDI_FlipSafety;

   // GROUP 22: CONSENSUS (7)
   bool               Bullet_TrendConsensusEnable;
   int                Bullet_TrendConsensusMinVotes;
   bool               Bullet_BlockDITMIConflict;
   bool               Bullet_AllowEarlyTMI;
   bool               Bullet_RequireAegisForEarly;
   double             Bullet_EarlyTMIConfidenceExtra;
   double             Bullet_AegisConfirmThreshold;

   // GROUP 23: LOSS SAFETY (6)
   bool               Bullet_RepeatLossGuardEnable;
   int                Bullet_SameSideLossLimit;
   int                Bullet_LossQualityStep;
   int                Bullet_AccountSameSideMax;
   bool               Bullet_RequireFreshSignalAfterLoss;
   bool               Bullet_FreezeTPProjLotOnLossStreak;

   // GROUP 24: AWR (16)
   bool               AWR_Enable;
   int                AWR_HorizonMin;
   int                AWR_TargetBars;
   int                AWR_qMin;
   double             AWR_VR_RangeBand;
   double             AWR_VR_TrendBand;
   double             AWR_BreakoutATR;
   int                AWR_FlipWindow;
   double             AWR_LossFracThresh;
   double             AWR_LotDecayFloor;
   bool               AWR_TightenLockInRange;
   double             AWR_RangeLockPullbackPct;
   int                AWR_RangeWatchdogMin;
   int                AWR_FlipStaleMin;
   bool               AWR_Hurst_Enable;
   double             AWR_Hurst_Band;

   // GROUP 25: TREND/RANGE DATA SOURCE (6)
   ENUM_AWR_REGIME_SRC AWR_RegimeSource;
   int                PULSE_TickWindow;
   double             PULSE_CrossDensRange;
   double             PULSE_CrossDensTrend;
   double             PULSE_BreakoutFrac;
   int                PULSE_MinTicks;

   // GROUP 26: DI (10)
   bool               DI_Enable;
   int                DI_TickWindow;
   int                DI_MinTicks;
   double             DI_TrendScore;
   double             DI_RangeScore;
   double             DI_MinEfficiency;
   double             DI_DirDeadZone;
   double             DI_BreakoutFrac;
   double             DI_SmoothAlpha;
   bool               DI_PrintChanges;

   // GROUP 27: DI EXTRA (13)
   bool               DI_FusionEnable;
   double             DI_Weight_Score;
   double             DI_Weight_Hurst;
   double             DI_Weight_VR;
   double             DI_HurstBand;
   double             DI_VRBand;
   int                DI_VR_Lag;
   bool               DI_MultiScaleEff;
   double             DI_DenoiseSpreadMult;
   bool               DI_AdaptiveThresh;
   double             DI_AdaptiveZ;
   double             DI_AdaptiveMix;
   bool               DI_FreezeBreakout;

   // GROUP 28: TMI (10)
   bool               TMI_Enable;
   int                TMI_FastTicks;
   int                TMI_MidTicks;
   double             TMI_ConfidenceGate;
   double             TMI_EarlyGate;
   double             TMI_MinImpulseATR;
   double             TMI_BreakoutATR;
   double             TMI_ReversalRiskGate;
   bool               TMI_UseTradeFeedback;
   bool               TMI_PrintChanges;

   // GROUP 29: UDC (1)
   bool               UDC_Log;

   // GROUP 30: MIN DISTANCE (4)
   bool               MinDist_Enable;
   double             MinDist_Points;
   bool               MinDist_AllEngines;
   bool               MinDist_Log;

   // GROUP 31: GRID ENGINE (38)
   bool               VG_Enable;
   bool               VG_InstantStartOnFlat;
   bool               VG_NettingSingleSide;
   bool               VG_NettingStartOnFlat;
   bool               VG_TPAuthority;
   bool               VG_TPManageStrictOff;
   bool               VG_TrendAdaptiveDirection;
   ENUM_GRID_TREND_SRC VG_TrendSource;
   double             VG_TrendMicroSpreadMult;
   bool               VG_PyramidBuy;
   bool               VG_PyramidSell;
   bool               VG_LoopHarvestEnable;
   double             VG_LoopMinNetSpreadMult;
   bool               VG_EscapeFundEnable;
   double             VG_EscapeFundSharePct;
   double             VG_EscapeDeployPct;
   double             VG_EscapeRewardRisk;
   double             VG_EscapeBankCapPct;
   double             VG_EscapeMaxGridLotMult;
   ENUM_GRID_LOT      VG_LotMode;
   double             VG_LotValue;
   ENUM_GRID_TP       VG_TPMode;
   double             VG_TPValue;
   ENUM_GRID_STEP     VG_StepMode;
   double             VG_StepValue;
   double             VG_BuyStepValue;
   double             VG_SellStepValue;
   int                VG_RangeSamples;
   bool               VG_StopNewEntriesOnTrend;
   bool               VG_CloseProfitsOnTrend;
   int                VG_MagicBuy;
   int                VG_MagicSell;
   double             Bullet_VolMinMult;
   double             Bullet_VolMaxMult;
   int                Bullet_MoveWindowMin;
   int                Bullet_MoveRefreshSec;
   bool               Bullet_MoveSpikeAware;
   double             Bullet_MoveDirFactor;

   // GROUP 32: AUTO TUNE (11)
   bool               EnableBulletAutoTune;
   int                BAT_MinSamples;
   int                BAT_RecalcEveryFlips;
   double             BAT_StepPct;
   bool               BAT_AutoRevertOnWorse;
   bool               BAT_VerboseLog;
   double             BAT_LossCluster_TroughRatio;
   double             BAT_R2_HighThr;
   double             BAT_R2_LowThr;
   double             BAT_BadHour_LossRate;
   int                BAT_BadHour_MinTrades;

   // GROUP 33: NEWS FILTER (13)
   bool               NF_Enable;
   bool               NF_OnlyHighImpact;
   bool               NF_MediumImpact;
   int                NF_MinutesBefore;
   int                NF_MinutesAfter;
   string             NF_CurrencyFilter;
   bool               NF_PauseTrading;
   bool               NF_HedgeBeforeNews;
   bool               NF_CloseAllBeforeNews;
   bool               NF_CloseHedgeAfterNews;
   bool               NF_CloseHedgeOnLoss;
   double             NF_HedgeExitProfit;
   bool               NF_ShowPanel;

   // GROUP 34: WEEKLY SCHEDULE (32)
   bool               EnableWeeklySchedule;
   ENUM_TIME_ACTION   WeeklyScheduleAction;
   ENUM_TIME_CLOCK    WeeklyScheduleClock;
   int                WeeklyScheduleResumeDelaySec;
   string             Mon_P1, Mon_P2, Mon_P3, Mon_P4;
   string             Tue_P1, Tue_P2, Tue_P3, Tue_P4;
   string             Wed_P1, Wed_P2, Wed_P3, Wed_P4;
   string             Thu_P1, Thu_P2, Thu_P3, Thu_P4;
   string             Fri_P1, Fri_P2, Fri_P3, Fri_P4;
   string             Sat_P1, Sat_P2, Sat_P3, Sat_P4;
   string             Sun_P1, Sun_P2, Sun_P3, Sun_P4;

   // GROUP 35: VIOP / FUTURES (17)
   ENUM_VIOP_DETECT   VIOP_DetectionMode;
   bool               VIOP_EnableSessionControl;
   bool               VIOP_UseBrokerSessionTimes;
   bool               VIOP_UseFixedTimesFallback;
   int                VIOP_Close_Hour;
   int                VIOP_Close_Min;
   int                VIOP_Open_Hour;
   int                VIOP_Open_Min;
   int                VIOP_GapWaitMinutes;
   bool               VIOP_EnableExpiryProtection;
   int                VIOP_BlockNewHoursBeforeExpiry;
   bool               VIOP_ForceCloseBeforeExpiry;
   int                VIOP_ForceCloseMinutesBeforeExpiry;
   bool               VIOP_BlockOptionSymbols;
   ENUM_VIOP_ROLLOVER VIOP_RolloverMode;
   int                VIOP_RolloverSearchDays;
   int                VIOP_AutoSwitchHoursBeforeExpiry;

   // GROUP 36: TRADE ID NUMBERS (10)
   string             MagicChartSuffix;
   int                MagicBuy;
   int                MagicSell;
   int                MagicGridEscapeBuy;
   int                MagicGridEscapeSell;
   int                MagicNFHedge;
   int                MagicManualHedge;
   int                MagicDDEdge;
   int                MagicDynHedge;
   int                MagicTimeHedge;

   // GROUP 37: VIRTUAL TP (2)
   bool               EnableAlternatingTP;
   double             VirtualTPPct;

   // GROUP 38: DAILY LOCK (8)
   bool               DailyProfitLockEnable;
   double             DailyProfitTargetPct;
   bool               DailyLossLockEnable;
   double             DailyLossTargetPct;
   ENUM_DAILY_SCOPE   DailyLockScope;
   ENUM_DAILY_CLOCK   DailyClockMode;
   int                DailyRestartHour;
   int                DailyRestartMinute;

   // GROUP 39: AUTO COST (3)
   bool               EnableAutoSpread;
   double             AutoSpreadSpikePct;
   double             AutoSlippagePct;

   // GROUP 40: TIME RESET (6)
   bool               EnableForcedReset;
   int                ForcedResetHours;
   bool               EnableTimeLimitReset;
   int                TimeLimitMinutes;
   ENUM_TIME_RESET    TimeResetAction;
   bool               PauseAfterTimeLimit;

   // GROUP 41: REOPEN (1)
   bool               AllowReopenNeutral;

   // GROUP 42: RISK STYLE (1)
   ENUM_RISK_PROFILE  AutoTune_RiskProfile;

   // ─── Helper: Magic numaralarını suffix ile hesapla ───────────────
   int GetMagicBuy()    { return (int)StringToInteger(MagicBuy   + MagicChartSuffix); }
   int GetMagicSell()   { return (int)StringToInteger(MagicSell  + MagicChartSuffix); }
   int GetMagicGridBuy(){ return (int)StringToInteger(MagicGridEscapeBuy + MagicChartSuffix); }
   int GetMagicGridSell(){ return (int)StringToInteger(MagicGridEscapeSell + MagicChartSuffix); }
   int GetMagicNFHedge(){ return (int)StringToInteger(MagicNFHedge + MagicChartSuffix); }
   int GetMagicManualHedge(){ return (int)StringToInteger(MagicManualHedge + MagicChartSuffix); }
   int GetMagicDDHedge(){ return (int)StringToInteger(MagicDDEdge + MagicChartSuffix); }
   int GetMagicDynHedge(){ return (int)StringToInteger(MagicDynHedge + MagicChartSuffix); }
   int GetMagicTimeHedge(){ return (int)StringToInteger(MagicTimeHedge + MagicChartSuffix); }
};
