//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — VIOP / Futures Manager                      |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>

//+------------------------------------------------------------------+
//| VIOP Contract Info                                                 |
//+------------------------------------------------------------------+
struct VIOPInfo {
   string            symbol;
   datetime          expiry_date;
   datetime          first_trade_date;
   datetime          last_trade_date;
   double            contract_size;
   double            point_value;
   bool               is_option;
   bool               is_futures;
   int               days_to_expiry;
};

class CVIOPManager {
private:
   CNexusInputs&     m_inputs;
   string            m_symbol;
   VIOPInfo          m_contract;
   bool               m_detected;
   bool               m_session_open;
   bool               m_gap_wait;
   datetime          m_session_open_time;
   datetime          m_last_gap_check;
   datetime          m_expiry_warning_time;
   bool               m_expiry_warning_issued;
   
public:
   CVIOPManager(CNexusInputs& inputs, string symbol)
      : m_inputs(inputs), m_symbol(symbol) {
      m_detected = false;
      m_session_open = false;
      m_gap_wait = false;
      m_session_open_time = 0;
      m_last_gap_check = 0;
      m_expiry_warning_time = 0;
      m_expiry_warning_issued = false;
   }
   
   void Initialize() {
      if(m_inputs.VIOP_DetectionMode == VIOP_FORCE_OFF) {
         Print("[VIOP] Detection disabled by user");
         return;
      }
      Detect();
   }
   
   // ─── VIOP Detection ────────────────────────────────────────────
   bool Detect() {
      if(m_inputs.VIOP_DetectionMode == VIOP_FORCE_OFF) {
         m_detected = false;
         return false;
      }
      
      string sym = m_symbol;
      
      // Futures indicators in symbol name
      bool is_futures = false;
      string futures_patterns[] = {"6E", "6B", "6J", "6A", "6N", "6C",
                                   "CL", "NG", "GC", "SI", "ES", "NQ", "YM",
                                   "XU", "X30", "VX", "ZT", "ZB", "ZN"};
      
      for(int i = 0; i < ArraySize(futures_patterns); i++) {
         if(StringFind(sym, futures_patterns[i]) >= 0) {
            is_futures = true;
            break;
         }
      }
      
      // Turkish futures pattern (BIST)
      if(StringFind(sym, "VI") >= 0 || StringFind(sym, "XU") >= 0 ||
         StringFind(sym, "30") >= 0) {
         is_futures = true;
      }
      
      // Also check via SymbolInfo
      ENUM_SYMBOL_TRADE_MODE trade_mode;
      long sym_type = SymbolInfoInteger(m_symbol, SYMBOL_TRADE_MODE);
      // futures symbols have specific characteristics
      double contract_size = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_CONTRACT_SIZE);
      if(contract_size > 10000) is_futures = true;
      
      if(is_futures || m_inputs.VIOP_DetectionMode == VIOP_FORCE_ON) {
         m_detected = true;
         m_contract.symbol = m_symbol;
         m_contract.is_futures = true;
         m_contract.is_option = StringFind(m_symbol, "OP") >= 0;
         m_contract.contract_size = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_CONTRACT_SIZE);
         m_contract.point_value = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_VALUE);
         
         // Get expiry from symbol or settings
         m_contract.expiry_date = DetectExpiry();
         m_contract.days_to_expiry = (int)((m_contract.expiry_date - TimeCurrent()) / 86400);
         
         Print("[VIOP] Detected: ", m_contract.symbol,
               " | ContractSize=", DoubleToString(m_contract.contract_size, 0),
               " | Expiry=", m_contract.expiry_date,
               " | DaysToExpiry=", m_contract.days_to_expiry);
         return true;
      }
      
      m_detected = false;
      return false;
   }
   
   datetime DetectExpiry() {
      // Try to detect expiry from symbol name
      // e.g., 6EZ24 -> December 2024
      string sym = m_symbol;
      int year = (int)StringToInteger(StringSubstr(sym, StringLen(sym) - 4, 2)) + 2000;
      int month = 3; // Default quarterly
      
      // Look for month letter
      if(StringFind(sym, "F") >= 0) month = 1;   // Jan
      else if(StringFind(sym, "G") >= 0) month = 2;  // Feb
      else if(StringFind(sym, "H") >= 0) month = 3;  // Mar
      else if(StringFind(sym, "J") >= 0) month = 4;  // Apr
      else if(StringFind(sym, "K") >= 0) month = 5;  // May
      else if(StringFind(sym, "M") >= 0) month = 6;  // Jun
      else if(StringFind(sym, "N") >= 0) month = 7;  // Jul
      else if(StringFind(sym, "Q") >= 0) month = 8;  // Aug
      else if(StringFind(sym, "U") >= 0) month = 9;  // Sep
      else if(StringFind(sym, "V") >= 0) month = 10; // Oct
      else if(StringFind(sym, "X") >= 0) month = 11; // Nov
      else if(StringFind(sym, "Z") >= 0) month = 12; // Dec
      
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      dt.year = year;
      dt.mon = month;
      dt.day = 1;
      dt.hour = 18; // Typically last trading day
      dt.min = 0;
      dt.sec = 0;
      
      return StructToTime(dt);
   }
   
   // ─── Update ───────────────────────────────────────────────────
   void Update() {
      if(!m_detected || !m_inputs.VIOP_EnableSessionControl) return;
      
      datetime now = TimeCurrent();
      MqlDateTime broker_time;
      TimeToStruct(now, broker_time);
      
      // Check session using broker times
      if(m_inputs.VIOP_UseBrokerSessionTimes) {
         CheckBrokerSession(now);
      } else if(m_inputs.VIOP_UseFixedTimesFallback) {
         CheckFixedSession(broker_time);
      }
      
      // Gap check
      if(m_session_open && !m_gap_wait) {
         CheckGap(now);
      }
      
      // Expiry protection
      if(m_inputs.VIOP_EnableExpiryProtection) {
         CheckExpiryProtection(now);
      }
   }
   
   void CheckBrokerSession(datetime now) {
      // Use SymbolInfoSessionTrade to get actual broker session
      MqlDateTime dt;
      TimeToStruct(now, dt);
      
      datetime open_time = StringToTime(StringFormat("%04d.%02d.%02d %02d:%02d:00",
         dt.year, dt.mon, dt.day,
         m_inputs.VIOP_Open_Hour, m_inputs.VIOP_Open_Min));
      
      datetime close_time = StringToTime(StringFormat("%04d.%02d.%02d %02d:%02d:00",
         dt.year, dt.mon, dt.day,
         m_inputs.VIOP_Close_Hour, m_inputs.VIOP_Close_Min));
      
      if(now >= open_time && now < close_time) {
         if(!m_session_open) {
            m_session_open = true;
            m_session_open_time = now;
            Print("[VIOP] Session OPEN: ", open_time, " - ", close_time);
         }
      } else {
         if(m_session_open) {
            m_session_open = false;
            m_gap_wait = false;
            Print("[VIOP] Session CLOSED");
         }
      }
   }
   
   void CheckFixedSession(MqlDateTime& dt) {
      int current_minutes = dt.hour * 60 + dt.min;
      int open_minutes = m_inputs.VIOP_Open_Hour * 60 + m_inputs.VIOP_Open_Min;
      int close_minutes = m_inputs.VIOP_Close_Hour * 60 + m_inputs.VIOP_Close_Min;
      
      if(current_minutes >= open_minutes && current_minutes < close_minutes) {
         m_session_open = true;
      } else {
         m_session_open = false;
         m_gap_wait = false;
      }
   }
   
   void CheckGap(datetime now) {
      if(m_inputs.VIOP_GapWaitMinutes <= 0) return;
      if(!m_session_open) return;
      
      datetime session_start = m_session_open_time;
      if(now - session_start < (datetime)(m_inputs.VIOP_GapWaitMinutes * 60)) {
         m_gap_wait = true;
         if(now - m_last_gap_check > 60) {
            Print("[VIOP] GAP WAIT — Waiting ", m_inputs.VIOP_GapWaitMinutes,
                  " min for gap stabilization");
            m_last_gap_check = now;
         }
      } else {
         if(m_gap_wait) {
            m_gap_wait = false;
            Print("[VIOP] Gap wait ended — normal trading");
         }
      }
   }
   
   void CheckExpiryProtection(datetime now) {
      if(m_contract.expiry_date == 0) return;
      
      int hours_to_expiry = (int)((m_contract.expiry_date - now) / 3600);
      
      // Warning
      if(hours_to_expiry <= 72 && hours_to_expiry > 0 && !m_expiry_warning_issued) {
         Print("[VIOP] ⚠️ WARNING: Expiry in ", hours_to_expiry, " hours");
         m_expiry_warning_issued = true;
      }
      
      // Block new entries
      if(hours_to_expiry <= m_inputs.VIOP_BlockNewHoursBeforeExpiry && hours_to_expiry > 0) {
         // This would trigger a safety lock
         Print("[VIOP] BLOCKING new entries — expiry in ",
               hours_to_expiry, " hours");
      }
      
      // Force close
      if(m_inputs.VIOP_ForceCloseBeforeExpiry) {
         int minutes_to_expiry = (int)((m_contract.expiry_date - now) / 60);
         if(minutes_to_expiry <= m_inputs.VIOP_ForceCloseMinutesBeforeExpiry &&
            minutes_to_expiry > 0) {
            Print("[VIOP] ⚠️ FORCE CLOSE triggered — expiry in ",
                  minutes_to_expiry, " minutes");
            // CloseAllPositions(CR_VIOP_EXPIRY);
         }
      }
   }
   
   // ─── Manage Session ────────────────────────────────────────────
   void ManageSession() {
      if(!m_detected) return;
      Update();
   }
   
   // ─── Rollover Management ─────────────────────────────────────
   void CheckRollover() {
      if(m_inputs.VIOP_RolloverMode == VIOP_ROLL_OFF) return;
      if(m_contract.days_to_expiry > 7) return;
      
      // Find next contract
      string next_symbol = FindNextContract();
      
      if(next_symbol != "") {
         Print("[VIOP] ROLLOVER: Current=", m_contract.symbol,
               " Next=", next_symbol);
         
         switch(m_inputs.VIOP_RolloverMode) {
            case VIOP_ROLL_SUGGEST:
               Print("[VIOP] SUGGESTION: Switch to ", next_symbol,
                     " (manual action required)");
               break;
            case VIOP_ROLL_AUTO:
               // Auto switch logic
               Print("[VIOP] AUTO SWITCH: Switching to ", next_symbol);
               // SwitchSymbol(next_symbol);
               break;
         }
      }
   }
   
   string FindNextContract() {
      // Find next month's futures contract
      string base = StringSubstr(m_symbol, 0, StringLen(m_symbol) - 4);
      // This is a simplified implementation
      // Real implementation would search symbol list
      return "";
   }
   
   bool IsSessionOpen() { return m_session_open && !m_gap_wait; }
   bool IsInGapWait() { return m_gap_wait; }
   bool IsDetected() { return m_detected; }
   VIOPInfo GetContractInfo() { return m_contract; }
};
