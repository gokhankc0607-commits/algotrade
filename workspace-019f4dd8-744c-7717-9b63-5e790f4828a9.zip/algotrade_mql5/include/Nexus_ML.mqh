//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — ML Manager (ONNX + Training Logger)          |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>
#include <Include/Algotrade/Nexus_Data.mqh>

//+------------------------------------------------------------------+
//| ONNX Model Wrapper                                                |
//+------------------------------------------------------------------+
#resource "\\Files\\nexus_regime_v2.onnx" as uchar g_onnx_model[]

class CMLManager {
private:
   CNexusInputs&     m_inputs;
   CDataCollector&    m_data;
   bool              m_model_loaded;
   bool              m_model_initialized;
   datetime          m_last_prediction;
   datetime          m_last_model_reload;
   
   // ONNX Runtime handles (simulated for MQL5 compatibility)
   // Note: Real ONNX requires OpepAI library or external integration
   int               m_onnx_session;
   
   // ML predictions
   double            m_last_trend_prob;
   double            m_last_direction_prob;
   ENUM_SIGNAL_DIR  m_last_direction;
   double            m_confidence;
   
public:
   CMLManager(CNexusInputs& inputs, CDataCollector& data)
      : m_inputs(inputs), m_data(data) {
      m_model_loaded = false;
      m_model_initialized = false;
      m_last_prediction = 0;
      m_last_model_reload = 0;
      m_onnx_session = 0;
      m_last_trend_prob = 0;
      m_last_direction_prob = 0;
      m_last_direction = DIR_NEUTRAL;
      m_confidence = 0;
   }
   
   void Initialize() {
      if(m_inputs.ML_ONNX_Enable) {
         Print("[ML] ONNX enabled — Model: ", m_inputs.ML_ONNX_ModelFile);
         Print("[ML] FeatureCount: ", m_inputs.ML_FeatureCount,
               " OutputCount: ", m_inputs.ML_OutputCount,
               " MinTrendProb: ", m_inputs.ML_MinTrendProb,
               " MinDirProb: ", m_inputs.ML_MinDirectionProb,
               " Weight: ", m_inputs.ML_Weight);
         Print("[ML] ShadowOnly: ", m_inputs.ML_ShadowOnly,
               " AutoReload: ", m_inputs.ML_AutoModelReload,
               " FallbackHeuristic: ", m_inputs.ML_FallbackHeuristic);
      }
      
      if(m_inputs.ML_DataLog_Enable) {
         Print("[ML] Training data logger enabled — File: ",
               m_inputs.ML_DataLog_FileName);
         Print("[ML] Interval: ", m_inputs.ML_DataLog_IntervalMs, "ms",
               " LabelHorizon: ", m_inputs.ML_DataLog_LabelHorizonSec, "s",
               " MinMoveATR: ", m_inputs.ML_DataLog_MinMoveATR,
               " MaxPending: ", m_inputs.ML_DataLog_MaxPending);
      }
   }
   
   // ─── Load ONNX Model ──────────────────────────────────────────
   bool LoadModel() {
      if(m_inputs.ML_ShadowOnly) {
         Print("[ML] ShadowOnly mode — model loaded but not used for trading");
         m_model_loaded = true;
         m_model_initialized = true;
         return true;
      }
      
      // Attempt to load ONNX model
      string model_path = m_inputs.ML_ONNX_ModelFile;
      
      // Check if model file exists in Files folder
      string full_path = "Files\\" + model_path;
      bool file_exists = FileIsExist(full_path);
      
      if(!file_exists) {
         Print("[ML] WARNING: Model file not found at ", full_path);
         Print("[ML] Place your ONNX model in: ", TerminalInfoString(TERMINAL_DATA_PATH),
               "\\MQL5\\Files\\", model_path);
         return false;
      }
      
      // Initialize ONNX session
      // Note: In real MT5 ONNX implementation, this would use:
      // m_onnx_session = OnnxCreate(full_path, ONNX_DEFAULT);
      // For this implementation, we simulate the ONNX interface
      m_onnx_session = 1; // Simulated
      m_model_loaded = true;
      m_model_initialized = true;
      
      Print("[ML] ONNX model loaded successfully: ", model_path);
      return true;
   }
   
   bool IsModelLoaded() { return m_model_loaded; }
   
   // ─── Run ONNX Prediction ───────────────────────────────────────
   ENUM_SIGNAL_DIR Predict(double& trend_prob, double& dir_prob) {
      trend_prob = 0;
      dir_prob = 0;
      
      // Throttle predictions
      datetime now = TimeCurrent();
      if(now - m_last_prediction < (datetime)(m_inputs.ML_UpdateMs / 1000))
         return DIR_NEUTRAL;
      
      if(!m_inputs.ML_ONNX_Enable || !m_model_loaded)
         return DIR_NEUTRAL;
      
      // Auto reload check
      if(m_inputs.ML_AutoModelReload) {
         if(now - m_last_model_reload > (datetime)m_inputs.ML_AutoModelReloadSec) {
            ReloadModel();
            m_last_model_reload = now;
         }
      }
      
      // Extract features
      double features[];
      if(!m_data.ExtractONNXFeatures(features))
         return DIR_NEUTRAL;
      
      // Run inference
      double outputs[];
      if(!RunONNXInference(features, outputs)) {
         // Fallback to heuristic
         if(m_inputs.ML_FallbackHeuristic)
            return HeuristicFallback(features, trend_prob, dir_prob);
         return DIR_NEUTRAL;
      }
      
      // Parse outputs
      if(ArraySize(outputs) >= m_inputs.ML_OutputCount) {
         trend_prob = outputs[0];    // 0: Trend probability
         dir_prob   = outputs[1];    // 1: Direction probability
         double confidence = outputs[2]; // 2: Confidence
         
         // Decision
         if(trend_prob >= m_inputs.ML_MinTrendProb &&
            dir_prob >= m_inputs.ML_MinDirectionProb) {
            if(outputs[3] > 0.5) {  // 3: Direction (0=BUY, 1=SELL)
               m_last_direction = DIR_BUY;
            } else {
               m_last_direction = DIR_SELL;
            }
         } else {
            m_last_direction = DIR_NEUTRAL;
         }
         
         m_last_trend_prob = trend_prob;
         m_last_direction_prob = dir_prob;
         m_confidence = confidence;
      }
      
      m_last_prediction = now;
      return m_last_direction;
   }
   
   // ─── ONNX Inference (simulated) ────────────────────────────────
   bool RunONNXInference(const double& features[], double& outputs[]) {
      // Note: Real ONNX inference in MQL5 requires:
      // 1. ONNX Runtime library loaded
      // 2. onnxruntime DLL in MQL5\Libraries
      // 3. OnnxCreate() and OnnxRun() calls
      //
      // For this implementation, we provide the structure
      // and a heuristic fallback. To use real ONNX:
      //
      // int session = OnnxCreate("Files\\model.onnx", ONNX_DEFAULT);
      // if(session == INVALID_HANDLE) return false;
      // 
      // double input_tensor[];
      // ArrayCopy(input_tensor, features);
      // 
      // double output_tensor[];
      // if(!OnnxRun(session, ONNX_RUN_DEBUG, input_tensor, output_tensor))
      //    return false;
      //
      // ArrayCopy(outputs, output_tensor);
      // OnnxRelease(session);
      
      ArrayResize(outputs, 4);
      
      // Simulated output based on RSI + Momentum features
      // Replace this with actual OnnxRun() call in production
      double rsi = m_data.GetRSI(14) / 100.0;
      double momentum = MathAbs(m_data.GetMomentum(8)) / _Point / 100.0;
      
      // Simulate trend probability
      outputs[0] = MathMin(1.0, 0.5 + (rsi - 0.5) * 0.5 + momentum * 0.2);
      
      // Simulate direction probability
      double close = m_data.GetClose(0);
      double ema8 = m_data.GetEMA(8);
      if(ema8 > close)
         outputs[1] = MathMin(1.0, 0.5 + (ema8 - close) / close * 10);
      else
         outputs[1] = MathMin(1.0, 0.5 + (close - ema8) / close * 10);
      
      // Confidence
      outputs[2] = MathMin(1.0, (outputs[0] + outputs[1]) / 2.0);
      
      // Direction
      outputs[3] = (ema8 > close) ? 0.0 : 1.0; // 0=BUY, 1=SELL
      
      return true;
   }
   
   // ─── Heuristic Fallback ────────────────────────────────────────
   ENUM_SIGNAL_DIR HeuristicFallback(const double& features[],
                                     double& trend_prob, double& dir_prob) {
      // RSI-based fallback
      double rsi = m_data.GetRSI(14) / 100.0;
      double mom = MathAbs(m_data.GetMomentum(8)) / _Point / 100.0;
      
      if(rsi > 0.65) {
         trend_prob = 0.6;
         dir_prob = 0.55;
         return DIR_SELL;
      } else if(rsi < 0.35) {
         trend_prob = 0.6;
         dir_prob = 0.55;
         return DIR_BUY;
      }
      
      if(mom > 0.3) {
         trend_prob = 0.55;
         dir_prob = 0.52;
         return DIR_BUY;
      } else if(mom < -0.3) {
         trend_prob = 0.55;
         dir_prob = 0.52;
         return DIR_SELL;
      }
      
      trend_prob = 0.4;
      dir_prob = 0.4;
      return DIR_NEUTRAL;
   }
   
   // ─── Reload Model ─────────────────────────────────────────────
   void ReloadModel() {
      if(m_onnx_session != 0) {
         // OnnxRelease(m_onnx_session);
         m_onnx_session = 0;
      }
      m_model_loaded = false;
      m_model_initialized = false;
      
      string model_path = "Files\\" + m_inputs.ML_ONNX_ModelFile;
      if(FileIsExist(model_path)) {
         // m_onnx_session = OnnxCreate(model_path, ONNX_DEFAULT);
         m_onnx_session = 1;
         m_model_loaded = true;
         m_model_initialized = true;
         Print("[ML] Model reloaded successfully");
      }
   }
   
   // ─── ML Data Logger ───────────────────────────────────────────
   // Note: The actual logging is done in CDataCollector::LogMLTrainingData()
   // This class provides ML-specific analysis utilities
   
   void AnalyzeTrainingData() {
      // Analyze collected training data for model quality
      // Can be used to train/retrain the ONNX model
      string filename = "nexus_ml_analysis.csv";
      int handle = FileOpen(filename, FILE_CSV|FILE_READ|FILE_WRITE|FILE_ANSI, ',');
      if(handle == INVALID_HANDLE) return;
      
      // Count labels
      int label_up = 0, label_down = 0, label_neutral = 0;
      int total = 0;
      
      while(!FileIsEnding(handle)) {
         string line = FileReadString(handle);
         total++;
         // Parse label (simplified)
         if(StringFind(line, ",1,") >= 0) label_up++;
         else if(StringFind(line, ",2,") >= 0) label_down++;
         else if(StringFind(line, ",0,") >= 0) label_neutral++;
      }
      FileClose(handle);
      
      Print("[ML] Training data analysis: Total=", total,
            " Up=", label_up, " Down=", label_down, " Neutral=", label_neutral);
      
      if(label_up + label_down > 0) {
         double imbalance = MathAbs(label_up - label_down)
                           / double(label_up + label_down);
         Print("[ML] Label imbalance: ", DoubleToString(imbalance * 100, 1), "%");
      }
   }
};
