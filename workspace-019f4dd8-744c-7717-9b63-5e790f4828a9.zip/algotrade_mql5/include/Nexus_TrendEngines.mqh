//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — Trend/Direction Engines                     |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>
#include <Include/Algotrade/Nexus_Data.mqh>

//+------------------------------------------------------------------+
//| Trend Engines Class                                               |
//+------------------------------------------------------------------+
class CTrendEngines {
private:
   CNexusInputs&    m_inputs;
   CDataCollector&   m_data;
   
   // VEMA-X state
   double            m_vema_ema15;
   double            m_vema_prev_ema15;
   datetime          m_vema_last_update;
   
   // First Touch state
   double            m_ft_buy_barrier;
   double            m_ft_sell_barrier;
   double            m_ft_buy_prob;
   double            m_ft_sell_prob;
   datetime          m_ft_last_launch;
   
   // Classic Live state
   double            m_classic_direction;
   double            m_classic_energy;
   double            m_classic_fast_ema;
   double            m_classic_slow_ema;
   
   // Consensus
   int               m_same_side_loss_streak_buy;
   int               m_same_side_loss_streak_sell;
   datetime          m_last_buy_loss_time;
   datetime          m_last_sell_loss_time;
   
   // AEG
   double            m_aeg_support;
   double            m_aeg_equity_peak;
   double            m_aeg_hard_loss_band;
   double            m_aeg_profit_floor;
   double            m_aeg_profit_run;
   
public:
   CTrendEngines(CNexusInputs& inputs, CDataCollector& data)
      : m_inputs(inputs), m_data(data) {
      Reset();
   }
   
   void Reset() {
      m_vema_ema15 = 0;
      m_vema_prev_ema15 = 0;
      m_vema_last_update = 0;
      m_ft_buy_barrier = 0;
      m_ft_sell_barrier = 0;
      m_ft_buy_prob = 0;
      m_ft_sell_prob = 0;
      m_ft_last_launch = 0;
      m_classic_direction = 0;
      m_classic_energy = 0;
      m_classic_fast_ema = 0;
      m_classic_slow_ema = 0;
      m_same_side_loss_streak_buy = 0;
      m_same_side_loss_streak_sell = 0;
      m_last_buy_loss_time = 0;
      m_last_sell_loss_time = 0;
      m_aeg_support = 0;
      m_aeg_equity_peak = 0;
   }
   
   void Initialize() {
      m_aeg_equity_peak = AccountInfoDouble(ACCOUNT_EQUITY);
      m_classic_fast_ema = m_data.GetMA(8);
      m_classic_slow_ema = m_data.GetMA(21);
   }
   
   // ─── VEMA-X Engine ──────────────────────────────────────────────
   ENUM_SIGNAL_DIR CalcVEMA(double& score) {
      double bid = SymbolInfoDouble(m_data.Symbol(), SYMBOL_BID);
      double ask = SymbolInfoDouble(m_data.Symbol(), SYMBOL_ASK);
      double spread = (ask - bid) / _Point;
      
      // Calculate EMA15 (15-minute virtual bar)
      double close = m_data.GetClose(0);
      double alpha = 2.0 / (15.0 + 1.0);
      
      if(m_vema_ema15 == 0) {
         m_vema_ema15 = close;
      } else {
         m_vema_ema15 = alpha * close + (1 - alpha) * m_vema_ema15;
      }
      
      double diff = m_vema_ema15 - m_vema_prev_ema15;
      double flat_threshold = spread * m_inputs.EMA15_FlatSpreadMult * _Point;
      
      if(diff > flat_threshold) {
         m_vema_prev_ema15 = m_vema_ema15;
         score = MathMin(100, 50 + diff / _Point);
         return DIR_BUY;
      } else if(diff < -flat_threshold) {
         m_vema_prev_ema15 = m_vema_ema15;
         score = MathMin(100, 50 + MathAbs(diff) / _Point);
         return DIR_SELL;
      }
      
      m_vema_prev_ema15 = m_vema_ema15;
      score = 50;
      return DIR_NEUTRAL;
   }
   
   // ─── First Touch Engine ─────────────────────────────────────────
   ENUM_SIGNAL_DIR CalcFirstTouch(double& score) {
      double bid = SymbolInfoDouble(m_data.Symbol(), SYMBOL_BID);
      double ask = SymbolInfoDouble(m_data.Symbol(), SYMBOL_ASK);
      double spread = (ask - bid) / _Point;
      double barrier = spread * m_inputs.FT_BarrierSpreadMult * _Point;
      
      datetime now = TimeCurrent();
      
      // Launch check
      if(now - m_ft_last_launch < (datetime)m_inputs.FT_LaunchEverySeconds)
         return DIR_NEUTRAL;
      
      // Get price history
      double highs[], lows[], closes[];
      int count = m_data.GetRecentBars(m_inputs.FT_LookbackSeconds, highs, lows, closes);
      if(count < m_inputs.FT_MinResolved) {
         score = 0;
         return DIR_NEUTRAL;
      }
      
      double lookback_high = ArrayMaximum(highs, 0, count);
      double lookback_low = ArrayMinimum(lows, 0, count);
      double current_price = bid;
      double range = lookback_high - lookback_low;
      double horizon_dist = range * m_inputs.FT_BarrierMoveMult;
      
      // Calculate barriers
      m_ft_buy_barrier = lookback_low + horizon_dist;
      m_ft_sell_barrier = lookback_high - horizon_dist;
      
      // Calculate probabilities (simplified barrier model)
      double buy_dist = MathAbs(current_price - m_ft_buy_barrier);
      double sell_dist = MathAbs(m_ft_sell_barrier - current_price);
      
      double buy_prob = 1.0 - (buy_dist / range);
      double sell_prob = 1.0 - (sell_dist / range);
      
      // Z-score adjustment
      double z = MathAbs(current_price - (lookback_high + lookback_low) / 2.0) / (range / 2.0);
      double z_adj = MathExp(-0.5 * MathPow(z - m_inputs.FT_ConfidenceZ, 2));
      
      buy_prob *= z_adj;
      sell_prob *= z_adj;
      
      m_ft_buy_prob = buy_prob;
      m_ft_sell_prob = sell_prob;
      
      double min_prob = m_inputs.FT_MinProbability;
      
      if(buy_prob >= min_prob && buy_prob > sell_prob) {
         m_ft_last_launch = now;
         score = buy_prob * 100;
         return DIR_BUY;
      } else if(sell_prob >= min_prob && sell_prob > buy_prob) {
         m_ft_last_launch = now;
         score = sell_prob * 100;
         return DIR_SELL;
      }
      
      score = MathMax(buy_prob, sell_prob) * 100;
      return DIR_NEUTRAL;
   }
   
   // ─── Classic Live Engine ────────────────────────────────────────
   ENUM_SIGNAL_DIR CalcClassicLive(double& score) {
      double close = m_data.GetClose(0);
      double alpha_fast = 2.0 / (m_inputs.ClassicLiveFastSeconds + 1.0);
      double alpha_slow = 2.0 / (m_inputs.ClassicLiveWindowSeconds + 1.0);
      
      if(m_classic_fast_ema == 0) m_classic_fast_ema = close;
      if(m_classic_slow_ema == 0) m_classic_slow_ema = close;
      
      m_classic_fast_ema = alpha_fast * close + (1 - alpha_fast) * m_classic_fast_ema;
      m_classic_slow_ema = alpha_slow * close + (1 - alpha_slow) * m_classic_slow_ema;
      
      double diff = m_classic_fast_ema - m_classic_slow_ema;
      double range = m_data.GetATR(14);
      double efficiency = (range > 0) ? MathAbs(diff) / range : 0;
      
      m_classic_direction = diff;
      m_classic_energy = efficiency;
      
      double direction_gate = m_inputs.ClassicLiveDirectionGate * _Point;
      double efficiency_gate = m_inputs.ClassicLiveEfficiencyGate;
      
      if(diff > direction_gate && efficiency >= efficiency_gate) {
         double pullback = m_data.GetPullbackPercent();
         if(pullback >= m_inputs.ClassicLivePullbackMin &&
            pullback <= m_inputs.ClassicLivePullbackMax) {
            score = efficiency * 100;
            return DIR_BUY;
         }
      } else if(diff < -direction_gate && efficiency >= efficiency_gate) {
         double pullback = m_data.GetPullbackPercent();
         if(pullback >= m_inputs.ClassicLivePullbackMin &&
            pullback <= m_inputs.ClassicLivePullbackMax) {
            score = efficiency * 100;
            return DIR_SELL;
         }
      }
      
      score = efficiency * 100;
      return DIR_NEUTRAL;
   }
   
   // ─── DI Smart Check ─────────────────────────────────────────────
   ENUM_SIGNAL_DIR CalcDI(double& score) {
      if(!m_inputs.DI_Enable) {
         score = 50;
         return DIR_NEUTRAL;
      }
      
      double trend_score = 0, range_score = 0;
      double up_ticks = 0, down_ticks = 0;
      double up_volume = 0, down_volume = 0;
      
      int window = m_inputs.DI_TickWindow;
      double efficiencies[];
      double directions[];
      
      int n = m_data.GetTickEfficiency(window, efficiencies, directions);
      if(n < m_inputs.DI_MinTicks) {
         score = 50;
         return DIR_NEUTRAL;
      }
      
      for(int i = 0; i < n; i++) {
         if(directions[i] > 0) up_ticks++;
         else if(directions[i] < 0) down_ticks++;
         trend_score += efficiencies[i];
      }
      
      trend_score = (up_ticks + down_ticks > 0)
                    ? trend_score / (up_ticks + down_ticks) : 0;
      range_score = 1.0 - trend_score;
      
      double di_plus = (up_ticks > 0) ? up_ticks * 100.0 / n : 0;
      double di_minus = (down_ticks > 0) ? down_ticks * 100.0 / n : 0;
      double dx = MathAbs(di_plus - di_minus);
      
      // Smooth
      double alpha = m_inputs.DI_SmoothAlpha;
      static double s_di_plus, s_di_minus;
      if(s_di_plus == 0) s_di_plus = di_plus;
      if(s_di_minus == 0) s_di_minus = di_minus;
      s_di_plus = alpha * di_plus + (1 - alpha) * s_di_plus;
      s_di_minus = alpha * di_minus + (1 - alpha) * s_di_minus;
      
      double smoothed_trend = MathMax(s_di_plus, s_di_minus);
      double breakout_frac = m_inputs.DI_BreakoutFrac;
      double dead_zone = m_inputs.DI_DirDeadZone;
      
      if(smoothed_trend > m_inputs.DI_TrendScore &&
         s_di_plus > s_di_minus + dead_zone * m_inputs.DI_TrendScore) {
         score = smoothed_trend;
         return DIR_BUY;
      } else if(smoothed_trend > m_inputs.DI_RangeScore &&
                s_di_minus > s_di_plus + dead_zone * m_inputs.DI_RangeScore) {
         score = smoothed_trend;
         return DIR_SELL;
      }
      
      score = smoothed_trend;
      return DIR_NEUTRAL;
   }
   
   // ─── TMI Early Trend Check ───────────────────────────────────────
   ENUM_SIGNAL_DIR CalcTMI(double& score) {
      if(!m_inputs.TMI_Enable) {
         score = 0.5;
         return DIR_NEUTRAL;
      }
      
      double fast_trend = m_data.GetMomentum(m_inputs.TMI_FastTicks);
      double mid_trend = m_data.GetMomentum(m_inputs.TMI_MidTicks);
      double atr = m_data.GetATR(14);
      
      double impulse = MathAbs(fast_trend) / (atr > 0 ? atr : 1);
      double breakout = m_inputs.TMI_BreakoutATR * atr;
      
      if(impulse >= m_inputs.TMI_ConfidenceGate &&
         MathAbs(fast_trend) >= m_inputs.TMI_MinImpulseATR * atr) {
         
         // Reversal risk
         double reversal = (mid_trend * fast_trend < 0)
                           ? MathAbs(mid_trend - fast_trend) / atr : 0;
         if(reversal > m_inputs.TMI_ReversalRiskGate) {
            score = m_inputs.TMI_ReversalRiskGate;
            return DIR_NEUTRAL;
         }
         
         score = impulse;
         if(fast_trend > 0) return DIR_BUY;
         else return DIR_SELL;
      }
      
      // Early gate
      if(m_inputs.Bullet_AllowEarlyTMI) {
         if(impulse >= m_inputs.TMI_EarlyGate &&
            MathAbs(fast_trend) >= m_inputs.TMI_MinImpulseATR * atr * 0.8) {
            score = impulse;
            return (fast_trend > 0) ? DIR_BUY : DIR_SELL;
         }
      }
      
      score = impulse;
      return DIR_NEUTRAL;
   }
   
   // ─── AWR Trend/Range Check ──────────────────────────────────────
   bool CalcAWR() {
      if(!m_inputs.AWR_Enable) return true; // Default to trend
      
      double vr_range = m_data.GetVR(14, m_inputs.AWR_VR_RangeBand);
      double vr_trend = m_data.GetVR(14, m_inputs.AWR_VR_TrendBand);
      double atr = m_data.GetATR(m_inputs.AWR_TargetBars);
      
      double hurst = 0.5;
      if(m_inputs.AWR_Hurst_Enable)
         hurst = m_data.GetHurstExponent(m_inputs.AWR_Hurst_Band);
      
      bool is_trend = (vr_trend > vr_range) && (hurst > 0.5);
      return is_trend;
   }
   
   // ─── NDI Nexus Direction Intelligence ──────────────────────────
   ENUM_SIGNAL_DIR CalcNDI() {
      if(!m_inputs.NDI_Enable) return DIR_NEUTRAL;
      
      // Simplified NDI: combines multiple signals
      double di_score;
      ENUM_SIGNAL_DIR di_dir = CalcDI(di_score);
      ENUM_SIGNAL_DIR tmi_dir = DIR_NEUTRAL;
      double tmi_score;
      if(m_inputs.TMI_Enable) tmi_dir = CalcTMI(tmi_score);
      
      ENUM_SIGNAL_DIR result = DIR_NEUTRAL;
      double di_weight = 0.6;
      double tmi_weight = 0.4;
      
      switch(m_inputs.NDI_Profile) {
         case NDI_MORE_TRADES:
            di_weight = 0.3; tmi_weight = 0.7; break;
         case NDI_BALANCED:
            di_weight = 0.5; tmi_weight = 0.5; break;
         case NDI_SELECTIVE:
            di_weight = 0.7; tmi_weight = 0.3; break;
      }
      
      if(di_dir == DIR_BUY && tmi_dir == DIR_BUY)
         result = DIR_BUY;
      else if(di_dir == DIR_SELL && tmi_dir == DIR_SELL)
         result = DIR_SELL;
      else if(di_dir != DIR_NEUTRAL)
         result = (di_score > 60) ? di_dir : DIR_NEUTRAL;
      else if(tmi_dir != DIR_NEUTRAL)
         result = (tmi_score > 0.6) ? tmi_dir : DIR_NEUTRAL;
      
      // NDI Flip Safety
      switch(m_inputs.NDI_FlipSafety) {
         case NDI_FLIP_STRONG:
            // Require 2+ consecutive same-direction signals
            static int s_same_count;
            static ENUM_SIGNAL_DIR s_last_ndi;
            if(result == s_last_ndi) s_same_count++;
            else { s_same_count = 1; s_last_ndi = result; }
            if(s_same_count < 2) result = DIR_NEUTRAL;
            break;
         case NDI_FLIP_VSTRONG:
            static int s_vstrong_count;
            static ENUM_SIGNAL_DIR s_last_vndi;
            if(result == s_last_vndi) s_vstrong_count++;
            else { s_vstrong_count = 1; s_last_vndi = result; }
            if(s_vstrong_count < 3) result = DIR_NEUTRAL;
            break;
      }
      
      return result;
   }
   
   // ─── DTE Direction Truth Meta Filter ───────────────────────────
   bool CalcDTE() {
      if(!m_inputs.DTE_Enable) return true;
      
      int samples = m_data.GetSampleCount();
      if(samples < m_inputs.DTE_MinSamples) return true;
      
      double meta_edge = m_data.GetMetaEdge();
      double noise = m_data.GetNoiseATR();
      
      double noise_max = m_inputs.DTE_NoiseMaxATR * m_data.GetATR(14);
      if(noise > noise_max) return false;
      
      // Scout penalty
      bool is_scout = (m_data.GetPositionCount() == 0);
      if(is_scout) {
         meta_edge -= m_inputs.DTE_ScoutOnlyPenalty;
      }
      
      // Meta edge thresholds
      if(meta_edge > m_inputs.DTE_MetaEdgeBoost) return true;
      if(meta_edge < -m_inputs.DTE_MetaEdgePenalty) return false;
      
      return true;
   }
   
   // ─── Entry Quality Score ────────────────────────────────────────
   int CalcEntryQuality() {
      int quality = 100;
      
      double spread = m_data.GetSpread();
      double atr = m_data.GetATR(14);
      double spread_mult = (atr > 0) ? spread * _Point / atr : 0;
      
      // Spread penalty
      double min_edge = m_inputs.Bullet_MinEdgeSpreadMult;
      if(spread_mult > min_edge) {
         quality -= (int)((spread_mult - min_edge) * 100);
      }
      
      // Trend quality
      double di_score;
      ENUM_SIGNAL_DIR di_dir = CalcDI(di_score);
      if(di_dir == DIR_NEUTRAL)
         quality -= 20;
      
      // AWR
      if(m_inputs.AWR_Enable) {
         if(!CalcAWR()) quality -= 10;
      }
      
      // Loss streak penalty
      double loss_penalty = MathMax(
         m_same_side_loss_streak_buy, m_same_side_loss_streak_sell)
         * m_inputs.Bullet_LossQualityStep;
      quality -= (int)loss_penalty;
      
      return MathMax(0, MathMin(100, quality));
   }
   
   // ─── AEG Support Strength ───────────────────────────────────────
   double CalcAEGSupport() {
      if(!m_inputs.AEG_Enable) return 1.0;
      
      double equity = AccountInfoDouble(ACCOUNT_EQUITY);
      double balance = AccountInfoDouble(ACCOUNT_BALANCE);
      
      // Update peak
      if(equity > m_aeg_equity_peak)
         m_aeg_equity_peak = equity;
      
      // Bands
      double drawdown = (m_aeg_equity_peak - equity) / m_aeg_equity_peak;
      m_aeg_hard_loss_band = m_inputs.AEG_HardLossBandMult * m_inputs.AEG_MinHoldSec * _Point;
      m_aeg_profit_floor = m_aeg_equity_peak * m_inputs.AEG_ProfitFloorBandMult;
      m_aeg_profit_run = m_aeg_equity_peak * m_inputs.AEG_ProfitRunBandMult;
      
      // Support strength
      if(equity >= m_aeg_profit_run) {
         m_aeg_support = 1.0 - drawdown;
      } else if(equity >= m_aeg_profit_floor) {
         m_aeg_support = 0.7 - (m_aeg_equity_peak - equity) / m_aeg_equity_peak;
      } else {
         m_aeg_support = 0.3;
      }
      
      return m_aeg_support;
   }
   
   // ─── TP-PROJ Lot Calculator ─────────────────────────────────────
   double CalcTPProjLot(ENUM_SIGNAL_DIR dir, double equity,
                        double reset_equity, double peak_equity) {
      
      double base_lot = m_inputs.BulletLotValue;
      
      switch(m_inputs.TPProjVolumeRegime) {
         case TPP_FIXED:
            return base_lot;
            
         case TPP_BALANCE_PCT:
            return equity * m_inputs.AutoLotPct / 100.0 / 10000.0;
            
         case TPP_TARGET_DEFICIT: {
            // Hedef para açığı / beklenen hareket
            double target_profit = equity * m_inputs.GlobalProfitPct / 100.0;
            double atr = m_data.GetATR(14);
            double expected_move = atr * 2; // Basit varsayım
            if(expected_move > 0) {
               double needed_lot = target_profit / (expected_move * _Point);
               return MathMin(needed_lot, base_lot * 5);
            }
            return base_lot;
         }
         
         case TPP_NET_VOL: {
            // Mevcut aynı yön lotu düşülür
            double current_same_side_lot = m_data.GetSameSideLot(dir);
            double max_lot = SymbolInfoDouble(m_data.Symbol(), SYMBOL_VOLUME_MAX);
            double lot_step = SymbolInfoDouble(m_data.Symbol(), SYMBOL_VOLUME_STEP);
            double target_lot = base_lot * (1.0 + m_inputs.LotBoostStepPct / 100.0);
            double needed = MathMax(0, target_lot - current_same_side_lot);
            return NormalizeDouble(MathMin(needed, max_lot) / lot_step, 0) * lot_step;
         }
         
         case TPP_SOLVER:
         default: {
            // En küçük ek lot — sepet simülasyonu
            double current_lot = m_data.GetSameSideLot(dir);
            double atr = m_data.GetATR(14);
            double target_pnl = equity * m_inputs.GlobalProfitPct / 100.0;
            double move_per_lot = atr * _Point;
            if(move_per_lot > 0) {
               double needed_lot = target_pnl / move_per_lot - current_lot;
               return MathMax(0.01, NormalizeDouble(needed_lot, 2));
            }
            return base_lot;
         }
      }
   }
   
   // ─── Fresh Signal Check ─────────────────────────────────────────
   bool IsFreshSignal(datetime last_signal_time) {
      datetime now = TimeCurrent();
      return (now - last_signal_time > 60); // 60 saniye
   }
   
   // ─── Record loss for streak tracking ────────────────────────────
   void RecordLoss(ENUM_SIGNAL_DIR dir) {
      if(dir == DIR_BUY) {
         m_same_side_loss_streak_buy++;
         m_last_buy_loss_time = TimeCurrent();
      } else {
         m_same_side_loss_streak_sell++;
         m_last_sell_loss_time = TimeCurrent();
      }
   }
   
   void RecordWin(ENUM_SIGNAL_DIR dir) {
      if(dir == DIR_BUY)
         m_same_side_loss_streak_buy = 0;
      else
         m_same_side_loss_streak_sell = 0;
   }
   
   int GetLossStreak(ENUM_SIGNAL_DIR dir) {
      return (dir == DIR_BUY) ? m_same_side_loss_streak_buy
                               : m_same_side_loss_streak_sell;
   }
};
