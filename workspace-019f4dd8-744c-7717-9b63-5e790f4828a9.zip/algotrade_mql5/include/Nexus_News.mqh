//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — News Filter & Calendar                      |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>

//+------------------------------------------------------------------+
//| News Event Structure                                               |
//+------------------------------------------------------------------+
struct NewsItem {
   datetime          time;
   string            currency;
   string            name;
   int               impact;         // 1=Low, 2=Medium, 3=High
   bool               handled;
   ENUM_TIME_ACTION   action;
};

class CNewsFilter {
private:
   CNexusInputs&     m_inputs;
   NewsItem           m_news_list[];
   int               m_news_count;
   bool               m_hard_locked;
   bool               m_hedge_opened;
   int               m_locked_currency_mask;
   datetime          m_news_window_start;
   datetime          m_news_window_end;
   int               m_news_handle;
   
public:
   CNewsFilter(CNexusInputs& inputs)
      : m_inputs(inputs), m_news_count(0), m_hard_locked(false),
        m_hedge_opened(false), m_locked_currency_mask(0),
        m_news_window_start(0), m_news_window_end(0) {
      ArrayResize(m_news_list, 0);
      m_news_handle = INVALID_HANDLE;
   }
   
   void Initialize() {
      if(!m_inputs.NF_Enable) {
         Print("[News] Filter disabled");
         return;
      }
      
      Print("[News] Filter enabled");
      Print("[News] Filter: ", m_inputs.NF_CurrencyFilter,
            " MinutesBefore=", m_inputs.NF_MinutesBefore,
            " MinutesAfter=", m_inputs.NF_MinutesAfter,
            " OnlyHigh=", m_inputs.NF_OnlyHighImpact,
            " Medium=", m_inputs.NF_MediumImpact);
      Print("[News] PauseTrading=", m_inputs.NF_PauseTrading,
            " HedgeBefore=", m_inputs.NF_HedgeBeforeNews,
            " CloseAllBefore=", m_inputs.NF_CloseAllBeforeNews,
            " ShowPanel=", m_inputs.NF_ShowPanel);
      
      // Load news from MT5 Economic Calendar
      LoadNewsFromCalendar();
   }
   
   void Update() {
      if(!m_inputs.NF_Enable) return;
      
      datetime now = TimeCurrent();
      
      // Update news window
      UpdateNewsWindow(now);
      
      // Check if we need to hard lock
      CheckHardLock(now);
      
      // Handle hedge operations
      if(m_hard_locked && !m_hedge_opened) {
         if(m_inputs.NF_HedgeBeforeNews)
            OpenNewsHedge();
      }
      
      // End of news window
      if(m_hedge_opened && now >= m_news_window_end) {
         CloseNewsHedge();
      }
   }
   
   void LoadNewsFromCalendar() {
      // MT5 Economic Calendar integration
      // CalendarGetNum() returns number of events
      // CalendarGetByIndex() gets event details
      
      #ifdef __MQL5__
      int num_events = CalendarGetNum();
      if(num_events <= 0) {
         Print("[News] No calendar events available from MT5");
         return;
      }
      
      // Parse currency filter
      string currencies[];
      string filter = m_inputs.NF_CurrencyFilter;
      int n_cur = StringSplit(filter, ',', currencies);
      
      for(int i = 0; i < MathMin(num_events, 500); i++) {
         MqlCalendarEvent evt;
         if(!CalendarGetByIndex(i, evt)) continue;
         
         // Filter by currency
         bool currency_match = false;
         for(int c = 0; c < n_cur; c++) {
            string cur = currencies[c];
            StringTrimLeft(cur);
            StringTrimRight(cur);
            if(StringFind(evt.currency, cur) >= 0) {
               currency_match = true;
               break;
            }
         }
         if(!currency_match && n_cur > 0) continue;
         
         // Filter by impact
         int impact = 0;
         switch(evt.importance) {
            case CALENDAR_IMPORTANCE_HIGH:   impact = 3; break;
            case CALENDAR_IMPORTANCE_MEDIUM: impact = 2; break;
            case CALENDAR_IMPORTANCE_LOW:    impact = 1; break;
            default:                         impact = 0; break;
         }
         
         if(m_inputs.NF_OnlyHighImpact && impact < 3) continue;
         if(!m_inputs.NF_MediumImpact && impact == 2) continue;
         if(impact == 0) continue;
         
         // Add to news list
         ArrayResize(m_news_list, m_news_count + 1);
         m_news_list[m_news_count].time = (datetime)evt.time;
         m_news_list[m_news_count].currency = evt.currency;
         m_news_list[m_news_count].name = evt.event_name;
         m_news_list[m_news_count].impact = impact;
         m_news_list[m_news_count].handled = false;
         m_news_count++;
      }
      
      Print("[News] Loaded ", m_news_count, " events from calendar");
      #endif
   }
   
   void UpdateNewsWindow(datetime now) {
      m_news_window_start = 0;
      m_news_window_end = 0;
      
      for(int i = 0; i < m_news_count; i++) {
         if(m_news_list[i].handled) continue;
         
         datetime news_time = m_news_list[i].time;
         datetime window_start = news_time - m_inputs.NF_MinutesBefore * 60;
         datetime window_end = news_time + m_inputs.NF_MinutesAfter * 60;
         
         if(now >= window_start && now <= window_end) {
            m_news_window_start = window_start;
            m_news_window_end = window_end;
            
            if(!m_news_list[i].handled) {
               m_news_list[i].handled = true;
               Print("[News] ⚠️ ", m_news_list[i].name,
                     " | ", m_news_list[i].currency,
                     " | Impact: ", m_news_list[i].impact,
                     " | In ", (news_time - now) / 60, " minutes");
            }
            break;
         }
      }
   }
   
   void CheckHardLock(datetime now) {
      if(m_news_window_start > 0 && m_news_window_end > 0) {
         if(m_inputs.NF_PauseTrading || m_inputs.NF_CloseAllBeforeNews) {
            m_hard_locked = true;
         }
      } else {
         m_hard_locked = false;
      }
   }
   
   bool IsHardLocked() {
      return m_hard_locked;
   }
   
   bool IsAnyNewsSoon() {
      datetime now = TimeCurrent();
      for(int i = 0; i < m_news_count; i++) {
         datetime news_time = m_news_list[i].time;
         if(news_time > now && news_time - now <= (datetime)(m_inputs.NF_MinutesBefore * 60))
            return true;
      }
      return false;
   }
   
   int GetMinutesToNextNews() {
      datetime now = TimeCurrent();
      int min_minutes = INT_MAX;
      for(int i = 0; i < m_news_count; i++) {
         datetime news_time = m_news_list[i].time;
         if(news_time > now) {
            int minutes = (int)((news_time - now) / 60);
            if(minutes < min_minutes) min_minutes = minutes;
         }
      }
      return (min_minutes == INT_MAX) ? -1 : min_minutes;
   }
   
   void OpenNewsHedge() {
      if(!m_inputs.NF_HedgeBeforeNews || m_hedge_opened) return;
      
      // Calculate net exposure
      double buy_lot = 0, sell_lot = 0;
      int total = PositionsTotal();
      for(int i = 0; i < total; i++) {
         if(PositionGetSymbol(i) == _Symbol) {
            if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
               buy_lot += PositionGetDouble(POSITION_VOLUME);
            else
               sell_lot += PositionGetDouble(POSITION_VOLUME);
         }
      }
      
      double net_lot = buy_lot - sell_lot;
      if(MathAbs(net_lot) < 0.01) return; // No significant exposure
      
      // Open hedge position
      ENUM_POSITION_TYPE hedge_type =
         (net_lot > 0) ? POSITION_TYPE_SELL : POSITION_TYPE_BUY;
      double hedge_lot = MathAbs(net_lot);
      
      double price = (hedge_type == POSITION_TYPE_BUY)
                     ? SymbolInfoDouble(_Symbol, SYMBOL_ASK)
                     : SymbolInfoDouble(_Symbol, SYMBOL_BID);
      
      ulong ticket = OrderSend(_Symbol, (ENUM_ORDER_TYPE)hedge_type,
         hedge_lot, price, 10, 0, 0,
         "NexusNewsHedge", m_inputs.GetMagicNFHedge(), 0, clrYellow);
      
      if(ticket > 0) {
         m_hedge_opened = true;
         Print("[News] Hedge opened: ", EnumToString(hedge_type),
               " Lot=", DoubleToString(hedge_lot, 2),
               " Ticket=", ticket);
      }
   }
   
   void CloseNewsHedge() {
      if(!m_hedge_opened) return;
      
      // Close hedge position
      int total = PositionsTotal();
      for(int i = total - 1; i >= 0; i--) {
         if(PositionGetSymbol(i) != _Symbol) continue;
         ulong magic = PositionGetInteger(POSITION_MAGIC);
         if(magic != m_inputs.GetMagicNFHedge()) continue;
         
         ulong ticket = PositionGetInteger(POSITION_TICKET);
         ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         
         double price = (type == POSITION_TYPE_BUY)
                        ? SymbolInfoDouble(_Symbol, SYMBOL_BID)
                        : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
         
         double lot = PositionGetDouble(POSITION_VOLUME);
         double pnl = PositionGetDouble(POSITION_PROFIT);
         
         OrderClose(ticket, lot, price, 10, clrNONE);
         Print("[News] Hedge closed: PnL=", DoubleToString(pnl, 2));
      }
      
      m_hedge_opened = false;
      m_hard_locked = false;
      Print("[News] News window ended — normal trading resumed");
   }
   
   bool IsNewsHedgeActive() { return m_hedge_opened; }
   
   string GetNextNewsInfo() {
      datetime now = TimeCurrent();
      int min_minutes = INT_MAX;
      string info = "";
      
      for(int i = 0; i < m_news_count; i++) {
         datetime news_time = m_news_list[i].time;
         if(news_time > now) {
            int minutes = (int)((news_time - now) / 60);
            if(minutes < min_minutes) {
               min_minutes = minutes;
               info = StringFormat("%s %s [%d min]",
                  m_news_list[i].name, m_news_list[i].currency, minutes);
            }
         }
      }
      return info;
   }
};
