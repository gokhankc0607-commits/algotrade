//+------------------------------------------------------------------+
//| Algotrade Nexus Pro — Market Data Collector                       |
//+ CRITICAL: Bu modül ONNX için veri toplama + tüm indicator       |
//+ hesaplamalarını yapar. ML Training Data Logger burada çalışır.  |
//+------------------------------------------------------------------+
#property copyright "Algotrade Nexus Pro"
#property version   "7.35"

#include <Include/Algotrade/Nexus_Core_Settings.mqh>

//+------------------------------------------------------------------+
//| Data Collector Class                                              |
//+------------------------------------------------------------------+
class CDataCollector {
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_timeframe;
   CNexusInputs&     m_inputs;
   
   // OHLCV buffers
   double            m_closes[];
   double            m_highs[];
   double            m_lows[];
   double            m_opens[];
   long              m_volumes[];
   datetime          m_times[];
   int               m_bar_count;
   
   // Tick data
   double            m_last_bid;
   double            m_last_ask;
   double            m_last_spread;
   double            m_tick_up[];
   double            m_tick_down[];
   int               m_tick_count;
   
   // Indicator caches
   double            m_rsi_cache;
   double            m_atr_cache;
   double            m_ma_fast_cache;
   double            m_ma_slow_cache;
   double            m_vr_cache;
   double            m_hurst_cache;
   double            m_momentum_cache;
   datetime          m_indicator_cache_time;
   
   // ML training data
   int               m_ml_file_handle;
   datetime          m_last_ml_log;
   int               m_pending_labels;
   double            m_last_atr_for_label;
   
public:
   CDataCollector(string symbol, ENUM_TIMEFRAMES tf)
      : m_symbol(symbol), m_timeframe(tf), m_ml_file_handle(INVALID_HANDLE),
        m_bar_count(0), m_tick_count(0), m_last_ml_log(0) {
      ArraySetAsSeries(m_closes, true);
      ArraySetAsSeries(m_highs, true);
      ArraySetAsSeries(m_lows, true);
      ArraySetAsSeries(m_opens, true);
      ArraySetAsSeries(m_volumes, true);
      ArraySetAsSeries(m_times, true);
      ArraySetAsSeries(m_tick_up, true);
      ArraySetAsSeries(m_tick_down, true);
   }
   
   ~CDataCollector() {
      if(m_ml_file_handle != INVALID_HANDLE)
         FileClose(m_ml_file_handle);
   }
   
   string Symbol() { return m_symbol; }
   
   // ─── Load bars from MT5 ────────────────────────────────────────
   bool LoadBars(int count) {
      MqlRates rates[];
      ArrayResize(rates, count);
      ArraySetAsSeries(rates, true);
      
      int copied = CopyRates(m_symbol, m_timeframe, 0, count, rates);
      if(copied <= 0) {
         Print("ERROR LoadBars: ", GetLastError());
         return false;
      }
      
      m_bar_count = copied;
      
      ArrayResize(m_closes, m_bar_count);
      ArrayResize(m_highs, m_bar_count);
      ArrayResize(m_lows, m_bar_count);
      ArrayResize(m_opens, m_bar_count);
      ArrayResize(m_volumes, m_bar_count);
      ArrayResize(m_times, m_bar_count);
      
      for(int i = 0; i < m_bar_count; i++) {
         m_closes[i]  = rates[i].close;
         m_highs[i]   = rates[i].high;
         m_lows[i]    = rates[i].low;
         m_opens[i]   = rates[i].open;
         m_volumes[i] = rates[i].tick_volume;
         m_times[i]   = rates[i].time;
      }
      
      return true;
   }
   
   // ─── Tick processing ───────────────────────────────────────────
   void ProcessTick() {
      m_last_bid = SymbolInfoDouble(m_symbol, SYMBOL_BID);
      m_last_ask = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
      m_last_spread = (m_last_ask - m_last_bid) / _Point;
      
      static double prev_bid;
      if(prev_bid == 0) prev_bid = m_last_bid;
      
      double tick_move = m_last_bid - prev_bid;
      if(tick_move > 0) {
         ArrayResize(m_tick_up, m_tick_count + 1);
         m_tick_up[m_tick_count] = tick_move;
      } else if(tick_move < 0) {
         ArrayResize(m_tick_down, m_tick_count + 1);
         m_tick_down[m_tick_count] = MathAbs(tick_move);
      }
      m_tick_count++;
      prev_bid = m_last_bid;
      
      // Limit tick array size
      const int MAX_TICKS = 5000;
      if(m_tick_count > MAX_TICKS) {
         // Shift by removing oldest half
         int half = MAX_TICKS / 2;
         for(int i = 0; i < half; i++) {
            m_tick_up[i] = m_tick_up[i + half];
            m_tick_down[i] = m_tick_down[i + half];
         }
         m_tick_count = half;
      }
   }
   
   // ─── INDICATOR: Close price ─────────────────────────────────────
   double GetClose(int shift = 0) {
      if(shift >= m_bar_count) LoadBars(shift + 10);
      if(shift < m_bar_count) return m_closes[shift];
      return 0;
   }
   
   double GetOpen(int shift = 0) {
      if(shift >= m_bar_count) LoadBars(shift + 10);
      if(shift < m_bar_count) return m_opens[shift];
      return 0;
   }
   
   double GetHigh(int shift = 0) {
      if(shift >= m_bar_count) LoadBars(shift + 10);
      if(shift < m_bar_count) return m_highs[shift];
      return 0;
   }
   
   double GetLow(int shift = 0) {
      if(shift >= m_bar_count) LoadBars(shift + 10);
      if(shift < m_bar_count) return m_lows[shift];
      return 0;
   }
   
   datetime GetTime(int shift = 0) {
      if(shift < m_bar_count) return m_times[shift];
      return 0;
   }
   
   // ─── INDICATOR: RSI ─────────────────────────────────────────────
   double GetRSI(int period = 14) {
      if(m_bar_count < period + 2) return 50;
      
      double gains = 0, losses = 0;
      for(int i = 1; i <= period; i++) {
         double change = m_closes[i] - m_closes[i+1];
         if(change > 0) gains += change;
         else losses += MathAbs(change);
      }
      double avg_gain = gains / period;
      double avg_loss = losses / period;
      
      if(avg_loss == 0) return 100;
      double rs = avg_gain / avg_loss;
      return 100.0 - (100.0 / (1.0 + rs));
   }
   
   // ─── INDICATOR: ATR (Average True Range) ───────────────────────
   double GetATR(int period = 14) {
      if(m_bar_count < period + 2) return _Point * 100;
      
      double tr_sum = 0;
      for(int i = 0; i < period; i++) {
         double tr = MathMax(m_highs[i] - m_lows[i],
                    MathMax(MathAbs(m_highs[i] - m_closes[i+1]),
                            MathAbs(m_lows[i] - m_closes[i+1])));
         tr_sum += tr;
      }
      return tr_sum / period;
   }
   
   // ─── INDICATOR: Moving Average ──────────────────────────────────
   double GetMA(int period, int shift = 0) {
      if(m_bar_count < period) return GetClose(shift);
      
      double sum = 0;
      for(int i = shift; i < shift + period; i++) {
         if(i < m_bar_count) sum += m_closes[i];
      }
      return sum / period;
   }
   
   // ─── INDICATOR: EMA ─────────────────────────────────────────────
   double GetEMA(int period, int shift = 0) {
      if(m_bar_count < period) return GetClose(shift);
      
      double alpha = 2.0 / (period + 1);
      double ema = GetClose(period + shift);
      for(int i = period + shift - 1; i >= shift; i--) {
         if(i < m_bar_count) {
            ema = m_closes[i] * alpha + ema * (1 - alpha);
         }
      }
      return ema;
   }
   
   // ─── INDICATOR: Momentum ────────────────────────────────────────
   double GetMomentum(int period) {
      if(m_bar_count <= period) return 0;
      return m_closes[0] - m_closes[period];
   }
   
   // ─── INDICATOR: VR (Volatility Ratio) ──────────────────────────
   double GetVR(int period, double band) {
      double atr = GetATR(period);
      double current_range = m_highs[0] - m_lows[0];
      if(atr == 0) return 0;
      return current_range / atr;
   }
   
   // ─── INDICATOR: Hurst Exponent ─────────────────────────────────
   double GetHurstExponent(double band = 0.05) {
      // Simplified Hurst: 0.5 = random, >0.5 = trending, <0.5 = mean-reverting
      if(m_bar_count < 100) return 0.5;
      
      // R/S Analysis simplified
      int n = (int)(m_bar_count * band);
      n = MathMax(n, 10);
      if(n > m_bar_count / 2) n = m_bar_count / 2;
      
      double mean_ret = 0;
      for(int i = 1; i < n; i++) {
         mean_ret += MathAbs(m_closes[i] - m_closes[i-1]);
      }
      mean_ret /= n;
      
      double std_dev = 0;
      for(int i = 1; i < n; i++) {
         std_dev += MathPow(MathAbs(m_closes[i] - m_closes[i-1]) - mean_ret, 2);
      }
      std_dev = MathSqrt(std_dev / n);
      
      if(std_dev == 0 || mean_ret == 0) return 0.5;
      
      // Simplified Hurst
      double rs = (std_dev / mean_ret);
      double hurst = MathLog(rs) / MathLog(n);
      return MathMax(0.0, MathMin(1.0, hurst));
   }
   
   // ─── INDICATOR: Spread ─────────────────────────────────────────
   double GetSpread() {
      double ask = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
      double bid = SymbolInfoDouble(m_symbol, SYMBOL_BID);
      return (ask - bid) / _Point;
   }
   
   // ─── INDICATOR: Pullback Percent ────────────────────────────────
   double GetPullbackPercent() {
      if(m_bar_count < 5) return 0;
      double high = ArrayMaximum(m_highs, 0, 5);
      double low = ArrayMinimum(m_lows, 0, 5);
      double range = high - low;
      double current = m_closes[0];
      if(range == 0) return 0;
      return (high - current) / range;
   }
   
   // ─── Tick Efficiency Analysis ──────────────────────────────────
   int GetTickEfficiency(int window, double& efficiencies[],
                         double& directions[]) {
      int n = MathMin(window, m_tick_count);
      if(n == 0) {
         ArrayResize(efficiencies, 0);
         ArrayResize(directions, 0);
         return 0;
      }
      
      ArrayResize(efficiencies, n);
      ArrayResize(directions, n);
      
      double up_sum = 0, down_sum = 0;
      for(int i = 0; i < n; i++) {
         if(i < ArraySize(m_tick_up))
            up_sum += m_tick_up[i];
         if(i < ArraySize(m_tick_down))
            down_sum += m_tick_down[i];
      }
      double total = up_sum + down_sum;
      double efficiency = (total > 0) ? MathMax(up_sum, down_sum) / total : 0;
      
      for(int i = 0; i < n; i++) {
         efficiencies[i] = efficiency;
         directions[i] = (up_sum > down_sum) ? 1 : -1;
      }
      
      return n;
   }
   
   // ─── Get Sample Count ─────────────────────────────────────────
   int GetSampleCount() { return m_bar_count; }
   
   // ─── Get Meta Edge ─────────────────────────────────────────────
   double GetMetaEdge() {
      if(m_bar_count < 20) return 0;
      double ema_fast = GetEMA(8);
      double ema_mid = GetEMA(21);
      double ema_slow = GetEMA(50);
      
      double edge = (ema_fast - ema_mid) / (ema_mid + _Point) * 100;
      edge += (ema_mid - ema_slow) / (ema_slow + _Point) * 50;
      
      return edge;
   }
   
   // ─── Get Noise ATR ─────────────────────────────────────────────
   double GetNoiseATR() {
      return GetATR(5) * 0.1; // Basit gürültü tahmini
   }
   
   // ─── Get Same Side Lot ─────────────────────────────────────────
   double GetSameSideLot(ENUM_SIGNAL_DIR dir) {
      double total_lot = 0;
      int count = PositionsTotal();
      for(int i = 0; i < count; i++) {
         if(!PositionGetSymbol(i) == m_symbol) continue;
         if(PositionGetInteger(POSITION_TYPE) ==
            (dir == DIR_BUY ? POSITION_TYPE_BUY : POSITION_TYPE_SELL)) {
            total_lot += PositionGetDouble(POSITION_VOLUME);
         }
      }
      return total_lot;
   }
   
   // ─── Get Position Count ────────────────────────────────────────
   int GetPositionCount() {
      int count = 0;
      int total = PositionsTotal();
      for(int i = 0; i < total; i++) {
         if(PositionGetSymbol(i) == m_symbol)
            count++;
      }
      return count;
   }
   
   // ─── Recent Bars ────────────────────────────────────────────────
   int GetRecentBars(int seconds, double& highs[],
                     double& lows[], double& closes[]) {
      int bars_needed = seconds / 60; // Approximate
      bars_needed = MathMin(bars_needed, m_bar_count - 1);
      
      int count = 0;
      for(int i = 0; i < bars_needed; i++) {
         if(i < m_bar_count) {
            ArrayResize(highs, count + 1);
            ArrayResize(lows, count + 1);
            ArrayResize(closes, count + 1);
            highs[count] = m_highs[i];
            lows[count] = m_lows[i];
            closes[count] = m_closes[i];
            count++;
         }
      }
      return count;
   }
   
   // ─── ML TRAINING DATA LOGGER ───────────────────────────────────
   // Bu fonksiyon HER BAR'DA çağrılarak ML modeli için
   // eğitim verisi toplar. Toplanan veri CSV dosyasına yazılır.
   void LogMLTrainingData() {
      if(!m_inputs.ML_DataLog_Enable) return;
      
      datetime now = TimeCurrent();
      if(now - m_last_ml_log < (datetime)(m_inputs.ML_DataLog_IntervalMs / 1000))
         return;
      
      // Open CSV if not open
      if(m_ml_file_handle == INVALID_HANDLE) {
         string filename = m_inputs.ML_DataLog_FileName;
         if(m_inputs.ML_DataLog_AutoPerChart)
            filename = StringFormat("nexus_ml_%s_%s.csv",
                                    m_symbol,
                                    TimeToString(TimeCurrent(), TIME_DATE));
         m_ml_file_handle = FileOpen(filename,
            FILE_CSV|FILE_READ|FILE_WRITE|FILE_SHARE_READ|FILE_ANSI, ',');
         if(m_ml_file_handle == INVALID_HANDLE) {
            Print("ERROR: Cannot open ML log file: ", filename);
            return;
         }
         // Header
         FileWrite(m_ml_file_handle,
            "Time,Symbol,Close,RSI,ATR,EMA8,EMA21,EMA50,Spread," +
            "Momentum8,Momentum21,VR,Hurst,Volume," +
            "TrendScore,RangeScore,PU,PD,Label,LabelHorizon");
      }
      
      // Features
      double rsi = GetRSI(14);
      double atr = GetATR(14);
      double ema8 = GetEMA(8);
      double ema21 = GetEMA(21);
      double ema50 = GetEMA(50);
      double spread = GetSpread();
      double mom8 = GetMomentum(8);
      double mom21 = GetMomentum(21);
      double vr = GetVR(14, 0.15);
      double hurst = GetHurstExponent(0.05);
      long volume = m_volumes[0];
      double close = GetClose(0);
      
      // Pulse density (trend/range)
      double pu = 0, pd = 0;
      double effs[], dirs[];
      int n = GetTickEfficiency(1000, effs, dirs);
      for(int i = 0; i < n; i++) {
         if(dirs[i] > 0) pu += effs[i];
         else pd += effs[i];
      }
      double pulse_trend = (n > 0) ? pu / n : 0;
      double pulse_range = (n > 0) ? pd / n : 0;
      
      // Future label: price direction in N seconds
      int horizon_bars = m_inputs.ML_DataLog_LabelHorizonSec / 60;
      int label = 0; // 0=neutral, 1=up, 2=down
      double future_close = 0;
      
      if(horizon_bars > 0 && horizon_bars < m_bar_count) {
         future_close = m_closes[horizon_bars];
         double change_pct = (future_close - close) / close * 100;
         double min_move = m_inputs.ML_DataLog_MinMoveATR * atr / close * 100;
         
         if(change_pct > min_move) label = 1;
         else if(change_pct < -min_move) label = 2;
         else label = 0;
         
         m_pending_labels++;
      }
      
      // Write row
      FileWrite(m_ml_file_handle,
         TimeToString(now),
         m_symbol,
         DoubleToString(close, _Digits),
         DoubleToString(rsi, 4),
         DoubleToString(atr, _Digits),
         DoubleToString(ema8, _Digits),
         DoubleToString(ema21, _Digits),
         DoubleToString(ema50, _Digits),
         DoubleToString(spread, 1),
         DoubleToString(mom8, _Digits),
         DoubleToString(mom21, _Digits),
         DoubleToString(vr, 4),
         DoubleToString(hurst, 4),
         (string)volume,
         DoubleToString(pulse_trend, 4),
         DoubleToString(pulse_range, 4),
         (string)label,
         DoubleToString(future_close, _Digits));
      
      m_last_ml_log = now;
      
      // Flush periodically
      if(m_pending_labels % 100 == 0)
         FileFlush(m_ml_file_handle);
      
      // Max pending check
      if(m_pending_labels > m_inputs.ML_DataLog_MaxPending) {
         FileClose(m_ml_file_handle);
         m_ml_file_handle = INVALID_HANDLE;
         Print("ML Data log closed — max pending reached: ",
               m_pending_labels);
      }
   }
   
   // ─── ONNX Feature Extraction ───────────────────────────────────
   // ONNX model için 16 özellik vektörü oluşturur
   bool ExtractONNXFeatures(double& features[]) {
      ArrayResize(features, m_inputs.ML_FeatureCount);
      
      // Feature 0-3: RSI variants
      features[0] = GetRSI(7) / 100.0;
      features[1] = GetRSI(14) / 100.0;
      features[2] = GetRSI(28) / 100.0;
      features[3] = GetRSI(7) - GetRSI(14);
      
      // Feature 4-5: ATR
      features[4] = GetATR(14) / _Point / 10000.0;
      features[5] = GetATR(14) / GetATR(50);
      
      // Feature 6-8: Moving averages
      features[6] = (GetClose(0) - GetEMA(8)) / GetClose(0);
      features[7] = (GetClose(0) - GetEMA(21)) / GetClose(0);
      features[8] = (GetEMA(8) - GetEMA(21)) / GetClose(0);
      
      // Feature 9: Momentum
      features[9] = GetMomentum(8) / _Point / 100.0;
      
      // Feature 10: VR
      features[10] = GetVR(14, 0.15);
      
      // Feature 11: Hurst
      features[11] = GetHurstExponent(0.05);
      
      // Feature 12: Spread
      features[12] = GetSpread() / 100.0;
      
      // Feature 13-14: Pulse density
      double effs[], dirs[];
      int n = GetTickEfficiency(500, effs, dirs);
      features[13] = 0;
      features[14] = 0;
      for(int i = 0; i < n; i++) {
         if(dirs[i] > 0) features[13] += effs[i];
         else features[14] += effs[i];
      }
      if(n > 0) {
         features[13] /= n;
         features[14] /= n;
      }
      
      // Feature 15: Volume normalized
      features[15] = (double)m_volumes[0] / 10000.0;
      
      return true;
   }
   
   // ─── Reset ─────────────────────────────────────────────────────
   void Reset() {
      ArrayFree(m_closes);
      ArrayFree(m_highs);
      ArrayFree(m_lows);
      ArrayFree(m_opens);
      ArrayFree(m_volumes);
      ArrayFree(m_times);
      ArrayFree(m_tick_up);
      ArrayFree(m_tick_down);
      m_tick_count = 0;
      m_bar_count = 0;
   }
};
