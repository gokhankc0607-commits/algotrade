# -*- coding: utf-8 -*-
"""
Algotrade Nexus Pro 7.35 — Unit Tests
Test: Modül testleri, strateji mantığı, hesaplamalar
"""
import unittest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestNexusSettings(unittest.TestCase):
    """Test: Nexus ayar sınıfı"""
    
    def test_input_count(self):
        """372 input olmalı"""
        # Bu test, tüm inputların tanımlandığını doğrular
        # Gerçek test için MQL5 tarafında derleme yapılmalı
        self.assertTrue(True)
    
    def test_group_count(self):
        """42 ayar grubu olmalı"""
        self.assertTrue(True)


class TestGridEngine(unittest.TestCase):
    """Test: Grid motor hesaplamaları"""
    
    def test_grid_step_calculation(self):
        """Grid STEP hesaplaması doğru olmalı"""
        # Simüle edilmiş test
        step_value = 200.0
        point = 0.00001  # 5 digit
        expected_step = step_value * point
        self.assertAlmostEqual(expected_step, 0.002, places=5)
    
    def test_grid_tp_calculation(self):
        """Grid TP spread çarpan modu"""
        spread = 20 * 0.00001  # 2.0 point
        tp_value = 2.0
        expected_tp = spread * tp_value
        self.assertAlmostEqual(expected_tp, 0.0004, places=6)
    
    def test_lot_normalization(self):
        """Lot normalizasyonu"""
        lot_step = 0.01
        raw_lot = 0.033
        normalized = round(raw_lot / lot_step) * lot_step
        self.assertEqual(normalized, 0.03)


class TestDirectionEngines(unittest.TestCase):
    """Test: Yön motorları"""
    
    def test_vema_signal(self):
        """VEMA-X sinyal üretimi"""
        # Basit simülasyon
        ema_current = 1.1050
        ema_prev = 1.1045
        spread = 0.0002
        flat_mult = 0.15
        flat_threshold = spread * flat_mult
        
        diff = ema_current - ema_prev
        
        if diff > flat_threshold:
            signal = "BUY"
        elif diff < -flat_threshold:
            signal = "SELL"
        else:
            signal = "NEUTRAL"
        
        self.assertIn(signal, ["BUY", "SELL", "NEUTRAL"])
    
    def test_di_score_calculation(self):
        """DI Smart Check skoru"""
        up_ticks = 65
        down_ticks = 35
        total = 100
        
        di_plus = up_ticks * 100.0 / total
        di_minus = down_ticks * 100.0 / total
        
        self.assertEqual(di_plus, 65.0)
        self.assertEqual(di_minus, 35.0)
    
    def test_consensus_voting(self):
        """Konsensüs oylama"""
        votes = []
        di_vote = "BUY"
        tmi_vote = "BUY"
        ndi_vote = "NEUTRAL"
        aeg_vote = True
        
        votes.append(di_vote)
        votes.append(tmi_vote)
        votes.append(ndi_vote)
        if aeg_vote:
            votes.append("BUY")
        
        min_votes = 2
        buy_votes = sum(1 for v in votes if v == "BUY")
        
        self.assertEqual(buy_votes, 3)
        self.assertGreaterEqual(buy_votes, min_votes)


class TestRiskManagement(unittest.TestCase):
    """Test: Risk yönetimi"""
    
    def test_equity_change_calculation(self):
        """Equity değişim yüzdesi"""
        last_reset = 10000.0
        current = 10250.0
        
        change_pct = (current - last_reset) / last_reset * 100.0
        self.assertAlmostEqual(change_pct, 2.5, places=2)
        
        # Profit reset threshold
        profit_threshold = 2.0
        self.assertGreaterEqual(change_pct, profit_threshold)
    
    def test_loss_calculation(self):
        """Zarar hesabı"""
        last_reset = 10000.0
        current = 9800.0
        
        change_pct = (last_reset - current) / last_reset * 100.0
        self.assertAlmostEqual(change_pct, 2.0, places=2)
    
    def test_lot_penalty(self):
        """Reset sonrası lot kesme"""
        base_lot = 0.10
        reset_count = 150
        step_resets = 100
        step_pct = 10.0
        min_pct = 30.0
        
        step = reset_count // step_resets
        penalty_pct = step * step_pct
        effective_pct = max(min_pct, 100.0 - penalty_pct)
        penalized_lot = base_lot * effective_pct / 100.0
        
        self.assertEqual(effective_pct, 80.0)
        self.assertAlmostEqual(penalized_lot, 0.08, places=3)
    
    def test_drawdown_calculation(self):
        """Drawdown hesabı"""
        peak_equity = 10500.0
        current_equity = 10200.0
        
        drawdown_pct = (peak_equity - current_equity) / peak_equity * 100.0
        self.assertAlmostEqual(drawdown_pct, 2.86, places=1)
    
    def test_win_rate(self):
        """Win rate hesabı"""
        wins = 65
        losses = 35
        total = wins + losses
        
        win_rate = wins / total * 100.0
        self.assertEqual(win_rate, 65.0)
    
    def test_profit_factor(self):
        """Profit factor"""
        total_profit = 1500.0
        total_loss = 1000.0
        
        pf = total_profit / total_loss
        self.assertEqual(pf, 1.5)


class TestIndicators(unittest.TestCase):
    """Test: Teknik indikatörler"""
    
    def test_rsi_calculation(self):
        """RSI hesaplaması"""
        gains = [0.0010, 0.0015, 0.0005, 0.0020, 0.0010]
        losses = [0.0005, 0.0000, 0.0008]
        
        avg_gain = sum(gains) / len(gains)
        avg_loss = sum(losses) / len(losses)
        
        if avg_loss == 0:
            rsi = 100
        else:
            rs = avg_gain / avg_loss
            rsi = 100.0 - (100.0 / (1.0 + rs))
        
        self.assertGreater(rsi, 50)
        self.assertLess(rsi, 100)
    
    def test_atr_calculation(self):
        """ATR hesaplaması (basit)"""
        highs = [1.1100, 1.1110, 1.1120]
        lows = [1.1080, 1.1090, 1.1095]
        closes = [1.1090, 1.1105, 1.1115]
        
        tr_values = []
        for i in range(len(highs) - 1):
            tr = max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i+1]),
                abs(lows[i] - closes[i+1])
            )
            tr_values.append(tr)
        
        atr = sum(tr_values) / len(tr_values) if tr_values else 0
        self.assertGreater(atr, 0)
    
    def test_hurst_exponent(self):
        """Hurst üstel (0.5 = random walk)"""
        # Simüle: trending veri
        hurst = 0.65  # >0.5 trending
        self.assertGreater(hurst, 0.5)
        
        # Simüle: mean-reverting veri
        hurst2 = 0.35  # <0.5 mean-reverting
        self.assertLess(hurst2, 0.5)


class TestTPPROJ(unittest.TestCase):
    """Test: TP-PROJ hacim motoru"""
    
    def test_target_deficit_lot(self):
        """Target deficit lot hesabı"""
        target_profit = 200.0  # $
        atr = 0.0010  # 10 point
        point_value = 10  # $ per point
        expected_lot = target_profit / (atr * point_value)
        
        self.assertGreater(expected_lot, 0)
    
    def test_net_volume_lot(self):
        """Net volume lot hesabı"""
        target_lot = 0.10
        current_same_side_lot = 0.03
        needed_lot = max(0.01, target_lot - current_same_side_lot)
        
        self.assertEqual(needed_lot, 0.07)


class TestSafety(unittest.TestCase):
    """Test: Güvenlik kontrolleri"""
    
    def test_spread_protection(self):
        """Spread koruması"""
        current_spread = 50  # points
        max_allowed = 100
        
        passed = current_spread <= max_allowed
        self.assertTrue(passed)
    
    def test_min_distance(self):
        """Minimum mesafe"""
        last_price = 1.10500
        current_price = 1.10520
        min_distance = 0.00050  # 50 points
        
        actual_distance = current_price - last_price
        passed = actual_distance >= min_distance
        
        self.assertTrue(passed)


class TestNewsFilter(unittest.TestCase):
    """Test: Haber filtresi"""
    
    def test_news_window(self):
        """Haber penceresi"""
        news_time = 1600  # 16:00
        minutes_before = 45
        minutes_after = 30
        current_time = 1545  # 15:45
        
        window_start = news_time - minutes_before
        window_end = news_time + minutes_after
        
        in_window = window_start <= current_time <= window_end
        self.assertTrue(in_window)
    
    def test_currency_filter(self):
        """Para birimi filtresi"""
        currencies = ["USD", "EUR", "GBP"]
        filter_str = "USD,EUR"
        filter_list = [c.strip() for c in filter_str.split(",")]
        
        for f in filter_list:
            self.assertIn(f, currencies)


class TestVIOP(unittest.TestCase):
    """Test: VIOP/Futures"""
    
    def test_session_check(self):
        """Seans kontrolü"""
        current_hour = 10
        current_min = 30
        open_hour, open_min = 9, 20
        close_hour, close_min = 18, 10
        
        current_mins = current_hour * 60 + current_min
        open_mins = open_hour * 60 + open_min
        close_mins = close_hour * 60 + close_min
        
        session_open = open_mins <= current_mins < close_mins
        self.assertTrue(session_open)
    
    def test_expiry_check(self):
        """Vade sonu kontrolü"""
        expiry_hours = 24
        block_hours = 48
        
        blocked = expiry_hours <= block_hours
        self.assertTrue(blocked)


if __name__ == "__main__":
    print("╔═══════════════════════════════════════════════╗")
    print("║  Algotrade Nexus Pro 7.35 — Unit Tests       ║")
    print("╚═══════════════════════════════════════════════╝")
    unittest.main(verbosity=2)
