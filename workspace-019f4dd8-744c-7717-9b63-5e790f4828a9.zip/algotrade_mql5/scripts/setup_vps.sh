#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║  VPS Kurulum Scripti — Algotrade Nexus Pro                      ║
# ║  Windows VPS üzerinde otomatik MT5 + Robot kurulumu             ║
# ╚══════════════════════════════════════════════════════════════════╝
set -e

echo "═══════════════════════════════════════════════"
echo "  VPS Kurulum — Algotrade Nexus Pro 7.35"
echo "═══════════════════════════════════════════════"

# ─── Sistem kontrolü ────────────────────────────────────────────────────────
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "✅ Linux tespit edildi"
    if command -v wine &> /dev/null; then
        echo "✅ Wine mevcut"
    else
        echo "⚠️  Wine kurulması önerilir (MT5 Linux'ta Wine ile çalışır)"
    fi
elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    echo "✅ Windows tespit edildi"
else
    echo "⚠️  Bilinmeyen işletim sistemi: $OSTYPE"
fi

# ─── MT5 kurulumu kontrol ────────────────────────────────────────────────────
MT5_PATHS=(
    "$PROGRAMFILES/MT5 Trading Terminal/terminal64.exe"
    "$PROGRAMFILES(X86)/MT5 Trading Terminal/terminal.exe"
    "$LOCALAPPDATA/Programs/MT5 Trading Terminal/terminal64.exe"
)

MT5_FOUND=""
for path in "${MT5_PATHS[@]}"; do
    if [ -f "$path" ]; then
        MT5_FOUND="$path"
        echo "✅ MT5 bulundu: $path"
        break
    fi
done

if [ -z "$MT5_FOUND" ]; then
    echo "⚠️  MT5 kurulu değil görünüyor."
    echo "   https://www.metatrader5.com/tr/download adresinden indirin."
fi

# ─── Python kurulumu ─────────────────────────────────────────────────────────
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    echo "✅ Python kurulu: $PYTHON_VERSION"
    
    # pip install
    echo "📦 Python bağımlılıkları kuruluyor..."
    pip3 install -q metaquotes numpy pandas scikit-learn pyyaml python-dotenv requests pytz
    echo "✅ Python bağımlılıkları kuruldu"
else
    echo "⚠️  Python 3 kurulması önerilir"
fi

# ─── VPS optimizasyon ayarları ───────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════"
echo "  VPS Optimizasyon Ayarları"
echo "═══════════════════════════════════════════════"

echo ""
echo "📌 WİNDOWS VPS İÇİN ÖNERİLEN AYARLAR:"
echo ""
echo "1. Power Options:"
echo "   → High Performance modunu seçin"
echo "   → Sleep: Never"
echo "   → Hibernation: Disable"
echo ""
echo "2. Windows Update:"
echo "   → Otomatik güncellemeleri kapatın"
echo "   → Bakım saatlerini belirleyin"
echo ""
echo "3. MT5 Ayarları:"
echo "   → Tools → Options → Expert Advisors:"
echo "     ✅ Allow automated trading"
echo "     ✅ Allow DLL imports"
echo "     ✅ Confirm DLL calls (güvenlik için açık)"
echo ""
echo "   → Tools → Options → Charts:"
echo "     Max bars in chart: 10000+"
echo "     Show grid: ✓"
echo ""
echo "4. Network:"
echo "   → MT5 için sabit IP / Kalıcı internet bağlantısı"
echo "   → UPS (kesintisiz güç kaynağı) önerilir"
echo ""
echo "5. MetaEditor Derleme:"
echo "   → MetaEditor'da F7 ile derleyin"
echo "   → 0 errors, 0 warnings hedefleyin"
echo ""
echo "6. Başlangıç:"
echo "   → MT5'i Windows Startup'a ekleyin"
echo "   → Görev Zamanlayıcı'dan otomatik başlatma ayarlayın"
echo ""
echo "═══════════════════════════════════════════════"
echo "  Kurulum tamamlandı"
echo "═══════════════════════════════════════════════"
