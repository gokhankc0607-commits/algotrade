#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Algotrade Nexus Pro 7.35 — Python Backtester
MT5 Python API ile Strategy Tester simülasyonu
NOT: Bu simülasyon gerçek backtest yerine GEÇMİŞ VERİ ile
     strateji mantığını test eder. Gerçek backtest için
     MT5 Strategy Tester kullanılmalıdır.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import argparse
import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import yaml

# Indicator hesaplamaları
def calculate_ema(data, period):
    return data.ewm(span=period, adjust=False).mean()

def calculate_rsi(data, period=14):
    delta = data.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.ewm(com=period-1, adjust=False).mean()
    avg_loss = loss.ewm(com=period-1, adjust=False).mean()
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def calculate_atr(high, low, close, period=14):
    tr = np.maximum(high - low,
                    np.maximum(np.abs(high - close.shift(1)),
                               np.abs(low - close.shift(1))))
    atr = tr.rolling(period).mean()
    return atr

class NexusBacktester:
    def __init__(self, symbol, timeframe, start_date, end_date,
                 initial_balance=10000, lot=0.01):
        self.symbol = symbol
        self.timeframe = timeframe
        self.start_date = start_date
        self.end_date = end_date
        self.initial_balance = initial_balance
        self.lot = lot
        
        self.balance = initial_balance
        self.equity = initial_balance
        self.positions = []
        self.closed_trades = []
        self.trade_count = 0
        self.win_count = 0
        self.loss_count = 0
        self.total_profit = 0
        self.total_loss = 0
        self.max_drawdown = 0
        self.peak_equity = initial_balance
        
        self.vema_ema15 = 0
        self.vema_prev_ema15 = 0
        
        # Settings (defaults)
        self.enable_grid = True
        self.grid_step = 200  # points
        self.grid_tp = 2.0    # spread multiplier
        self.vg_enable = True
        self.vg_lot_value = 0.01
        self.global_profit_pct = 2.0
        self.global_loss_pct = 2.0
        
    def load_data(self):
        """MT5'ten tarihsel veri yükle"""
        if not mt5.initialize():
            print("MT5 başlatılamadı")
            return False
            
        rates = mt5.copy_rates_range(
            self.symbol, self.timeframe,
            self.start_date, self.end_date
        )
        
        if rates is None or len(rates) == 0:
            print("Veri yüklenemedi")
            return False
        
        self.data = pd.DataFrame(rates)
        self.data['time'] = pd.to_datetime(self.data['time'], unit='s')
        self.data.set_index('time', inplace=True)
        
        print(f"✅ Veri yüklendi: {len(self.data)} bar")
        print(f"   Periyot: {self.data.index[0]} - {self.data.index[-1]}")
        
        return True
    
    def calculate_indicators(self):
        """Teknik indikatörleri hesapla"""
        self.data['EMA15'] = calculate_ema(self.data['close'], 15)
        self.data['EMA8'] = calculate_ema(self.data['close'], 8)
        self.data['EMA21'] = calculate_ema(self.data['close'], 21)
        self.data['RSI'] = calculate_rsi(self.data['close'], 14)
        self.data['ATR'] = calculate_atr(
            self.data['high'], self.data['low'], self.data['close'], 14)
        
        # VEMA direction
        self.data['VEMA_diff'] = self.data['EMA15'].diff()
        
        # Signal
        self.data['Signal'] = 'NEUTRAL'
        spread_mult = 0.15
        flat_threshold = self.data['spread'] * spread_mult * 1e-5
        
        self.data.loc[self.data['VEMA_diff'] > flat_threshold, 'Signal'] = 'BUY'
        self.data.loc[self.data['VEMA_diff'] < -flat_threshold, 'Signal'] = 'SELL'
        
        print(f"   BUY sinyali: {(self.data['Signal']=='BUY').sum()}")
        print(f"   SELL sinyali: {(self.data['Signal']=='SELL').sum()}")
        print(f"   NEUTRAL: {(self.data['Signal']=='NEUTRAL').sum()}")
    
    def run(self):
        """Backtest çalıştır"""
        if not self.load_data():
            return
        self.calculate_indicators()
        
        print(f"\n{'='*50}")
        print(f"  Backtest Başlıyor")
        print(f"{'='*50}")
        print(f"  Sembol: {self.symbol}")
        print(f"  Timeframe: {self.timeframe}")
        print(f"  Başlangıç: {self.initial_balance}")
        print(f"  Lot: {self.lot}")
        print(f"  Grid: {'Açık' if self.vg_enable else 'Kapalı'}")
        print(f"  Grid Step: {self.grid_step} pips")
        print(f"{'='*50}\n")
        
        for idx, row in self.data.iterrows():
            # Equity güncelle
            self.equity = self.balance
            for pos in self.positions:
                if pos['type'] == 'BUY':
                    pnl = (row['close'] - pos['entry_price']) * pos['lot'] * 100000
                else:
                    pnl = (pos['entry_price'] - row['close']) * pos['lot'] * 100000
                pos['current_pnl'] = pnl
            
            pos_pnl = sum(p['current_pnl'] for p in self.positions)
            self.equity = self.balance + pos_pnl
            
            if self.equity > self.peak_equity:
                self.peak_equity = self.equity
            
            drawdown = (self.peak_equity - self.equity) / self.peak_equity
            if drawdown > self.max_drawdown:
                self.max_drawdown = drawdown
            
            # Signal'e göre pozisyon aç
            signal = row['Signal']
            
            if signal == 'BUY' and not self._has_position_type('BUY'):
                self._open_position('BUY', row['close'])
            elif signal == 'SELL' and not self._has_position_type('SELL'):
                self._open_position('SELL', row['close'])
            
            # Global reset kontrolü
            equity_change = (self.equity - self.balance) / self.balance * 100.0
            if equity_change >= self.global_profit_pct:
                self._global_reset('PROFIT')
            elif equity_change <= -self.global_loss_pct:
                self._global_reset('LOSS')
        
        self._close_all_positions(self.data.iloc[-1]['close'])
        self._print_results()
    
    def _open_position(self, direction, price):
        self.positions.append({
            'type': direction,
            'entry_price': price,
            'lot': self.lot,
            'entry_time': self.data.index[-1],
            'current_pnl': 0
        })
        self.trade_count += 1
    
    def _has_position_type(self, direction):
        return any(p['type'] == direction for p in self.positions)
    
    def _close_position(self, idx, close_price):
        pos = self.positions[idx]
        if pos['type'] == 'BUY':
            pnl = (close_price - pos['entry_price']) * pos['lot'] * 100000
        else:
            pnl = (pos['entry_price'] - close_price) * pos['lot'] * 100000
        
        self.balance += pnl
        
        self.closed_trades.append({
            'type': pos['type'],
            'entry': pos['entry_price'],
            'exit': close_price,
            'lot': pos['lot'],
            'pnl': pnl,
            'entry_time': pos['entry_time'],
        })
        
        if pnl > 0:
            self.win_count += 1
            self.total_profit += pnl
        else:
            self.loss_count += 1
            self.total_loss += abs(pnl)
        
        self.positions.pop(idx)
    
    def _close_all_positions(self, close_price):
        for i in range(len(self.positions) - 1, -1, -1):
            self._close_position(i, close_price)
    
    def _global_reset(self, reason):
        print(f"  [RESET] {reason}: Equity={self.equity:.2f}")
        self._close_all_positions(self.data.iloc[-1]['close'])
        self.balance = self.equity
    
    def _print_results(self):
        print(f"\n{'='*50}")
        print(f"  BACKTEST SONUÇLARI")
        print(f"{'='*50}")
        print(f"  İşlem Sayısı:     {self.trade_count}")
        print(f"  Kazanan:          {self.win_count}")
        print(f"  Kaybeden:         {self.loss_count}")
        print(f"  Win Rate:         {self.win_count/max(self.trade_count,1)*100:.1f}%")
        print(f"  Toplam Kâr:       ${self.total_profit:.2f}")
        print(f"  Toplam Zarar:     ${self.total_loss:.2f}")
        if self.total_loss > 0:
            print(f"  Profit Factor:    {self.total_profit/self.total_loss:.2f}")
        print(f"  Net Kâr/Zarar:    ${self.total_profit - self.total_loss:.2f}")
        print(f"  Son Bakiye:       ${self.balance:.2f}")
        print(f"  Max Drawdown:     {self.max_drawdown*100:.2f}%")
        print(f"  ROI:              {(self.balance-self.initial_balance)/self.initial_balance*100:.2f}%")
        print(f"{'='*50}")


def main():
    parser = argparse.ArgumentParser(description='Algotrade Nexus Pro Backtester')
    parser.add_argument('--symbol', default='EURUSD', help='Sembol')
    parser.add_argument('--tf', default=mt5.TIMEFRAME_M1, help='Timeframe')
    parser.add_argument('--days', type=int, default=30, help='Gün sayısı')
    parser.add_argument('--balance', type=float, default=10000, help='Başlangıç bakiyesi')
    parser.add_argument('--lot', type=float, default=0.01, help='Lot')
    parser.add_argument('--config', default='', help='YAML ayar dosyası')
    
    args = parser.parse_args()
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=args.days)
    
    tester = NexusBacktester(
        symbol=args.symbol,
        timeframe=args.tf,
        start_date=start_date,
        end_date=end_date,
        initial_balance=args.balance,
        lot=args.lot
    )
    
    if args.config:
        with open(args.config, 'r') as f:
            config = yaml.safe_load(f)
            tester.enable_grid = config.get('vg_enable', True)
            tester.grid_step = config.get('vg_step_value', 200)
            tester.global_profit_pct = config.get('global_profit_pct', 2.0)
            tester.global_loss_pct = config.get('global_loss_pct', 2.0)
    
    tester.run()
    
    mt5.shutdown()


if __name__ == "__main__":
    main()
