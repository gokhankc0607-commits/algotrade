#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║  ALGOTRADE NEXUS PRO 7.35 — Kurulum Scriptu                     ║
# ║  MT5 MQL5 Kurulum — Otomatik Dosya Yerleştirme                  ║
# ╚══════════════════════════════════════════════════════════════════╝
set -e

echo "═══════════════════════════════════════════════"
echo "  Algotrade Nexus Pro 7.35 — Kurulum"
echo "═══════════════════════════════════════════════"

# ─── Kullanıcıdan bilgi al ───────────────────────────────────────────────
read -p "MT5 Data Folder yolunu girin (örn: ~/.wine/drive_c/ProgramData/MetaQuotes/Terminal/XX...): " MT5_PATH
MT5_PATH="${MT5_PATH/#\~/$HOME}"

if [ ! -d "$MT5_PATH" ]; then
    echo "❌ HATA: Klasör bulunamadı: $MT5_PATH"
    echo "   MT5'i açın ve File → Open Data Folder yolunu kopyalayın."
    exit 1
fi

echo "✅ MT5 Path: $MT5_PATH"

# ─── Hedef klasörler ───────────────────────────────────────────────────────
MQL5_DIR="$MT5_PATH/MQL5"
EXPERTS_DIR="$MQL5_DIR/Experts"
INCLUDE_DIR="$MQL5_DIR/Include"
SOUNDS_DIR="$MT5_PATH/Sounds"
FILES_DIR="$MQL5_DIR/Files"
LOGS_DIR="$MT5_PATH/logs"

echo ""
echo "Hedef klasörler:"
echo "  Experts: $EXPERTS_DIR"
echo "  Include: $INCLUDE_DIR"
echo "  Sounds:  $SOUNDS_DIR"
echo "  Files:    $FILES_DIR"
echo "  Logs:    $LOGS_DIR"

# ─── Klasörleri oluştur ───────────────────────────────────────────────────
echo ""
echo "📁 Klasörler oluşturuluyor..."
mkdir -p "$EXPERTS_DIR/Algotrade"
mkdir -p "$INCLUDE_DIR/Algotrade"
mkdir -p "$SOUNDS_DIR/Nexus"
mkdir -p "$FILES_DIR"
mkdir -p "$LOGS_DIR"

# ─── Dosyaları kopyala ────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$(dirname "$SCRIPT_DIR")"

echo ""
echo "📋 Dosyalar kopyalanıyor..."

# Main EA
if [ -f "$SOURCE_DIR/AlgoTrade_Nexus_Pro_09.07.rewrite.mq5" ]; then
    cp "$SOURCE_DIR/AlgoTrade_Nexus_Pro_09.07.rewrite.mq5" \
       "$EXPERTS_DIR/Algotrade/"
    echo "  ✅ Main EA (.mq5) → Experts/Algotrade/"
else
    echo "  ⚠️  Main EA dosyası bulunamadı"
fi

# Include dosyaları
if [ -d "$SOURCE_DIR/include" ]; then
    cp "$SOURCE_DIR/include/"*.mqh "$INCLUDE_DIR/Algotrade/" 2>/dev/null || true
    echo "  ✅ Include (.mqh) → Include/Algotrade/"
fi

# Derlenmiş dosya (varsa)
if [ -f "$SOURCE_DIR/AlgoTrade_Nexus_Pro_09.07.rewrite.ex5" ]; then
    cp "$SOURCE_DIR/AlgoTrade_Nexus_Pro_09.07.rewrite.ex5" \
       "$EXPERTS_DIR/Algotrade/"
    echo "  ✅ Derlenmiş EA (.ex5) → Experts/Algotrade/"
fi

# ONNX model (varsa)
if [ -f "$SOURCE_DIR/models/nexus_regime_v2.onnx" ]; then
    cp "$SOURCE_DIR/models/"*.onnx "$FILES_DIR/"
    echo "  ✅ ONNX model → Files/"
fi

# Logs klasörü ayarları
if [ ! -f "$LOGS_DIR/.gitkeep" ]; then
    touch "$LOGS_DIR/.gitkeep"
fi

echo ""
echo "═══════════════════════════════════════════════"
echo "  Kurulum Tamamlandı!"
echo "═══════════════════════════════════════════════"
echo ""
echo "📌 SONRAKİ ADIMLAR:"
echo ""
echo "1. MetaTrader 5'i açın"
echo "2. Navigator → Experts'te 'AlgoTrade Nexus Pro 09.07.rewrite'ı görmelisiniz"
echo "3. Sembol grafiği açın (örn: EURUSD M1)"
echo "4. Robotu grafiğe sürükleyin"
echo "5. Input sekmesinde:"
echo "   - PanelLanguage → LANG_TR (Türkçe)"
echo "   - FixedLot → 0.01"
echo "   - VG_LotValue → 0.01"
echo "   - VG_StepValue → 300 (başlangıç için)"
echo "6. Allow automated trading iznini verin"
echo "7. Journal sekmesinde başlatma mesajlarını kontrol edin"
echo ""
echo "⚠️  ÖNEMLİ:"
echo "   - İlk önce Strategy Tester'da test edin"
echo "   - Sonra Demo hesapta en az 2 hafta test edin"
echo "   - Grid STEP ve LOT ayarlarını sembole göre ayarlayın"
echo "   - VPS kullanımı kesintisiz çalışma için önerilir"
echo ""

# ─── Kurulum bilgilerini kaydet ───────────────────────────────────────────
echo "Kurulum tarihi: $(date)" > "$MT5_PATH/nexus_install_info.txt"
echo "MT5 Path: $MT5_PATH" >> "$MT5_PATH/nexus_install_info.txt"
echo "EA Path: $EXPERTS_DIR/Algotrade/" >> "$MT5_PATH/nexus_install_info.txt"
