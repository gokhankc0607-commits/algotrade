# 🤖 ALGOTRADE NEXUS PRO 7.35 - PYTHON CLONE
**Sürüm:** 7.35 | **Platform:** Python 3.10+ | **API:** MetaTrader 5 (MT5) + Metatrader Python API

Bu proje, Algotrade Nexus Pro 7.35 Expert Advisor'ın Python ile yeniden yazılmış
bağımsız bir klonudur. MT5 Terminal'e bağlanarak aynı stratejileri, grid motorlarını,
ML entegrasyonunu ve koruma sistemlerini çalıştırır.

## 📦 ÖZELLİKLER

- ✅ 3 Yön Motoru (VEMA-X, First Touch, Classic Live)
- ✅ R21 Sanal Gapless Grid (Hedging + Netting)
- ✅ TP-PROJ Hacim Motoru (7 rejim)
- ✅ Haber Filtresi (MT5 Calendar)
- ✅ VIOP/Futures Güvenlik Sistemi
- ✅ ONNX Model Entegrasyonu
- ✅ Shadow Trade Journal
- ✅ Global/Günlük/Zaman Resetleri
- ✅ Drawdown Hedge
- ✅ 42 Ayar Grubu, 372 Input
- ✅ 13 Dil Desteği
- ✅ Web Panel UI (Dash/dəniz)

## 🚀 HIZLI BAŞLANGIÇ

```bash
# 1. Kurulum scriptini çalıştırın
bash scripts/install.sh

# 2. .env dosyasını düzenleyin
cp config/.env.example config/.env
nano config/.env

# 3. Robotu başlatın
python src/main.py --config config/presets/conservative_demo.json

# 4. Web paneli açın
python src/ui/panel_server.py
# Tarayıcıda: http://localhost:8050
```

## 📁 PROJE YAPISI

```
algotrade_nexus_pro/
├── src/
│   ├── main.py                 # Ana giriş noktası
│   ├── nexus_bot.py            # Ana Robot sınıfı
│   ├── config/
│   │   ├── settings.py         # 372 input + 42 ayar grubu
│   │   ├── enums.py           # Tüm enum tipleri
│   │   └── defaults.py         # Varsayılan değerler
│   ├── engines/
│   │   ├── direction_selector.py    # Yön motoru seçici
│   │   ├── vema_engine.py          # VEMA-X motor
│   │   ├── first_touch_engine.py   # First Touch motor
│   │   ├── classic_live_engine.py  # Classic Live motor
│   │   ├── di_check.py             # Direction Smart Check
│   │   ├── tmi_check.py            # Early Trend Check
│   │   ├── awr_check.py            # Trend/Range Check
│   │   ├── ndi_check.py            # Nexus Direction Intelligence
│   │   ├── dte_check.py            # Direction Truth Meta Filter
│   │   ├── consensus.py            # Trend Konsensüs
│   │   ├── aeg_governor.py         # Asymmetric Expectancy Governor
│   │   ├── heg_governor.py         # Hyperactive Edge Governor
│   │   └── udc_router.py           # Final Direction Decision
│   ├── grid/
│   │   ├── r21_grid.py         # R21 Sanal Gapless Grid
│   │   ├── grid_tp.py          # Grid TP yönetimi
│   │   ├── pyramid.py          # Piramit sistemi
│   │   ├── escape_fund.py      # Escape Fund sistemi
│   │   └── loop_harvest.py     # Loop Harvest sistemi
│   ├── trend/
│   │   ├── bullet_trend.py     # Trend/Bullet motoru
│   │   ├── lot_calculator.py  # Lot hesaplama
│   │   ├── tp_proj.py          # TP-PROJ hacim motoru
│   │   ├── profit_lock.py      # Profit Lock
│   │   ├── bonus_tp.py         # Bonus TP
│   │   └── flip_manager.py     # Trend Flip yönetimi
│   ├── safety/
│   │   ├── spread_guard.py     # Spread koruması
│   │   ├── loss_guard.py       # Aynı yön zarar güvenliği
│   │   ├── min_distance.py    # Minimum mesafe
│   │   ├── entry_quality.py    # Giriş kalite kontrolü
│   │   └── loss_block.py       # Zarar bloklama
│   ├── news/
│   │   ├── news_filter.py     # Haber filtresi
│   │   ├── calendar.py        # MT5 Calendar entegrasyonu
│   │   └── hedge_manager.py   # Haber hedge yönetimi
│   ├── viop/
│   │   ├── session_control.py  # Seans kontrolü
│   │   ├── expiry_protection.py # Vade koruması
│   │   └── rollover.py         # Vade geçişi
│   ├── ml/
│   │   ├── onnx_predictor.py  # ONNX model entegrasyonu
│   │   ├── ml_logger.py        # ML veri kaydı
│   │   └── shadow_journal.py   # Shadow Trade Journal
│   ├── risk/
│   │   ├── drawdown_hedge.py  # Drawdown hedge
│   │   ├── reset_manager.py   # Reset yönetimi
│   │   ├── daily_lock.py      # Günlük kâr/zarar kilidi
│   │   ├── time_limit.py      # Zaman limitli kapanış
│   │   └── auto_tune.py       # Auto Tuning
│   ├── execution/
│   │   ├── mt5_connector.py   # MT5 API bağlantısı
│   │   ├── order_manager.py   # Emir gönderimi
│   │   ├── position_manager.py # Pozisyon yönetimi
│   │   └── magic_manager.py  # Magic numara yönetimi
│   ├── utils/
│   │   ├── tick_processor.py  # Tick işleme
│   │   ├── statistics.py     # İstatistik hesaplama
│   │   ├── sound_alerts.py   # Sesli uyarılar
│   │   ├── csv_logger.py     # CSV loglama
│   │   └── global_vars.py    # Global değişken yönetimi
│   └── ui/
│       ├── panel_server.py   # Dash web panel sunucusu
│       └── components.py     # Panel bileşenleri
├── config/
│   ├── .env.example          # Ortam değişkenleri şablonu
│   ├── presets/              # Hazır ayar senaryoları
│   │   ├── conservative_demo.json
│   │   ├── grid_only.json
│   │   ├── trend_proj.json
│   │   ├── aggressive.json
│   │   └── viop_futures.json
│   └── symbols.json          # Sembol konfigürasyonları
├── logs/                     # Log dosyaları
├── models/                  # ONNX model dosyaları
├── data/                    # ML/Shadow CSV verileri
├── tests/
│   ├── test_engines.py
│   ├── test_grid.py
│   ├── test_news.py
│   ├── test_viop.py
│   └── test_ml.py
├── scripts/
│   ├── install.sh            # Kurulum scripti
│   ├── start_demo.sh         # Demo başlatma
│   ├── start_real.sh        # Gerçek hesap başlatma
│   ├── setup_vps.sh         # VPS kurulum
│   └── check_dependencies.py # Bağımlılık kontrolü
├── requirements.txt
└── LICENSE
```

## ⚙️ MANDATORY DEPENDENCIES

```
metaquotes>=1.2        # MT5 Python API ( resmi )
numpy>=1.24
pandas>=2.0
scikit-learn>=1.3
onnxruntime>=1.16     # ONNX inference
pyyaml>=6.0
python-dotenv>=1.0
dash>=2.14             # Web panel
plotly>=5.18           # Grafikler
requests>=2.31         # HTTP istekleri
pytz>=2024.1
```

## ⚠️ RİSK UYARISI

```
Bu kod KÂR GARANTİSİ VERMEZ.
Forex, CFD ve vadeli işlem piyasalarında sermayenin bir kısmı
veya tamamı KAYBEDİLEBİLİR.

Grid, hedge, TP-PROJ, lot artırma, sanal TP ve sabit Stop Loss
bulunmayan yönetimler riski ARTIRIR.

ZORUNLU TEST SIRASI:
1. Strategy Tester (backtest)
2. Demo hesap (minimum 2 hafta)
3. Küçük sabit lot (0.01)
4. Gerçek hesap
```

## 📋 LISANS

Bu proje eğitim amaçlı oluşturulmuştur.
Gerçek ticaret kullanımı için lisans koşullarını kontrol edin.

**Orijinal:** Algotrade Nexus Pro 7.35 (MQL5)
**Klon:** Python 3.10+ Implementation
