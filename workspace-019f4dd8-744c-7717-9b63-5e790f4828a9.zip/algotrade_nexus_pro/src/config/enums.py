# ─────────────────────────────────────────────────────────────────────────────
# ALGOTRADE NEXUS PRO 7.35 - ENUM TİPLERİ
# src/config/enums.py
# ─────────────────────────────────────────────────────────────────────────────
"""Tüm enum seçenekleri — Orijinal MQL5 EA'daki enum'ların Python karşılığı."""

from __future__ import annotations
from enum import IntEnum
from typing import List


# ──────────────────────────────── LANG ENUM ────────────────────────────────
class LangEnum(IntEnum):
    """Panel dili seçenekleri (13 dil)."""
    LANG_EN = 0    # İngilizce
    LANG_TR = 1    # Türkçe
    LANG_KU = 2    # Kürtçe
    LANG_RU = 3    # Rusça
    LANG_HI = 4    # Hintçe
    LANG_ZH = 5    # Çince
    LANG_FR = 6    # Fransızca
    LANG_AR = 7    # Arapça
    LANG_FA = 8    # Farsça
    LANG_DE = 9    # Almanca
    LANG_IT = 10   # İtalyanca
    LANG_PT = 11   # Portekizce
    LANG_ES = 12   # İspanyolca

    @classmethod
    def lang_name(cls, value: int) -> str:
        names = {
            0: "English", 1: "Türkçe", 2: "Kurdî",
            3: "Русский", 4: "हिन्दी", 5: "中文",
            6: "Français", 7: "العربية", 8: "فارسی",
            9: "Deutsch", 10: "Italiano", 11: "Português", 12: "Español"
        }
        return names.get(value, "Unknown")


# ──────────────────────────────── DIRECTION ENGINE ────────────────────────
class DirectionEngineModeEnum(IntEnum):
    """Yön motoru seçimi."""
    DIR_ENGINE_VEMA = 0       # VEMA-X — varsayılan
    DIR_ENGINE_FIRST_TOUCH = 1  # First Touch olasılık
    DIR_ENGINE_CLASSIC = 2      # Classic Live faz-enerji


# ──────────────────────────────── LOT MODES ───────────────────────────────
class BulletLotModeEnum(IntEnum):
    """Trend lot hesaplama modları."""
    BLM_AUTO = 0      # Bakiye/equity yüzdesi (varsayılan)
    BLM_MANUAL = 1   # Sabit lot
    BLM_PROJECT = 2   # TP-PROJ ile projekte lot


class LotTypeEnum(IntEnum):
    """Temel lot tipi."""
    Fixed = 0
    Auto = 1


class GridLotModeEnum(IntEnum):
    """Grid lot modları."""
    GLM_FIXED = 0        # Sabit lot (varsayılan)
    GLM_BALANCE_PCT = 1  # Bakiye yüzdesi
    GLM_EQUITY_PCT = 2   # Equity yüzdesi


# ──────────────────────────────── TP-PROJ ────────────────────────────────
class TPProjVolumeRegimeEnum(IntEnum):
    """TP-PROJ hacim rejimleri."""
    TPP_REG_FIXED = 0               # TP hedef kasası izlenir
    TPP_REG_BALANCE_PCT = 1         # Temel bakiye/equity yüzdesi
    TPP_REG_TARGET_DEFICIT = 2       # Hedef para açığı / beklenen hareket
    TPP_REG_CONTROLLED_RECOVERY = 3  # Tamamlanan zarar bloklarına göre lot artışı
    TPP_REG_NET_VOLUME_TARGET = 4    # Mevcut lot düşülerek eksik hacim açılır
    TPP_REG_SOLVER = 5              # Açık sepeti simüle ederek hedefi çözen en küçük ek lot (varsayılan)


class TPProjStartModeEnum(IntEnum):
    """TP-PROJ başlangıç modu."""
    TPP_START_FIXED_LOT = 0          # Sabit lot ile başla
    TPP_START_PROJECTED_LOT = 1      # Projekte lot ile başla (varsayılan)


class TPProjGlobalResetStartEnum(IntEnum):
    """Reset sonrası TP-PROJ davranışı."""
    TPP_GRESET_KEEP_PEAK_LOGIC = 0  # Peak mantığını koru (varsayılan)
    TPP_GRESET_FIXED_LOT = 1        # Sabit lot ile başla
    TPP_GRESET_PROJECTED_LOT = 2    # Projekte lot ile başla


# ──────────────────────────────── GRID ────────────────────────────────────
class GridTPModeEnum(IntEnum):
    """Grid TP modları."""
    GTP_SPREAD_MULT = 0      # Spread çarpanı (varsayılan)
    GTP_BALANCE_PCT = 1      # Bakiye yüzdesi
    GTP_FIXED_POINTS = 2     # Sabit point
    GTP_PRICE_PCT = 3        # Fiyat yüzdesi


class GridStepModeEnum(IntEnum):
    """Grid STEP modları."""
    GST_FIXED_POINTS = 0   # Sabit point (varsayılan)
    GST_RANGE_MULT = 1     # Range çarpanı
    GST_PRICE_PCT = 2      # Fiyat yüzdesi


class GridTrendSourceEnum(IntEnum):
    """Grid trend kaynağı."""
    VGTS_MICRO_FLOW = 0   # Mikro akış (varsayılan)
    VGTS_TREND_ENGINE = 1  # Trend motoru


# ──────────────────────────────── DIRECTION ────────────────────────────────
class DirectionPermissionEnum(IntEnum):
    """Yön izni."""
    DPERM_BOTH = 0   # Her iki yön de açık
    DPERM_BUY = 1    # Sadece BUY
    DPERM_SELL = 2    # Sadece SELL


class PureShadowBypassEnum(IntEnum):
    """Pure Shadow bypass modları."""
    PSB_STRATEGY = 0    # Strateji bazlı (varsayılan)
    PSB_ENGINES = 1     # Motor bazlı
    PSB_NONE = 2        # Bypass yok


# ──────────────────────────────── NDI ────────────────────────────────────
class NDIProfileEnum(IntEnum):
    """NDI profil seçenekleri."""
    NDI_MORE_TRADES = 0  # Daha fazla işlem
    NDI_BALANCED = 1     # Dengeli (varsayılan)
    NDI_SELECTIVE = 2    # Seçici


class NDIFlipSafetyEnum(IntEnum):
    """NDI flip güvenlik seviyesi."""
    NDI_FLIP_NORMAL = 0      # Normal
    NDI_FLIP_STRONG = 1      # Güçlü (varsayılan)
    NDI_FLIP_VERY_STRONG = 2  # Çok güçlü


# ──────────────────────────────── AWR ────────────────────────────────────
class AWRRegimeSrcEnum(IntEnum):
    """Trend/Range veri kaynağı."""
    AWR_SRC_VR_TF = 0        # VR time frame
    AWR_SRC_PULSE_TICK = 1   # Pulse tick
    AWR_SRC_ENSEMBLE = 2     # Topluluk (varsayılan)


# ──────────────────────────────── VIOP ────────────────────────────────────
class VIOPDetectModeEnum(IntEnum):
    """VIOP tespit modu."""
    VIOP_DETECT_AUTO = 0   # Otomatik tespit (varsayılan)
    VIOP_FORCE_ON = 1      # Zorla açık
    VIOP_FORCE_OFF = 2     # Zorla kapalı


class VIOPRolloverModeEnum(IntEnum):
    """VIOP rollover modu."""
    VIOP_ROLLOVER_OFF = 0           # Kapalı
    VIOP_ROLLOVER_SUGGEST = 1       # Sadece öneri (varsayılan)
    VIOP_ROLLOVER_AUTO_SWITCH = 2   # Otomatik switch


# ──────────────────────────────── SCHEDULE ────────────────────────────────
class TimeFilterActionEnum(IntEnum):
    """Haftalık saat dışı eylem."""
    TFA_BLOCK_NEW = 0      # Yeni girişleri engelle (varsayılan)
    TFA_CLOSE_PROFIT = 1   # Kârlıları kapat
    TFA_CLOSE_ALL = 2      # Tümünü kapat
    TFA_NET_HEDGE = 3      # Net hedge


class TimeFilterClockEnum(IntEnum):
    """Saat kaynağı."""
    TFC_BROKER = 0  # Broker saati (varsayılan)
    TFC_LOCAL = 1   # Yerel saat
    TFC_UTC = 2     # UTC saat


# ──────────────────────────────── RESET ────────────────────────────────────
class TimeResetModeEnum(IntEnum):
    """Zaman limit sonrası eylem."""
    TR_CLOSE_ALL = 0      # Tümünü kapat (varsayılan)
    TR_CLOSE_PROFIT = 1   # Kârlıları kapat
    TR_CLOSE_LOSS = 2    # Zararlıları kapat


class AutoTuneRiskProfile(IntEnum):
    """Auto Tune risk profili."""
    RISK_ULTRA_SAFE = 0     # Ultra güvenli
    RISK_CONSERVATIVE = 1   # Muhafazakâr
    RISK_BALANCED = 2       # Dengeli (varsayılan)
    RISK_AGGRESSIVE = 3     # Agresif
    RISK_ULTRA_AGGR = 4    # Ultra agresif


class DailyGuardScopeEnum(IntEnum):
    """Günlük kapsam."""
    DGS_ROBOT = 0     # Robot bazlı
    DGS_ACCOUNT = 1   # Hesap bazlı (varsayılan)


class DailyGuardClockEnum(IntEnum):
    """Günlük saat modu."""
    DGC_BROKER = 0  # Broker saati (varsayılan)
    DGC_LOCAL = 1   # Yerel saat


# ──────────────────────────────── ENGINE ───────────────────────────────────
class EngineOverrideEnum(IntEnum):
    """Motor override modları."""
    ENG_AUTO = 0       # Otomatik (varsayılan)
    ENG_TREND = 1      # Trend motoru ağırlıklı
    ENG_GRID = 2       # Grid motoru ağırlıklı


class EngineDecisionEnum(IntEnum):
    """Motor karar türü."""
    EDEC_GRID = 0    # Grid kararı
    EDEC_TREND = 1   # Trend kararı


# ──────────────────────────────── CLOSE REASON ────────────────────────────
class CloseReasonEnum(IntEnum):
    """Pozisyon kapanış nedeni."""
    CR_OTHER = 0
    CR_GRID_TP = 1
    CR_GLOBAL_TP_RESET = 2
    CR_GLOBAL_RESET = 3
    CR_PROJECT_TP_RESET = 4
    CR_PANEL_FORCE = 5
    CR_PANEL_GLOBAL_FORCE = 6
    CR_TIME_LIMIT_RESET = 7
    CR_FORCED_RESET = 8
    CR_TREND_FLIP = 9
    CR_NEWS_HEDGE = 10
    CR_MANUAL_HEDGE = 11
    CR_TIME_FILTER = 12
    CR_NEWS_CLOSE_ALL = 13
    CR_VIOP_EXPIRY = 14
    CR_DAILY_PROFIT_LOCK = 15
    CR_DAILY_LOSS_LOCK = 16
    CR_TREND_PROFIT_FLIP = 17
    CR_TREND_BONUS_TP = 18
    CR_TREND_PROFIT_LOCK = 19
    CR_AEG_PROFIT_EXIT = 20
    CR_TIME_FILTER_PROFIT = 21
    CR_TIME_LIMIT_PROFIT = 22
    CR_HEDGE_PROFIT_TARGET = 23


# ──────────────────────────────── FEATURE GATE ────────────────────────────
class ProfitCloseFeatureEnum(IntEnum):
    """Kârlı kapanış feature kapıları."""
    PCF_MASTER = 0
    PCF_TREND_FLIP = 1
    PCF_AEG_PROFIT = 2
    PCF_GRID_TP = 3
    PCF_TP_PROJECT = 4
    PCF_GLOBAL_PROFIT_RESET = 5
    PCF_DAILY_PROFIT = 6
    PCF_TIME_FILTER_PROFIT = 7
    PCF_TIME_LIMIT_PROFIT = 8
    PCF_HEDGE_PROFIT = 9
    PCF_BONUS_TP = 10
    PCF_PROFIT_LOCK = 11
    PCF_CLOSE_ALL_WINNERS = 12
    PCF_NEWS_PROFIT = 13
    PCF_SAFETY_PROFIT = 14
    PCF_OTHER_AUTO = 15


class LossCloseFeatureEnum(IntEnum):
    """Zararlı kapanış feature kapıları."""
    LCF_MASTER = 0
    LCF_TREND_FLIP = 1
    LCF_GLOBAL_LOSS_RESET = 2
    LCF_DAILY_LOSS = 3
    LCF_TIME_FILTER_LOSS = 4
    LCF_TIME_LIMIT_LOSS = 5
    LCF_NEWS_LOSS = 6
    LCF_VIOP_LOSS = 7
    LCF_FORCED_LOSS = 8
    LCF_HEDGE_LOSS = 9
    LCF_PROFIT_CYCLE_LOSERS = 10
    LCF_OTHER_AUTO = 11


# ──────────────────────────────── PANEL ────────────────────────────────────
class ActiveTabEnum(IntEnum):
    """Panel aktif sekmesi."""
    TAB_CTRL = 0    # Kontrol
    TAB_TOOLS = 1   # Araç
    TAB_NEWS = 2    # Haber
    TAB_PARAM = 3   # Parametre
    TAB_QUALITY = 4 # Kalite


class PanelDashPageEnum(IntEnum):
    """Panel dashboard sayfası."""
    DASH_STRATEGY = 0   # Strateji
    DASH_TREND = 1      # Trend
    DASH_SYSTEM = 2      # Sistem
    DASH_RESET = 3       # Reset


class NexusKernelStateEnum(IntEnum):
    """Robot kernel durumu."""
    NUK_STATE_BOOT = 0              # Başlangıç
    NUK_STATE_SAFETY_LOCK = 1       # Güvenlik kilidi
    NUK_STATE_MANAGE_ONLY = 2       # Sadece yönetim
    NUK_STATE_WAIT_DIRECTION = 3    # Yön bekleniyor
    NUK_STATE_WAIT_ENTRY = 4        # Giriş bekleniyor
    NUK_STATE_ENTRY_READY = 5       # Giriş hazır
    NUK_STATE_ORDER_PENDING = 6      # Emir bekliyor
    NUK_STATE_POSITION_MANAGE = 7    # Pozisyon yönetimi
    NUK_STATE_COOLDOWN = 8          # Bekleme


# ──────────────────────────────── SIGNAL TYPES ────────────────────────────
class SignalType:
    """Yön sinyali değerleri."""
    BUY = 1
    SELL = -1
    NEUTRAL = 0


class AccountType:
    """Hesap tipi."""
    HEDGING = "hedging"
    NETTING = "netting"
    UNKNOWN = "unknown"
