# ─────────────────────────────────────────────────────────────────────────────
# ALGOTRADE NEXUS PRO 7.35 - 42 AYAR GRUBU, 372 INPUT
# src/config/settings.py
# ─────────────────────────────────────────────────────────────────────────────
"""
Algotrade Nexus Pro 7.35 — Tüm input ayarları ve 42 ayar grubu.
Orijinal MQL5 EA'daki 372 input'un tam Python karşılığı.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from .enums import (
    LangEnum, DirectionEngineModeEnum, BulletLotModeEnum,
    TPProjVolumeRegimeEnum, TPProjStartModeEnum, TPProjGlobalResetStartEnum,
    GridLotModeEnum, GridTPModeEnum, GridStepModeEnum, GridTrendSourceEnum,
    NDIProfileEnum, NDIFlipSafetyEnum, AWRRegimeSrcEnum,
    VIOPDetectModeEnum, VIOPRolloverModeEnum,
    DailyGuardScopeEnum, DailyGuardClockEnum,
    TimeFilterActionEnum, TimeFilterClockEnum,
    TimeResetModeEnum, AutoTuneRiskProfile,
    LotTypeEnum, DirectionPermissionEnum,
    EngineOverrideEnum, CloseReasonEnum,
    ProfitCloseFeatureEnum, LossCloseFeatureEnum,
    ActiveTabEnum, PanelDashPageEnum, NexusKernelStateEnum,
    PureShadowBypassEnum,
)


# ──────────────────────────────── GROUP 1 ────────────────────────────────────
# DISPLAY (2 input)
@dataclass
class DisplaySettings:
    panel_language: LangEnum = LangEnum.LANG_TR
    inp_panel_scale: float = 1.0


# ──────────────────────────────── GROUP 2 ────────────────────────────────────
# SOUND ALERTS (6 input)
@dataclass
class SoundAlertSettings:
    sound_alerts_enabled: bool = True
    sound_trade_open: str = "nexus_trade_open.wav"
    sound_profit_close: str = "nexus_profit_close.wav"
    sound_loss_close: str = "nexus_loss_close.wav"
    sound_profit_reset: str = "nexus_profit_reset.wav"
    sound_loss_reset: str = "nexus_loss_reset.wav"


# ──────────────────────────────── GROUP 3 ────────────────────────────────────
# DOM / DEPTH OF MARKET (4 input)
@dataclass
class DOMSettings:
    dom_enable: bool = False
    dom_top_levels: int = 5
    dom_fresh_ms: int = 1500
    dom_weight: float = 0.35


# ──────────────────────────────── GROUP 4 ────────────────────────────────────
# CPU / LATENCY OPTIMIZATION (2 input)
@dataclass
class CPUOptimizeSettings:
    cpu_optimization: bool = True
    cpu_signal_refresh_ms: int = 120


# ──────────────────────────────── GROUP 5 ────────────────────────────────────
# ML / LIVE MARKET LEARNING (12 input)
@dataclass
class MLSettings:
    ml_onnx_enable: bool = False
    ml_onnx_model_file: str = "nexus_regime_v2.onnx"
    ml_update_ms: int = 500
    ml_feature_count: int = 16
    ml_output_count: int = 4
    ml_min_trend_prob: float = 0.62
    ml_min_direction_prob: float = 0.58
    ml_weight: float = 0.35
    ml_fallback_heuristic: bool = True
    ml_shadow_only: bool = False
    ml_auto_model_reload: bool = True
    ml_auto_model_reload_sec: int = 300


# ──────────────────────────────── GROUP 6 ────────────────────────────────────
# ML TRAINING DATA LOGGER (7 input)
@dataclass
class MLDataLogSettings:
    ml_data_log_enable: bool = True
    ml_data_log_file_name: str = "nexus_ml_market_training_v3.csv"
    ml_data_log_auto_per_chart: bool = True
    ml_data_log_interval_ms: int = 1000
    ml_data_log_label_horizon_sec: int = 10
    ml_data_log_min_move_atr: float = 0.35
    ml_data_log_max_pending: int = 512


# ──────────────────────────────── GROUP 7 ────────────────────────────────────
# SHADOW TRADE JOURNAL (6 input)
@dataclass
class ShadowTradeSettings:
    shadow_trade_enable: bool = True
    shadow_trade_max_age_sec: int = 300
    shadow_trade_target_atr: float = 1.00
    shadow_trade_risk_atr: float = 0.75
    shadow_trade_rearm_sec: int = 60
    shadow_trade_write_csv: bool = True


# ──────────────────────────────── GROUP 8 ────────────────────────────────────
# DIRECTION ENGINE SELECTOR (10 input)
@dataclass
class DirectionEngineSettings:
    direction_engine_default: DirectionEngineModeEnum = DirectionEngineModeEnum.DIR_ENGINE_VEMA
    trend_reverse_signal_default: bool = False
    micro_trend_reverse_default: bool = False
    pure_shadow_spread_mult: float = 1.50
    pure_shadow_bypass_default: PureShadowBypassEnum = PureShadowBypassEnum.PSB_STRATEGY
    pure_shadow_price_follow_enable: bool = True
    pure_shadow_profit_follow_mult: float = 2.50
    pure_shadow_net_spread_close_enable: bool = True
    pure_shadow_net_profit_spread_mult: float = 3.00
    pure_shadow_net_loss_spread_mult: float = 2.00


# ──────────────────────────────── GROUP 9 ────────────────────────────────────
# VEMA-X LIVE FLOW ARCHITECTURE (3 input)
@dataclass
class VEMASettings:
    ema15_flat_spread_mult: float = 0.15
    ema15_confirm_bars: int = 1
    ema_virtual_bar_seconds: int = 15


# ──────────────────────────────── GROUP 10 ───────────────────────────────────
# FIRST TOUCH PROBABILITY ENGINE (8 input)
@dataclass
class FirstTouchSettings:
    ft_lookback_seconds: int = 1800
    ft_horizon_seconds: int = 45
    ft_launch_every_seconds: int = 3
    ft_barrier_spread_mult: float = 4.0
    ft_barrier_move_mult: float = 6.0
    ft_min_resolved: int = 36
    ft_min_probability: float = 0.58
    ft_confidence_z: float = 1.00


# ──────────────────────────────── GROUP 11 ─────────────────────────────────
# CLASSIC LIVE PHASE-ENERGY ENGINE (10 input)
@dataclass
class ClassicLiveSettings:
    classic_live_window_seconds: int = 36
    classic_live_fast_seconds: int = 7
    classic_live_warmup_seconds: int = 12
    classic_live_entry_confirm_ms: int = 900
    classic_live_flip_confirm_ms: int = 3600
    classic_live_direction_gate: float = 0.24
    classic_live_efficiency_gate: float = 0.16
    classic_live_pullback_min: float = 0.14
    classic_live_pullback_max: float = 0.64
    classic_live_reclaim_ratio: float = 0.34


# ──────────────────────────────── GROUP 12 ─────────────────────────────────
# MAIN TRADING (14 input)
@dataclass
class MainTradingSettings:
    enable_global_trading: bool = True
    enable_buy: bool = True
    enable_sell: bool = True
    grid_direction_permission: DirectionPermissionEnum = DirectionPermissionEnum.DPERM_BOTH
    trend_direction_permission: DirectionPermissionEnum = DirectionPermissionEnum.DPERM_BOTH
    enable_spread_protection: bool = False
    max_allowed_spread: int = 100
    enable_slippage_protection: bool = False
    max_slippage: int = 100
    max_reset_count: int = 9999
    global_profit_pct: float = 2.0
    global_loss_pct: float = 2.0
    withdrawal_neutral_for_loss_reset: bool = True
    allow_reset_when_paused: bool = True


# ──────────────────────────────── GROUP 13 ─────────────────────────────────
# BASIC LOT SIZE (3 input)
@dataclass
class BasicLotSettings:
    lot_type: LotTypeEnum = LotTypeEnum.Auto
    fixed_lot: float = 0.01
    auto_lot_pct: float = 0.01


# ──────────────────────────────── GROUP 14 ─────────────────────────────────
# LOT CUT AFTER RESETS (3 input)
@dataclass
class LotCutSettings:
    lot_penalty_step_resets: int = 100
    lot_penalty_step_pct: float = 10.0
    lot_penalty_min_pct: float = 30.0


# ──────────────────────────────── GROUP 15 ─────────────────────────────────
# TIME LOT BOOST (4 input)
@dataclass
class TimeLotBoostSettings:
    enable_timed_lot_boost: bool = False
    lot_boost_step_hours: int = 8
    lot_boost_step_pct: float = 50.0
    lot_boost_max_pct: float = 1000.0


# ──────────────────────────────── GROUP 16 ─────────────────────────────────
# DRAWDOWN HEDGE (5 input)
@dataclass
class DrawdownHedgeSettings:
    enable_auto_dd_hedge: bool = False
    enable_multi_symbol_hedge: bool = False
    auto_dd_hedge_pct: float = 5.0
    dd_hedge_exit_profit: float = 0.50
    dd_hedge_pause_trading: bool = False


# ──────────────────────────────── GROUP 17 ─────────────────────────────────
# TREND ENGINE (28 input)
@dataclass
class TrendEngineSettings:
    bullet_lot_mode: BulletLotModeEnum = BulletLotModeEnum.BLM_AUTO
    bullet_lot_value: float = 0.50
    tp_proj_volume_regime: TPProjVolumeRegimeEnum = TPProjVolumeRegimeEnum.TPP_REG_SOLVER
    tp_proj_start_mode: TPProjStartModeEnum = TPProjStartModeEnum.TPP_START_PROJECTED_LOT
    tp_proj_after_profit_reset: TPProjGlobalResetStartEnum = TPProjGlobalResetStartEnum.TPP_GRESET_KEEP_PEAK_LOGIC
    tp_proj_after_loss_reset: TPProjGlobalResetStartEnum = TPProjGlobalResetStartEnum.TPP_GRESET_KEEP_PEAK_LOGIC
    bullet_auto_volume: bool = True
    bullet_loss_block_enable: bool = True
    bullet_loss_block_count: int = 4
    bullet_sample_sec: int = 2
    bullet_confirm_count: int = 3
    bullet_sensitivity: float = 1.0
    bullet_tolerance_price_pct: float = 0.10
    bullet_hard_risk_pct: float = 0.50
    bullet_profit_incubation_sec: int = 8
    bullet_loss_incubation_sec: int = 20
    bullet_flip_cooldown_sec: int = 40
    bullet_profit_cooldown_after_count: int = 1
    bullet_loss_cooldown_sec: int = 50
    bullet_loss_cooldown_after_count: int = 1
    bullet_bonus_tp_enable: bool = True
    bullet_bonus_tp_mult: float = 9.0
    bullet_profit_lock_enable: bool = True
    bullet_profit_lock_pullback_pct: float = 25.0
    bullet_entry_confirm_ticks: int = 1
    bullet_entry_quality_enable: bool = True
    bullet_entry_quality_min_score: int = 40
    bullet_min_edge_spread_mult: float = 1.5


# ──────────────────────────────── GROUP 18 ─────────────────────────────────
# HYPERACTIVE EDGE GOVERNOR (12 input)
@dataclass
class HEGSettings:
    heg_enable: bool = True
    heg_scout_edge_score: int = 58
    heg_full_edge_score: int = 74
    heg_scout_lot_pct: float = 35.0
    heg_fast_abort_sec: int = 8
    heg_fast_abort_atr: float = 0.28
    heg_virtual_scout: bool = True
    heg_virtual_fast_promote: bool = True
    heg_virtual_fast_promote_r: float = 0.20
    heg_virtual_invalidate_r: float = 0.35
    heg_virtual_no_chase_r: float = 0.45
    heg_virtual_max_age_sec: int = 180


# ──────────────────────────────── GROUP 19 ─────────────────────────────────
# ASYMMETRIC EXPECTANCY GOVERNOR (7 input)
@dataclass
class AEGSettings:
    aeg_enable: bool = True
    aeg_min_hold_sec: int = 4
    aeg_hard_loss_band_mult: float = 1.15
    aeg_profit_floor_band_mult: float = 0.85
    aeg_profit_run_band_mult: float = 1.20
    aeg_profit_run_pullback_pct: float = 45.0
    aeg_support_strength_gate: float = 0.46


# ──────────────────────────────── GROUP 20 ─────────────────────────────────
# DIRECTIONAL TRUTH META FILTER (8 input)
@dataclass
class DTESettings:
    dte_enable: bool = True
    dte_min_samples: int = 8
    dte_meta_edge_penalty: float = 12.0
    dte_meta_edge_boost: float = 8.0
    dte_scout_only_penalty: float = 10.0
    dte_late_entry_adverse_ratio: float = 0.65
    dte_noise_max_atr: float = 0.22
    dte_ewma_alpha: float = 0.16


# ──────────────────────────────── GROUP 21 ─────────────────────────────────
# NEXUS DIRECTION INTELLIGENCE (3 input)
@dataclass
class NDISettings:
    ndi_enable: bool = True
    ndi_profile: NDIProfileEnum = NDIProfileEnum.NDI_BALANCED
    ndi_flip_safety: NDIFlipSafetyEnum = NDIFlipSafetyEnum.NDI_FLIP_STRONG


# ──────────────────────────────── GROUP 22 ─────────────────────────────────
# TREND DETECTION CONSENSUS (7 input)
@dataclass
class ConsensusSettings:
    bullet_trend_consensus_enable: bool = True
    bullet_trend_consensus_min_votes: int = 2
    bullet_block_ditmi_conflict: bool = True
    bullet_allow_early_tmi: bool = True
    bullet_require_aegis_for_early: bool = False
    bullet_early_tmi_confidence_extra: float = 0.08
    bullet_aegis_confirm_threshold: float = 0.45


# ──────────────────────────────── GROUP 23 ─────────────────────────────────
# TREND SAME-DIRECTION LOSS SAFETY (6 input)
@dataclass
class LossSafetySettings:
    bullet_repeat_loss_guard_enable: bool = True
    bullet_same_side_loss_limit: int = 3
    bullet_loss_quality_step: int = 10
    bullet_account_same_side_max: int = 1
    bullet_require_fresh_signal_after_loss: bool = True
    bullet_freeze_tp_proj_lot_on_loss_streak: bool = True


# ──────────────────────────────── GROUP 24 ─────────────────────────────────
# TREND OR RANGE CHECK (16 input)
@dataclass
class AWRSettings:
    awr_enable: bool = True
    awr_horizon_min: int = 60
    awr_target_bars: int = 60
    awr_q_min: int = 20
    awr_vr_range_band: float = 0.15
    awr_vr_trend_band: float = 0.30
    awr_breakout_atr: float = 0.60
    awr_flip_window: int = 8
    awr_loss_frac_thresh: float = 0.60
    awr_lot_decay_floor: float = 0.30
    awr_tighten_lock_in_range: bool = True
    awr_range_lock_pullback_pct: float = 12.0
    awr_range_watchdog_min: int = 60
    awr_flip_stale_min: int = 30
    awr_hurst_enable: bool = True
    awr_hurst_band: float = 0.05


# ──────────────────────────────── GROUP 25 ─────────────────────────────────
# TREND/RANGE DATA SOURCE (6 input)
@dataclass
class TrendRangeDataSettings:
    awr_regime_source: AWRRegimeSrcEnum = AWRRegimeSrcEnum.AWR_SRC_ENSEMBLE
    pulse_tick_window: int = 1500
    pulse_cross_dens_range: float = 0.12
    pulse_cross_dens_trend: float = 0.04
    pulse_breakout_frac: float = 0.25
    pulse_min_ticks: int = 200


# ──────────────────────────────── GROUP 26 ─────────────────────────────────
# DIRECTION SMART CHECK (10 input)
@dataclass
class DISettings:
    di_enable: bool = True
    di_tick_window: int = 1200
    di_min_ticks: int = 180
    di_trend_score: float = 67.0
    di_range_score: float = 56.0
    di_min_efficiency: float = 0.18
    di_dir_dead_zone: float = 0.08
    di_breakout_frac: float = 0.22
    di_smooth_alpha: float = 0.28
    di_print_changes: bool = True


# ──────────────────────────────── GROUP 27 ─────────────────────────────────
# DIRECTION EXTRA CHECKS (13 input)
@dataclass
class DIExtraSettings:
    di_fusion_enable: bool = True
    di_weight_score: float = 0.50
    di_weight_hurst: float = 0.30
    di_weight_vr: float = 0.20
    di_hurst_band: float = 0.05
    di_vr_band: float = 0.15
    di_vr_lag: int = 4
    di_multi_scale_eff: bool = True
    di_denoise_spread_mult: float = 0.50
    di_adaptive_thresh: bool = True
    di_adaptive_z: float = 0.50
    di_adaptive_mix: float = 0.50
    di_freeze_breakout: bool = True


# ──────────────────────────────── GROUP 28 ─────────────────────────────────
# EARLY TREND CHECK (10 input)
@dataclass
class TMISettings:
    tmi_enable: bool = True
    tmi_fast_ticks: int = 48
    tmi_mid_ticks: int = 144
    tmi_confidence_gate: float = 0.62
    tmi_early_gate: float = 0.54
    tmi_min_impulse_atr: float = 0.18
    tmi_breakout_atr: float = 0.12
    tmi_reversal_risk_gate: float = 0.72
    tmi_use_trade_feedback: bool = False
    tmi_print_changes: bool = True


# ──────────────────────────────── GROUP 29 ─────────────────────────────────
# FINAL DIRECTION DECISION (1 input)
@dataclass
class UDCWSettings:
    udc_log: bool = True


# ──────────────────────────────── GROUP 30 ─────────────────────────────────
# SAME SIDE MIN DISTANCE (4 input)
@dataclass
class MinDistanceSettings:
    min_dist_enable: bool = True
    min_dist_points: float = 0.0
    min_dist_all_engines: bool = True
    min_dist_log: bool = True


# ──────────────────────────────── GROUP 31 ─────────────────────────────────
# GRID ENGINE (38 input)
@dataclass
class GridEngineSettings:
    vg_enable: bool = True
    vg_instant_start_on_flat: bool = False
    vg_netting_single_side: bool = True
    vg_netting_start_on_flat: bool = True
    vg_tp_authority: bool = True
    vg_tp_manage_strict_off: bool = False
    vg_trend_adaptive_direction: bool = True
    vg_trend_source: GridTrendSourceEnum = GridTrendSourceEnum.VGTS_MICRO_FLOW
    vg_trend_micro_spread_mult: float = 2.00
    vg_pyramid_buy: bool = False
    vg_pyramid_sell: bool = False
    vg_loop_harvest_enable: bool = False
    vg_loop_min_net_spread_mult: float = 1.0
    vg_escape_fund_enable: bool = False
    vg_escape_fund_share_pct: float = 20.0
    vg_escape_deploy_pct: float = 50.0
    vg_escape_reward_risk: float = 2.0
    vg_escape_bank_cap_pct: float = 2.0
    vg_escape_max_grid_lot_mult: float = 2.0
    vg_lot_mode: GridLotModeEnum = GridLotModeEnum.GLM_FIXED
    vg_lot_value: float = 0.01
    vg_tp_mode: GridTPModeEnum = GridTPModeEnum.GTP_SPREAD_MULT
    vg_tp_value: float = 2.0
    vg_step_mode: GridStepModeEnum = GridStepModeEnum.GST_FIXED_POINTS
    vg_step_value: float = 200.0
    vg_buy_step_value: float = 0.0
    vg_sell_step_value: float = 0.0
    vg_range_samples: int = 300
    vg_stop_new_entries_on_trend: bool = True
    vg_close_profits_on_trend: bool = False
    vg_magic_buy: int = 2301
    vg_magic_sell: int = 2302
    bullet_vol_min_mult: float = 0.25
    bullet_vol_max_mult: float = 8.0
    bullet_move_window_min: int = 10
    bullet_move_refresh_sec: int = 5
    bullet_move_spike_aware: bool = True
    bullet_move_dir_factor: float = 1.0


# ──────────────────────────────── GROUP 32 ─────────────────────────────────
# AUTO TUNING (11 input)
@dataclass
class AutoTuneSettings:
    enable_bullet_auto_tune: bool = False
    bat_min_samples: int = 30
    bat_recalc_every_flips: int = 15
    bat_step_pct: float = 10.0
    bat_auto_revert_on_worse: bool = True
    bat_verbose_log: bool = True
    bat_loss_cluster_trough_ratio: float = 0.5
    bat_r2_high_thr: float = 0.70
    bat_r2_low_thr: float = 0.50
    bat_bad_hour_loss_rate: float = 65.0
    bat_bad_hour_min_trades: int = 8


# ──────────────────────────────── GROUP 33 ─────────────────────────────────
# NEWS FILTER (13 input)
@dataclass
class NewsFilterSettings:
    nf_enable: bool = False
    nf_only_high_impact: bool = True
    nf_medium_impact: bool = True
    nf_minutes_before: int = 45
    nf_minutes_after: int = 30
    nf_currency_filter: str = "USD,EUR,GBP"
    nf_pause_trading: bool = True
    nf_hedge_before_news: bool = False
    nf_close_all_before_news: bool = False
    nf_close_hedge_after_news: bool = True
    nf_close_hedge_on_loss: bool = True
    nf_hedge_exit_profit: float = 0.30
    nf_show_panel: bool = True


# ──────────────────────────────── GROUP 34 ─────────────────────────────────
# WEEKLY TRADING HOURS (32 input)
@dataclass
class WeeklyScheduleSettings:
    enable_weekly_schedule: bool = False
    weekly_schedule_action: TimeFilterActionEnum = TimeFilterActionEnum.TFA_BLOCK_NEW
    weekly_schedule_clock: TimeFilterClockEnum = TimeFilterClockEnum.TFC_BROKER
    weekly_schedule_resume_delay_sec: int = 10
    # Her gün için 4 periyot (P1, P2, P3, P4)
    mon_p1: str = "00:00-05:59"
    mon_p2: str = "06:00-11:59"
    mon_p3: str = "12:00-17:59"
    mon_p4: str = "18:00-23:59"
    tue_p1: str = "00:00-05:59"
    tue_p2: str = "06:00-11:59"
    tue_p3: str = "12:00-17:59"
    tue_p4: str = "18:00-23:59"
    wed_p1: str = "00:00-05:59"
    wed_p2: str = "06:00-11:59"
    wed_p3: str = "12:00-17:59"
    wed_p4: str = "18:00-23:59"
    thu_p1: str = "00:00-05:59"
    thu_p2: str = "06:00-11:59"
    thu_p3: str = "12:00-17:59"
    thu_p4: str = "18:00-23:59"
    fri_p1: str = "00:00-05:59"
    fri_p2: str = "06:00-11:59"
    fri_p3: str = "12:00-17:59"
    fri_p4: str = "18:00-23:59"
    sat_p1: str = "00:00-00:00"
    sat_p2: str = "00:00-00:00"
    sat_p3: str = "00:00-00:00"
    sat_p4: str = "00:00-00:00"
    sun_p1: str = "00:00-00:00"
    sun_p2: str = "00:00-00:00"
    sun_p3: str = "00:00-00:00"
    sun_p4: str = "00:00-00:00"


# ──────────────────────────────── GROUP 35 ─────────────────────────────────
# VIOP / FUTURES SAFETY (17 input)
@dataclass
class VIOPSettings:
    viop_detection_mode: VIOPDetectModeEnum = VIOPDetectModeEnum.VIOP_DETECT_AUTO
    viop_enable_session_control: bool = True
    viop_use_broker_session_times: bool = True
    viop_use_fixed_times_fallback: bool = True
    viop_close_hour: int = 18
    viop_close_min: int = 10
    viop_open_hour: int = 9
    viop_open_min: int = 20
    viop_gap_wait_minutes: int = 5
    viop_enable_expiry_protection: bool = True
    viop_block_new_hours_before_expiry: int = 48
    viop_force_close_before_expiry: bool = False
    viop_force_close_minutes_before_expiry: int = 30
    viop_block_option_symbols: bool = True
    viop_rollover_mode: VIOPRolloverModeEnum = VIOPRolloverModeEnum.VIOP_ROLLOVER_SUGGEST
    viop_rollover_search_days: int = 180
    viop_auto_switch_hours_before_expiry: int = 1


# ──────────────────────────────── GROUP 36 ─────────────────────────────────
# TRADE ID NUMBERS (10 input)
@dataclass
class TradeIDSettings:
    magic_chart_suffix: str = ""
    magic_buy: int = 2001
    magic_sell: int = 2002
    magic_grid_escape_buy: int = 2311
    magic_grid_escape_sell: int = 2312
    magic_nf_hedge: int = 78777
    magic_manual_hedge: int = 78778
    magic_dd_hedge: int = 78779
    magic_dyn_hedge: int = 78780
    magic_time_hedge: int = 78781


# ──────────────────────────────── GROUP 37 ─────────────────────────────────
# VIRTUAL TAKE PROFIT (2 input)
@dataclass
class VirtualTPSettings:
    enable_alternating_tp: bool = True
    virtual_tp_pct: float = 0.15


# ──────────────────────────────── GROUP 38 ─────────────────────────────────
# DAILY PROFIT / LOSS LOCK (8 input)
@dataclass
class DailyLockSettings:
    daily_profit_lock_enable: bool = False
    daily_profit_target_pct: float = 1.00
    daily_loss_lock_enable: bool = False
    daily_loss_target_pct: float = 1.00
    daily_lock_scope: DailyGuardScopeEnum = DailyGuardScopeEnum.DGS_ACCOUNT
    daily_clock_mode: DailyGuardClockEnum = DailyGuardClockEnum.DGC_BROKER
    daily_restart_hour: int = 9
    daily_restart_minute: int = 30


# ──────────────────────────────── GROUP 39 ─────────────────────────────────
# AUTO COST LIMITS (3 input)
@dataclass
class AutoCostSettings:
    enable_auto_spread: bool = True
    auto_spread_spike_pct: float = 30.0
    auto_slippage_pct: float = 50.0


# ──────────────────────────────── GROUP 40 ─────────────────────────────────
# TIME-BASED RESET (6 input)
@dataclass
class TimeResetSettings:
    enable_forced_reset: bool = False
    forced_reset_hours: int = 24
    enable_time_limit_reset: bool = False
    time_limit_minutes: int = 60
    time_reset_action: TimeResetModeEnum = TimeResetModeEnum.TR_CLOSE_ALL
    pause_after_time_limit: bool = True


# ──────────────────────────────── GROUP 41 ─────────────────────────────────
# REOPEN RULE (1 input)
@dataclass
class ReopenSettings:
    allow_reopen_neutral: bool = True


# ──────────────────────────────── GROUP 42 ─────────────────────────────────
# RISK STYLE (1 input)
@dataclass
class RiskStyleSettings:
    auto_tune_risk_profile: AutoTuneRiskProfile = AutoTuneRiskProfile.RISK_BALANCED


# ─────────────────────────────────────────────────────────────────────────────
# ANA AYAR SINIFI — TÜM 42 GRUBU BİRLEŞTİRİR
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class NexusSettings:
    """Algotrade Nexus Pro 7.35 — 42 ayar grubu, 372 input."""
    version: str = "7.35"
    build: str = "REAL_ARCHITECTURE_R21"

    # 42 Ayar Grubu
    display: DisplaySettings = field(default_factory=DisplaySettings)
    sound: SoundAlertSettings = field(default_factory=SoundAlertSettings)
    dom: DOMSettings = field(default_factory=DOMSettings)
    cpu: CPUOptimizeSettings = field(default_factory=CPUOptimizeSettings)
    ml: MLSettings = field(default_factory=MLSettings)
    ml_data_log: MLDataLogSettings = field(default_factory=MLDataLogSettings)
    shadow_trade: ShadowTradeSettings = field(default_factory=ShadowTradeSettings)
    direction_engine: DirectionEngineSettings = field(default_factory=DirectionEngineSettings)
    vema: VEMASettings = field(default_factory=VEMASettings)
    first_touch: FirstTouchSettings = field(default_factory=FirstTouchSettings)
    classic_live: ClassicLiveSettings = field(default_factory=ClassicLiveSettings)
    main_trading: MainTradingSettings = field(default_factory=MainTradingSettings)
    basic_lot: BasicLotSettings = field(default_factory=BasicLotSettings)
    lot_cut: LotCutSettings = field(default_factory=LotCutSettings)
    time_lot_boost: TimeLotBoostSettings = field(default_factory=TimeLotBoostSettings)
    drawdown_hedge: DrawdownHedgeSettings = field(default_factory=DrawdownHedgeSettings)
    trend_engine: TrendEngineSettings = field(default_factory=TrendEngineSettings)
    heg: HEGSettings = field(default_factory=HEGSettings)
    aeg: AEGSettings = field(default_factory=AEGSettings)
    dte: DTESettings = field(default_factory=DTESettings)
    ndi: NDISettings = field(default_factory=NDISettings)
    consensus: ConsensusSettings = field(default_factory=ConsensusSettings)
    loss_safety: LossSafetySettings = field(default_factory=LossSafetySettings)
    awr: AWRSettings = field(default_factory=AWRSettings)
    trend_range_data: TrendRangeDataSettings = field(default_factory=TrendRangeDataSettings)
    di: DISettings = field(default_factory=DISettings)
    di_extra: DIExtraSettings = field(default_factory=DIExtraSettings)
    tmi: TMISettings = field(default_factory=TMISettings)
    udc: UDCWSettings = field(default_factory=UDCWSettings)
    min_distance: MinDistanceSettings = field(default_factory=MinDistanceSettings)
    grid: GridEngineSettings = field(default_factory=GridEngineSettings)
    auto_tune: AutoTuneSettings = field(default_factory=AutoTuneSettings)
    news: NewsFilterSettings = field(default_factory=NewsFilterSettings)
    weekly: WeeklyScheduleSettings = field(default_factory=WeeklyScheduleSettings)
    viop: VIOPSettings = field(default_factory=VIOPSettings)
    trade_id: TradeIDSettings = field(default_factory=TradeIDSettings)
    virtual_tp: VirtualTPSettings = field(default_factory=VirtualTPSettings)
    daily_lock: DailyLockSettings = field(default_factory=DailyLockSettings)
    auto_cost: AutoCostSettings = field(default_factory=AutoCostSettings)
    time_reset: TimeResetSettings = field(default_factory=TimeResetSettings)
    reopen: ReopenSettings = field(default_factory=ReopenSettings)
    risk_style: RiskStyleSettings = field(default_factory=RiskStyleSettings)

    def get_magic_buy(self) -> int:
        suffix = self.trade_id.magic_chart_suffix
        base = self.trade_id.magic_buy
        return int(str(base) + suffix) if suffix else base

    def get_magic_sell(self) -> int:
        suffix = self.trade_id.magic_chart_suffix
        base = self.trade_id.magic_sell
        return int(str(base) + suffix) if suffix else base

    def to_dict(self) -> dict:
        """Tüm ayarları dict olarak döndür."""
        import dataclasses
        result = {}
        for name, value in dataclasses.fields(self):
            if isinstance(value, dataclasses.Field):
                # nested dataclass
                sub = getattr(self, name)
                if hasattr(sub, '__dataclass_fields__'):
                    result[name] = dataclasses.asdict(sub)
                else:
                    result[name] = sub
            else:
                result[name] = value
        return result

    @classmethod
    def from_dict(cls, data: dict) -> "NexusSettings":
        """Dict'ten ayarları oluştur."""
        import dataclasses
        # Flat dict'i nested dataclass yapısına dönüştür
        kwargs = {}
        for name, value in data.items():
            if name in ('version', 'build'):
                kwargs[name] = value
            elif hasattr(cls, name):
                sub_cls = getattr(cls, name)
                if hasattr(sub_cls, '__dataclass_fields__'):
                    # nested dataclass instance
                    kwargs[name] = sub_cls
        return cls(**kwargs)

    def input_count(self) -> int:
        """Toplam input sayısını döndür."""
        return 372

    def group_count(self) -> int:
        """Toplam ayar grubu sayısını döndür."""
        return 42
