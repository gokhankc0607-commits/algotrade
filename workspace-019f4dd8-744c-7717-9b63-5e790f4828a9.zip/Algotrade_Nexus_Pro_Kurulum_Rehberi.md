# 🤖 ALGOTRADE NEXUS PRO 7.35 — TAM KURULUM VE KULLANIM REHBERİ
**Sürüm:** 7.35 | **Güncelleme:** 09.07.2026 | **Hazırlayan:** AI Assistant  
**Kapsam:** Sıfırdan kurulum → Demo test → Gerçek hesap → ONNX/ML entegrasyonu → Tüm koruma sistemleri

---

## 📌 İÇİNDEKİLER

1. [Hızlı Başlangıç Kontrol Listesi](#1-hızlı-başlangıç-kontrol-listesi)
2. [Bölüm 1 — GEREKSİNİMLER VE HESAP HAZIRLIĞI](#bölüm-1--gereksinimler-ve-hesap-hazırlığı)
3. [Bölüm 2 — DOSYA KURULUMU](#bölüm-2--dosya-kurulumu)
4. [Bölüm 3 — METAQUOTES TERMINALİNDE ROBOTU ÇALIŞTIRMA](#bölüm-3--metaquotes-terminalinde-robotu-çalıştırma)
5. [Bölüm 4 — PANELİ TANIMA](#bölüm-4--paneli-tanıma)
6. [Bölüm 5 — STRATEJİ MOTORLARINI ANLAMA](#bölüm-5--strateji-motorlarını-anlama)
7. [Bölüm 6 — GRID SİSTEMİ (R21 SANAL GAPLESS)](#bölüm-6--grid-sistemi-r21-sanal-gapless)
8. [Bölüm 7 — TÜM KORUMA SİSTEMLERİ](#bölüm-7--tüm-koruma-sistemleri)
9. [Bölüm 8 — HABER FİLTRE SİSTEMİ](#bölüm-8--haber-filtre-sistemi)
10. [Bölüm 9 — VIOP / FUTURES GÜVENLİĞİ](#bölüm-9--viop--futures-güvenliği)
11. [Bölüm 10 — ONNX VE ML ENTEGRASYONU](#bölüm-10--onnx-ve-ml-entegrasyonu)
12. [Bölüm 11 — SHADOW TRADE JOURNAL SİSTEMİ](#bölüm-11--shadow-trade-journal-sistemi)
13. [Bölüm 12 — RESET SİSTEMLERİ](#bölüm-12--reset-sistemleri)
14. [Bölüm 13 — ÇOKLU GRAFİK VE PERFORMANS](#bölüm-13--çoklu-grafik-ve-performans)
15. [Bölüm 14 — SORUN GİDERME](#bölüm-14--sorun-giderme)
16. [Bölüm 15 — AYAR SENARYOLARI](#bölüm-15--ayar-senaryoları)
17. [Bölüm 16 — 372 INPUT KISA REFERANS](#bölüm-16--372-input-kısa-referans)
18. [SON KONTROL LİSTESİ](#son-kontrol-listesi)

---

## ⚠️ RİSK UYARISI — LÜTFEN ÖNCE OKUYUN

> **Bu robot kâr garantisi vermez.** Forex, CFD ve vadeli işlem piyasalarında sermayenin bir kısmı veya tamamı kaybedilebilir.  
> Grid, hedge, TP-PROJ, lot artırma, sanal TP ve sabit sunucu Stop Loss bulunmayan yönetimler riski artırabilir.  
> **Zorunlu test sırası:** Strategy Tester → Demo hesap → Küçük sabit lot → Gerçek hesap

---

# BÖLÜM 1 — GEREKSİNİMLER VE HESAP HAZIRLIĞI

## 1.1 Minimum Sistem Gereksinimleri

| Gereksinim | Önerilen | Açıklama |
|---|---|---|
| **Terminal** | MetaTrader 5 Build 3320+ | MT5'in güncel olması gerekir |
| **İşletim Sistemi** | Windows 10/11, macOS (PlayOnMac) | MT5 native çalışmalı |
| **İnternet** | Kesintisiz, düşük ping | Robot sanal yönetim için sürekli bağlantı ister |
| **RAM** | 4 GB+ | Çoklu grafik kullanımı için 8 GB önerilir |
| **VPS** | Windows VPS (1 vCPU, 2 GB RAM) | **Kritik öneri:** Kesintisiz çalışma için şiddetle tavsiye edilir |
| **Broker** | MT5 destekli, Hedging hesap | Spread, komisyon ve likidite kontrol edilmeli |

## 1.2 Hesap Tipi: Hedging mi Netting mi?

Bu karar **kurulumdan önce** verilmelidir — sonradan değiştirilemez.

### ✅ HEDGING HESAP (ÖNERİLEN)
- Aynı sembolde **BUY ve SELL** ayrı pozisyonlar olarak tutulabilir
- Çift taraflı sanal grid, haber hedge, manuel hedge ve drawdown hedge için **en esnek yapı**
- Netting'e göre daha fazla fonksiyon kullanılabilir
- **Nasıl açılır:** MT5 → File → Open Account → "Hedging" seçeneğini işaretleyerek

### ⚠️ NETTING HESAP (SINIRLI)
- Aynı sembolde **tek net pozisyon** olabilir
- `VG_NettingSingleSide=true` açıkken grid tek yönlü çalışır
- Hedge fonksiyonları **kapatılır** veya blok davranışına çevrilir
- Yabancı pozisyonları (manuel, başka EA) **korur** — ters emirle bozmaz

### 📋 HESAP KARŞILAŞTIRMASI

| Özellik | Hedging | Netting |
|---|---|---|
| Çift yönlü pozisyon | ✅ Evet | ❌ Hayır |
| Haber Hedge | ✅ Aktif | ⚠️ Sınırlı |
| Manuel Hedge | ✅ Aktif | ⚠️ Panel only |
| Drawdown Hedge | ✅ Aktif | ❌ Pasif |
| R21 Grid (iki taraflı) | ✅ Evet | ⚠️ Tek yön |
| Yabancı pozisyon koruması | ⚠️ Dikkat gerekli | ✅ Otomatik koruma |

**Öneri:** İlk testler için **Hedging demo hesap** kullanın.

## 1.3 Broker ve Sembol Seçimi

### Yapılması Gerekenler:
1. ✅ MT5 platformunu indirin ve kurun ([metaquotes.net](https://www.metaquotes.net))
2. ✅ Demo hesap açın — **Hedging** seçeneğini işaretleyin
3. ✅ İşlem yapmak istediğiniz sembolün özelliklerini kontrol edin:
   - **Spread** ne kadar? (düşük spreadli semboller daha iyidir)
   - **Komisyon** var mı? (komisyonlu hesaplarda maliyet hesabı değişir)
   - **Swap** değerleri? (taşıma maliyeti önemli)
   - **Min lot** ve **Lot step** nedir?
4. ✅ Sembol grafiklerinde 1 dakikalık veri geçmişinin yeterli olduğundan emin olun

### ⚠️ Önemli Sembol Kontrolleri:
- **6E (EUR/USD), 6B (GBP/USD), 6J (USD/JPY)** gibi standart futures sembolleri için VIOP ayarları
- **Forex çiftleri** (EURUSD, GBPUSD vb.) için standart ayarlar
- **Altın (XAUUSD)** — yüksek volatilite, daha geniş STEP gerekebilir
- **Kripto** (BTCUSD) — çok yüksek volatilite, dikkatli lot/step ayarı

---

# BÖLÜM 2 — DOSYA KURULUMU

## 2.1 Alınan Dosyalar

| Dosya | Tip | Kullanım |
|---|---|---|
| `Algotrade Nexus Pro 09.07.rewrite.ex5` | **Derlenmiş (gerekli)** | Market dağıtımı için kullanılır |
| `Algotrade Nexus Pro 09.07.rewrite.mq5` | Kaynak | Sadece geliştirme/modifikasyon için |
| `Nexus_*.mqh` (13 dosya) | Modül | Kaynak derlemesi için gerekli |

## 2.2 Dosyaları Doğru Konumlara Kopyalama

### Adım 1: .ex5 Dosyasını Kurma
```
MT5 → File → Open Data Folder
├── MQL5/
│   └── Experts/
│       └── Algotrade Nexus Pro 09.07.rewrite.ex5   ← Burası
```

**VEYA** MT5 içinde:
```
Navigator → Expert Advisors → sağ tık → "Install"
```

### Adım 2: Ses Dosyaları (Opsiyonel — Özel Ses Kullanacaksanız)
```
MT5 Data Folder/
├── Sounds/
│   ├── nexus_trade_open.wav
│   ├── nexus_profit_close.wav
│   ├── nexus_loss_close.wav
│   ├── nexus_profit_reset.wav
│   └── nexus_loss_reset.wav
```
> 📝 **Not:** Ses dosyaları opsiyoneldir. Yoksa robot varsayılan MT5 seslerini kullanır.

### Adım 3: ONNX Model Dosyası (ONNX kullanacaksanız — Bölüm 10'da detaylı anlatım)
```
MT5 Data Folder/
├── MQL5/
│   └── Files/
│       └── nexus_regime_v2.onnx   ← Varsayılan model dosyası adı
```

### Adım 4: ML Veri Kaydı Klasörü (Otomatik Oluşur)
```
MT5 Data Folder/
├── MQL5/
│   └── Files/
│       ├── nexus_ml_market_training_v3.csv  ← ML_DataLog_Enable=true ise oluşur
│       └── [chart-specific files]           ← AutoPerChart=true ise
```

## 2.3 Terminal Ayarlarını Yapma

### MT5 Genel Ayarlar:
```
Tools → Options → Expert Advisors
├── ✅ Allow automated trading
├── ✅ Allow DLL imports (bazı fonksiyonlar için gerekebilir)
├── ✅ Allow external experts (opsiyonel)
└── ⚠️ Confirm DLL calls (güvenlik için açık bırakılabilir)
```

```
Tools → Options → Charts
├── ✅ Auto arrange
├── Max bars in chart: 10,000 (veya daha fazla)
└── Show grid: Tercih edilen
```

---

# BÖLÜM 3 — METAQUOTES TERMINALİNDE ROBOTU ÇALIŞTIRMA

## 3.1 Robotu Grafiğe Ekleme

### Adım adım:
1. **MT5'i açın**
2. **İşlem yapmak istediğiniz sembolün grafiğini açın**
   - Önerilen timeframe: M1 (1 dakika) — robot tick bazlı çalışır
3. **Navigator penceresinde** Experts → `Algotrade Nexus Pro 09.07.rewrite` dosyasını bulun
4. **Grafiğin üzerine sürükleyin** veya çift tıklayın
5. **"Expert Advisor" penceresi** açılacak:

### ⚠️ Önemli İlk Ayarlar (Input Sekmesi):

| Input Grubu | Ayar | İlk Değer | Öneri |
|---|---|---|---|
| **MAIN TRADING** | `EnableGlobalTrading` | `true` | İlk testte `true` |
| **MAIN TRADING** | `EnableBuy` | `true` | İlk testte `true` |
| **MAIN TRADING** | `EnableSell` | `true` | İlk testte `true` |
| **BASIC LOT SIZE** | `FixedLot` | `0.01` | İlk testte 0.01 bırakın |
| **GRID ENGINE** | `VG_LotValue` | `0.01` | İlk testte 0.01 |
| **NEWS FILTER** | `NF_Enable` | `false` | İlk testte kapalı |
| **ML / LIVE** | `ML_ONNX_Enable` | `false` | İlk testte kapalı |
| **AUTO TUNING** | `EnableBulletAutoTune` | `false` | İlk testte kapalı |
| **DISPLAY** | `PanelLanguage` | `LANG_TR` (Türkçe) | Türkçe kullanın |

6. **"OK"** butonuna tıklayın

## 3.2 Başlatma Sonrası Kontrol (Journal)

Robotu ekledikten sonra **Journal sekmesini** açın ve şu satırları arayın:

```
✅ "AlgoTrade Nexus Pro v7.35 - REAL ARCHITECTURE R21" → Başarılı başlatma
✅ "Hedging" veya "Netting" → Hesap tipi algılandı
✅ "Magic: 2001/2002" → Magic numaraları atandı
✅ "VIOP Detected: ..." veya "VIOP not detected" → VIOP durumu
✅ "Panel Language: ..." → Panel dili
```

### ❌ Hata Kontrolü:
- **"AutoTrading disabled"** → Tools → Options → Expert Advisors'ta izin verilmemiş
- **"Spread too high"** → Spread koruması aktif, spread düşene kadar bekleyin
- **"VIOP session closed"** → VIOP seans dışı, bekleyin veya VIOP ayarını kontrol edin

## 3.3 Panel Görünümünü Anlama

Robot başarıyla çalıştırıldığında grafikte **panel görünür** olur. Panel şu bölümlerden oluşur:

### Üst Bölüm (Bilgi Paneli):
| Sekme | Gördüğünüz Bilgi |
|---|---|
| **STRATEJİ** | Aktif motor (VEMA-X / First Touch / Classic Live), yön sinyali |
| **İŞLEMLER** | BUY/SELL lot, açık pozisyon sayısı, K/Z değerleri |
| **İSTATİSTİKLER** | İşlem istatistikleri, win rate, ortalama K/Z |
| **SİSTEM DURUMU** | Equity, marjin, serbest marjin, drawdown |
| **TP/RESET** | Equity durumu, reset sayacı, kilit durumları |

### Alt Bölüm (Kontrol Paneli):
| Sekme | İşlev |
|---|---|
| **KONTROL** | BUY/SELL açma/kapama, yerli kapat, tümünü kapat |
| **ARAÇ** | TP, lot, STEP gibi parametreler |
| **HABER** | Haber takvimi görünümü (NF_ShowPanel=true ise) |
| **DEĞER** | Canlı değer izleme ve müdahale |

> 📝 **Not:** Panel düğmeleri görsel durum metinleriyle açık/kapalı bilgisini verir. **Bazı butonlar gerçek işlem komutudur** — yanlışlıkla tıklanmamalıdır!

---

# BÖLÜM 4 — PANELİ TANIMA VE HAFIZA

## 4.1 Panel Dili Değiştirme

```
Input → DISPLAY → PanelLanguage
→ LANG_TR (Türkçe) ✓ ÖNERİLEN
→ LANG_EN (İngilizce)
→ LANG_AR, LANG_RU, LANG_ZH, LANG_FA, LANG_DE, LANG_IT, LANG_PT, LANG_ES, LANG_HI, LANG_KU
```

## 4.2 Panel Ölçeği

```
Input → DISPLAY → InpPanelScale
→ 1.0 (varsayılan)
→ Farklı çözünürlüklerde yazı/kutu oranını korumak için ayarlanır
→ Büyük ekranlarda 1.1-1.3, küçük ekranlarda 0.8-0.9 deneyin
```

## 4.3 Panel Hafızası — ÖNEMLİ!

```
⚠️ Panelde yazdığınız bazı değerler Input'tan farkı şekilde
   Global Variables (Terminal Global Değişkenleri) altında saklanır.
   Robotu yeniden taktığınızda ESKİ canlı değer geri gelebilir.
```

### Panel Hafızasını Temizleme:

**Yöntem 1 — MagicChartSuffix değiştirme (ÖNERİLEN):**
```
Input → TRADE ID NUMBERS → MagicChartSuffix
→ Boştu (varsayılan)
→ "1" yapın
→ Robotu kapatıp yeniden açın
```

**Yöntem 2 — Global Variables'ı Manuel Temizleme:**
```
MT5 → View → Global Variables
→ Sağ tık → "Delete All" veya
→ Robotla ilgili değişkenleri tek tek silin
```

**Yöntem 3 — Grafiği Tamamen Değiştirme:**
```
Robotu çalıştırdığınız grafiği kapatın
Yeni bir grafik açın
Robotu yeniden ekleyin
```

## 4.4 Master Panel Sistemi

Master Panel, bir grafiği "merkez panel" gibi kullanarak diğer grafiklerin bazı panel ayarlarını görmenize imkân verir.

```
Input → (Master panel olacak grafikte bir ayar)
→ MasterPanelPublish = true (varsayılan)
→ MasterPanelSyncPoll = aktif
```

> ⚠️ Çoklu grafikte aynı sembol veya farklı semboller kullanırken **MagicChartSuffix** ve **master senkron kapsamı** karıştırılmamalıdır!

---

# BÖLÜM 5 — STRATEJİ MOTORLARINI ANLAMA

## 5.1 Üç Temel Yön Motoru

Robotun kalbi yön motorlarıdır. **Birini seçin ve anlayın.**

### Motor 1: VEMA-X (Varsayılan — ÖNERİLEN BAŞLANGIÇ)
```
Input → DIRECTION ENGINE SELECTOR → DirectionEngineDefault
→ DIR_ENGINE_VEMA (0)
```

**Nasıl Çalışır:**
- Sanal bar saniyesi ve EMA akış davranışıyla canlı yön enerjisini ölçer
- Tick bazlı çalışır — bar kapanışını beklemez
- En hızlı tepki veren motordur

**Ana Inputlar:**
| Input | Varsayılan | Açıklama |
|---|---|---|
| `EMA15_FlatSpreadMult` | 0.15 | Düz piyasada spread çarpanı |
| `EMA15_ConfirmBars` | 1 | Onay bar sayısı |
| `EMA_VirtualBarSeconds` | 15 | Sanal bar saniyesi |

---

### Motor 2: First Touch (Olasılık Tabanlı)
```
Input → DIRECTION ENGINE SELECTOR → DirectionEngineDefault
→ DIR_ENGINE_FIRST_TOUCH (1)
```

**Nasıl Çalışır:**
- Fiyatın önce yukarı mı aşağı mı dokunacağını bariyer ve olasılık hesabıyla değerlendirir
- Daha analitik bir yaklaşım isteyenler için

**Ana Inputlar:**
| Input | Varsayılan | Açıklama |
|---|---|---|
| `FT_LookbackSeconds` | 1800 | Geçmiş pencere (saniye) |
| `FT_HorizonSeconds` | 45 | Ufuk (saniye) |
| `FT_MinProbability` | 0.58 | Minimum olasılık eşiği |
| `FT_ConfidenceZ` | 1.00 | Güven Z skoru |

---

### Motor 3: Classic Live (Faz-Enerji)
```
Input → DIRECTION ENGINE SELECTOR → DirectionEngineDefault
→ DIR_ENGINE_CLASSIC (2)
```

**Nasıl Çalışır:**
- Kısa pencere, hızlı pencere, warmup, giriş ve flip onayıyla klasik canlı faz-enerji hesabı
- Daha geleneksel bir strateji isteyenler için

**Ana Inputlar:**
| Input | Varsayılan | Açıklama |
|---|---|---|
| `ClassicLiveWindowSeconds` | 36 | Ana pencere |
| `ClassicLiveFastSeconds` | 7 | Hızlı pencere |
| `ClassicLiveDirectionGate` | 0.24 | Yön geçiş eşiği |

---

## 5.2 Destekleyici Kontrol Katmanları

Ana motordan gelen yönü ek kontroller destekler:

### DI — Direction Smart Check
```
Input → DIRECTION SMART CHECK
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `DI_Enable` | `true` | DI katmanını açar |
| `DI_TickWindow` | 1200 | Tick pencere boyutu |
| `DI_TrendScore` | 67.0 | Trend skor eşiği |
| `DI_RangeScore` | 56.0 | Range skor eşiği |

### TMI — Early Trend Check (Erken Trend)
```
Input → EARLY TREND CHECK
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `TMI_Enable` | `true` | Erken trend kontrolünü açar |
| `TMI_ConfidenceGate` | 0.62 | Güven eşiği |
| `TMI_EarlyGate` | 0.54 | Erken giriş eşiği |

### AWR — Trend or Range Check
```
Input → TREND OR RANGE CHECK
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `AWR_Enable` | `true` | Trend/Range ayrımını açar |
| `AWR_Hurst_Enable` | `true` | Hurst üstel ayrımını açar |
| `AWR_BreakoutATR` | 0.60 | Kırılma ATR çarpanı |

### NDI — Nexus Direction Intelligence
```
Input → NEXUS DIRECTION INTELLIGENCE
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `NDI_Enable` | `true` | NDI katmanını açar |
| `NDI_Profile` | `NDI_BALANCED` | Profil: NDI_MORE_TRADES / NDI_BALANCED / NDI_SELECTIVE |
| `NDI_FlipSafety` | `NDI_FLIP_STRONG` | Flip güvenlik seviyesi |

### DTE — Direction Truth Meta Filter
```
Input → DIRECTIONAL TRUTH META FILTER
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `DTE_Enable` | `true` | Meta filteri açar |
| `DTE_MinSamples` | 8 | Minimum örnek sayısı |
| `DTE_MetaEdgePenalty` | 12.0 | Meta edge cezası |

---

## 5.3 Trend Konsensüs Sistemi

```
Input → TREND DETECTION CONSENSUS
```

Robot, tek bir motora değil **birden fazla katmanın oy birliğine** dayanabilir:

| Input | Varsayılan | Açıklama |
|---|---|---|
| `Bullet_TrendConsensusEnable` | `true` | Konsensüs modunu açar |
| `Bullet_TrendConsensusMinVotes` | 2 | Minimum oy sayısı (DI + TMI + AEGIS vb.) |
| `Bullet_BlockDITMIConflict` | `true` | DI ile TMI çatışırsa girişi bloke eder |
| `Bullet_AllowEarlyTMI` | `true` | TMI'nin erken trend yakalamasına izin verir |

**Konsensüs Nasıl Çalışır:**
1. DI trend yönünde oy verir → +1 oy
2. TMI trend yönünde oy verir → +1 oy  
3. AEGIS onay verir → +1 oy
4. Toplam oy ≥ `Bullet_TrendConsensusMinVotes` → Girişe izin

---

# BÖLÜM 6 — GRID SİSTEMİ (R21 SANAL GAPLESS)

## 6.1 En Kritik Bilgi: Grid Sanal mı Gerçek mi?

```
🔴 KRİTİK: Grid seviyeleri SANAldır.
   Broker tarafına BUY LIMIT, BUY STOP, SELL LIMIT veya SELL STOP bekleyen grid emirleri DİZİLMEZ.
   
   EA belleğindeki sanal seviye fiyatla TETİKLENİRSE yalnız PİYASA EMRİ açılır.
   
   Terminal KAPANIRSA sanal yönetim de DURUR.
   Bu yüzden VPS kullanımı ŞİDDETLE ÖNERİLİR.
```

## 6.2 Grid'i Açma/Kapama

```
Input → GRID ENGINE → VG_Enable
→ true  → Grid aktif (varsayılan)
→ false → Grid kapalı, sadece Trend motoru çalışır
```

## 6.3 Grid Lot Ayarları

### Lot Modu Seçimi:
```
Input → GRID ENGINE → VG_LotMode
→ GLM_FIXED (0)        → Sabit lot (ÖNERİLEN BAŞLANGIÇ)
→ GLM_BALANCE_PCT (1)  → Bakiye yüzdesi
→ GLM_EQUITY_PCT (2)   → Equity yüzdesi
```

### Sabit Lot Ayarı:
```
Input → GRID ENGINE → VG_LotValue
→ 0.01  → İlk test için önerilen
→ 0.02  → Orta risk
→ 0.05  → Dikkatli
→ 0.10+ → Yüksek risk — demo test şart
```

## 6.4 Grid STEP (Kademe Mesafesi) Ayarları

```
🔴 STEP çok küçük ayarlanırsa marjin ve işlem yoğunluğu riski ARTAR.
   Sembolün volatilitesine ve spread'ine göre ayarlanmalıdır.
```

### STEP Modu:
```
Input → GRID ENGINE → VG_StepMode
→ GST_FIXED_POINTS (0)   → Sabit point (ÖNERİLEN BAŞLANGIÇ)
→ GST_RANGE_MULT (1)     → Range çarpanı
→ GST_PRICE_PCT (2)      → Fiyat yüzdesi
```

### STEP Değeri (Sabit Point Modunda):
```
Input → GRID ENGINE → VG_StepValue
→ 200.0  → Varsayılan (Forex'te genellikle yeterli)
→ 100.0  → Daha sık kademe — daha yüksek risk
→ 300.0  → Daha seyrek kademe — daha düşük risk
→ 500.0  → Çok seyrek — düşük risk
```

### Ayrı BUY/SELL STEP (İleri Düzey):
```
Input → GRID ENGINE
→ VG_BuyStepValue  → 0.0 (varsayılan = genel VG_StepValue kullanılır)
→ VG_SellStepValue → 0.0 (varsayılan = genel VG_StepValue kullanılır)
→ Sıfırdan farklıysa yön bazlı ayrı adım uygulanır
```

## 6.5 Grid TP (Take Profit) Ayarları

### TP Modu:
```
Input → GRID ENGINE → VG_TPMode
→ GTP_SPREAD_MULT (0)    → Spread çarpanı (varsayılan)
→ GTP_BALANCE_PCT (1)    → Bakiye yüzdesi
→ GTP_FIXED_POINTS (2)   → Sabit point
→ GTP_PRICE_PCT (3)      → Fiyat yüzdesi
```

### TP Değeri:
```
Input → GRID ENGINE → VG_TPValue
→ 2.0  → Varsayılan (spread × 2 çarpan)
→ 3.0  → Daha büyük TP — daha az sıklıkta
→ 1.5  → Daha küçük TP — daha sıklıkta kapanış
```

### Grid TP Otoritesi:
```
Input → GRID ENGINE → VG_TPAuthority
→ true  → TP gerçekleşince pozisyonu kapatabilir
→ false → TP sadece izlenir, kapatma yapılmaz
```

```
⚠️ VG_TPAuthority = true VE gerçek PnL POZİTİF olmalıdır.
   Negatif PnL'de TP kapanışı yapılmaz.
```

## 6.6 Grid TP Yönetimi İnce Ayarı:
```
Input → GRID ENGINE → VG_TPManageStrictOff
→ false (varsayılan) → Standart TP yönetimi
→ true               → TP yönetimi sıkı modda kapalı
```

## 6.7 Trend Adaptif Yön:
```
Input → GRID ENGINE → VG_TrendAdaptiveDirection
→ true  → Trend yönüne göre grid davranışı uyum sağlar
→ false → Yönsüz/range modunda sabit davranır
```

## 6.8 İleri Grid Özellikleri

### Piramit (Aynı Yönde Ekleme):
```
Input → GRID ENGINE
→ VG_PyramidBuy  → true/false
→ VG_PyramidSell → true/false
→ ⚠️ Yalnız uygun/kârlı koşullarda ekleme yapar — dikkatli kullanın
```

### Loop Harvest (Döngüsel Kâr Hasadı):
```
Input → GRID ENGINE → VG_LoopHarvestEnable
→ true  → Spread maliyeti için minimum çarpan belirlenir
→ VG_LoopMinNetSpreadMult → 1.0 (varsayılan)
```

### Escape Fund (Kurtarma Fonu):
```
Input → GRID ENGINE → VG_EscapeFundEnable
→ true  → Kârın bir kısmını kurtarma fonu olarak ayırır
→ VG_EscapeFundSharePct  → 20.0 (kârın %20'si)
→ VG_EscapeDeployPct    → 50.0 (fonun %50'i deploy edilir)
→ VG_EscapeRewardRisk    → 2.0 (ödül/risk oranı)
→ VG_EscapeBankCapPct    → 2.0 (maksimum banka yüzdesi)
→ VG_EscapeMaxGridLotMult→ 2.0 (maksimum lot çarpanı)
```

## 6.9 Trend Varlığında Grid Davranışı:

```
Input → GRID ENGINE
→ VG_StopNewEntriesOnTrend → true (varsayılan)
   → Trend algılandığında yeni grid girişleri DURUR
   
→ VG_CloseProfitsOnTrend  → false (varsayılan)
   → Trend sırasında mevcut kârlı grid pozisyonlarını kapatmaz
```

## 6.10 Netting Hesapta Grid:

```
Input → GRID ENGINE
→ VG_NettingSingleSide → true (varsayılan)
   → Yalnız tek net yön grid çalışır
   → Ters emirle pozisyon bozmaz
   
→ VG_NettingStartOnFlat → true (varsayılan)
   → Yatay/flat başlangıçta grid'i başlatır
```

## 6.11 Grid Magic Numaraları:

```
Input → GRID ENGINE
→ VG_MagicBuy  → 2301 (varsayılan)
→ VG_MagicSell → 2302 (varsayılan)
→ Bu numaralar grid pozisyonlarını tanımlar
```

## 6.12 R21 Grid İşlem Öncelik Sırası (Tick Başına):

```
1. Platform ve izin kontrolleri (Algo Trading, piyasa açık mı, spread/slippage)
2. Haber mutlak kilidi, haftalık saat filtresi, VIOP seans/vade, günlük kilit
3. Pozisyon, PnL, equity, marjin, magic ve dahili sayaç önbellekleri güncellenir
4. Global kâr/zarar reseti ve günlük kâr/zarar kilidi değerlendirilir
5. TP-PROJ, Bonus TP, Profit Lock, AEG profit exit ve Grid TP kapanış yolları
6. Yeni girişe kapalı mod varsa yalnız pozisyon yönetimi sürer
7. Yön motorları tarafından ana yön ve piyasa fazı hesaplanır
8. DI, TMI, AWR/PULSE, AEGIS/BD4, NDI, DTE ve ONNX katmanları ek doğrulama üretir
9. Router/UDC katmanı yeni emir için Trend/Bullet veya Grid tarafına izin verir
10. Son veto: BUY/SELL izni, minimum mesafe, kalite skoru, marjin, lot step, broker retcode
```

---

# BÖLÜM 7 — TÜM KORUMA SİSTEMLERİ

## 7.1 Ana Ticaret İzinleri

```
Input → MAIN TRADING
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `EnableGlobalTrading` | `true` | Robotun genel çalışma izni |
| `EnableBuy` | `true` | BUY yönü izni |
| `EnableSell` | `true` | SELL yönü izni |
| `EnableSpreadProtection` | `false` | Spread koruması (açılırsa MaxAllowedSpread devreye girer) |
| `MaxAllowedSpread` | 100 | İzin verilen maksimum spread (point) |
| `EnableSlippageProtection` | `false` | Slippage koruması |
| `MaxSlippage` | 100 | İzin verilen maksimum slippage (point) |

## 7.2 Yön Bazlı İzinler (İleri Düzey)

```
Input → MAIN TRADING → GridDirectionPermission
→ DPERM_BOTH  (0) → Her iki yön de açık (varsayılan)
→ DPERM_BUY   (1) → Sadece BUY
→ DPERM_SELL  (2) → Sadece SELL

Input → MAIN TRADING → TrendDirectionPermission
→ DPERM_BOTH  (0) → Her iki yön de açık (varsayılan)
→ DPERM_BUY   (1) → Sadece BUY
→ DPERM_SELL  (2) → Sadece SELL
```

## 7.3 Aynı Yön Minimum Mesafe Koruması

```
Input → SAME SIDE MIN DISTANCE
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `MinDist_Enable` | `true` | Minimum mesafe korumasını açar |
| `MinDist_Points` | 0.0 | Mesafe (0 = yön motoru kararı) |
| `MinDist_AllEngines` | `true` | Tüm motorlardan onay ister |
| `MinDist_Log` | `true` | Loglama yapar |

## 7.4 Aynı Yön Zarar Güvenliği (Repeat Loss Guard)

```
Input → TREND SAME-DIRECTION LOSS SAFETY
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `Bullet_RepeatLossGuardEnable` | `true` | Aynı yönde tekrar zararları sayar |
| `Bullet_SameSideLossLimit` | 3 | Limit aşılınca yön KİLİTLENİR |
| `Bullet_LossQualityStep` | 10 | Her zarardan sonra giriş kalite eşiği yükselir |
| `Bullet_AccountSameSideMax` | 1 | Hesap başına aynı yön maksimum pozisyon |
| `Bullet_RequireFreshSignalAfterLoss` | `true` | Taze sinyal ister |
| `Bullet_FreezeTPProjLotOnLossStreak` | `true` | Zarar serisinde lot artışını dondurur |

## 7.5 Lot Artış Kısıtlamaları

### Reset Sonrası Lot Kesme:
```
Input → LOT CUT AFTER RESETS
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `LotPenaltyStepResets` | 100 | Kesme adımı (reset sayısı) |
| `LotPenaltyStepPct` | 10.0 | Her adımda lot kesme yüzdesi |
| `LotPenaltyMinPct` | 30.0 | Minimum lot yüzdesi (sıfırlanmaz) |

### Örnek: 3 reset sonra lot kesilmesi:
- Reset 1-100 arası: Lot %100
- Reset 101-200 arası: Lot %90
- Reset 201-300 arası: Lot %80
- Minimum: Lot %30'ın altına düşmez

### Zamanlı Lot Artışı:
```
Input → TIME LOT BOOST
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `EnableTimedLotBoost` | `false` | Zamanlı lot artışı (test şart!) |
| `LotBoostStepHours` | 8 | Artış periyodu (saat) |
| `LotBoostStepPct` | 50.0 | Her adımda artış yüzdesi |
| `LotBoostMaxPct` | 1000.0 | Maksimum lot artış yüzdesi |

## 7.6 Drawdown (Düşüş) Hedge Koruması

```
Input → DRAWDOWN HEDGE
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `EnableAutoDDHedge` | `false` | Equity düşüşünde otomatik hedge |
| `EnableMultiSymbolHedge` | `false` | Çoklu sembol hedge |
| `AutoDDHedgePct` | 5.0 | Hedge tetikleme yüzdesi |
| `DDHedgeExitProfit` | 0.50 | Hedge çıkış kâr yüzdesi |
| `DDHedgePauseTrading` | `false` | Hedge sırasında işlem duraklatma |

## 7.7 Hyperactive Edge Governor (HEG)

```
Input → HYPERACTIVE EDGE GOVERNOR
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `HEG_Enable` | `true` | Aşırı aktif filtre |
| `HEG_ScoutEdgeScore` | 58 | Scout (ön tarama) kenar skoru |
| `HEG_FullEdgeScore` | 74 | Tam giriş kenar skoru |
| `HEG_ScoutLotPct` | 35.0 | Scout lot yüzdesi |
| `HEG_FastAbortSec` | 8 | Hızlı iptal saniyesi |
| `HEG_VirtualScout` | `true` | Sanal ön tarama |

## 7.8 Asimetrik Beklenti Yöneticisi (AEG)

```
Input → ASYMMETRIC EXPECTANCY GOVERNOR
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `AEG_Enable` | `true` | Asimetrik beklenti yönetimi |
| `AEG_MinHoldSec` | 4 | Minimum tutma süresi |
| `AEG_HardLossBandMult` | 1.15 | Sert zarar bandı çarpanı |
| `AEG_ProfitFloorBandMult` | 0.85 | Kâr tabanı bandı çarpanı |
| `AEG_ProfitRunBandMult` | 1.20 | Kâr koşusu bandı çarpanı |
| `AEG_ProfitRunPullbackPct` | 45.0 | Kâr geri çekilme yüzdesi |
| `AEG_SupportStrengthGate` | 0.46 | Destek gücü eşiği |

## 7.9 Trend Flip (Yön Değişimi) Kapanışı

```
Input → TREND ENGINE
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `Bullet_ProfitIncubationSec` | 8 | Kârlı kuluçka süresi |
| `Bullet_LossIncubationSec` | 20 | Zararlı kuluçka süresi |
| `Bullet_FlipCooldownSec` | 40 | Flip bekleme süresi |

## 7.10 Bonus TP (Ek Kâr Kapatma)

```
Input → TREND ENGINE
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `Bullet_BonusTPEnable` | `true` | Bonus TP modunu açar |
| `Bullet_BonusTP_Mult` | 9.0 | Sanal TP katsayısı |

## 7.11 Profit Lock (Kâr Kilitleme)

```
Input → TREND ENGINE
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `Bullet_ProfitLockEnable` | `true` | Kâr kilitleme modunu açar |
| `Bullet_ProfitLockPullbackPct` | 25.0 | Kâr geri çekilme yüzdesi |

## 7.12 Sanal TP Sistemi

```
Input → VIRTUAL TAKE PROFIT
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `EnableAlternatingTP` | `true` | Alternatif TP modunu açar |
| `VirtualTPPct` | 0.15 | Sanal TP yüzdesi |

```
⚠️ Sanal TP terminal/EA açık kalmasını gerektirir.
   Kesinti yönetimi için VPS kullanımı önemlidir.
```

## 7.13 Entry (Giriş) Kalite Kontrolü

```
Input → TREND ENGINE
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `Bullet_EntryConfirmTicks` | 1 | Giriş onay tick sayısı |
| `Bullet_EntryQualityEnable` | `true` | Kalite filtresini açar |
| `Bullet_EntryQualityMinScore` | 40 | Minimum kalite skoru |
| `Bullet_MinEdgeSpreadMult` | 1.5 | Minimum kenar spread çarpanı |

## 7.14 Loss Block (Zarar Engelleme)

```
Input → TREND ENGINE
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `Bullet_LossBlockEnable` | `true` | Zarar bloklamayı açar |
| `Bullet_LossBlockCount` | 4 | Bloklama eşiği |
| `Bullet_LossCooldownSec` | 50 | Zarar bekleme süresi |

## 7.15 Reopen (Yeniden Açma) Kuralı

```
Input → REOPEN RULE → AllowReopenNeutral
→ true (varsayılan) → Nötr sinyalde yeniden açmaya izin verir
→ false             → Yeniden açmayı kapatır
```

---

# BÖLÜM 8 — HABER FİLTRE SİSTEMİ

## 8.1 Haber Filtresini Açma

```
Input → NEWS FILTER → NF_Enable
→ false → Haber filtresi KAPALI (varsayılan, ilk testler için)
→ true  → Haber filtresi AÇIK (demo test şart)
```

## 8.2 Haber Etki Seviyesi

```
Input → NEWS FILTER
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `NF_OnlyHighImpact` | `true` | Sadece YÜKSEK etkili haberleri filtrele |
| `NF_MediumImpact` | `true` | ORTA etkili haberleri de filtrele |

> 📝 MT5 Economic Calendar verisine bağlıdır.

## 8.3 Haber Zaman Penceresi

```
Input → NEWS FILTER
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `NF_MinutesBefore` | 45 | Haber öncesi bekleme (dakika) |
| `NF_MinutesAfter` | 30 | Haber sonrası bekleme (dakika) |

## 8.4 Para Birimi Filtresi

```
Input → NEWS FILTER → NF_CurrencyFilter
→ "USD,EUR,GBP" (varsayılan)
→ "USD" → Sadece USD haberleri
→ "EUR,USD,GBP,JPY" → Birden fazla
→ "" → Tüm para birimleri
```

## 8.5 Haber Sırasında Davranış Modları

```
Input → NEWS FILTER → NF_PauseTrading
→ true (varsayılan) → Haber penceresinde yeni girişleri DURDURUR
```

### İleri Modlar:

```
Input → NEWS FILTER
→ NF_HedgeBeforeNews → Haber öncesi net maruziyeti hedge etmeye çalışır
   → ⚠️ Sadece Hedging hesapta çalışır
   
→ NF_CloseAllBeforeNews → Haberden önce tüm pozisyonları kapatmaya çalışır
   → ⚠️ Zarar gerçekleşebilir!
   
→ NF_CloseHedgeAfterNews → Haber penceresi bitince hedge pozisyonlarını kapatır
   → NF_CloseHedgeOnLoss → Hedge zararda da kapatır
   
→ NF_HedgeExitProfit → 0.30 → Hedge çıkış kâr yüzdesi
```

### 📋 Haber Filtresi Davranış Matrisi:

| Mod | Açıklama | Risk |
|---|---|---|
| `NF_PauseTrading=true` | Yeni girişler durur, mevcut pozisyonlar korunur | Düşük |
| `NF_HedgeBeforeNews=true` | Haber öncesi hedge açılır | Orta |
| `NF_CloseAllBeforeNews=true` | Haber öncesi HERŞEY kapatılır | Yüksek |
| `NF_CloseHedgeAfterNews=true` | Haber sonrası hedge kapatılır | Orta |

### 🔴 MUTLAK HABER KİLİDİ KURALI:

```
⚠️ Hedge Before veya Close All Before kullanıldığında haber penceresi boyunca
   TP, reset, flip ve yeni giriş gibi otomatik eylemler SINIRLANMALIDIR.
   Amaç haber anında hesabı yeni otomatik kararlarla BÜYÜT MEMEKTİR.
```

## 8.6 Panel'de Haber Görünümü

```
Input → NEWS FILTER → NF_ShowPanel
→ true (varsayılan) → Panelde haber takvimi görünür
```

---

# BÖLÜM 9 — VIOP / FUTURES GÜVENLİĞİ

## 9.1 VIOP Nedir?

VIOP = Vadeli İşlem ve Opsiyon Piyasası (Borsa İstanbul)  
Bu sistem **Türk futures sözleşmeleri** (VI30, VIEN, XU030 vb.) ve **uluslararası futures sembolleri** (6E, 6B, CL, NG vb.) için tasarlanmıştır.

## 9.2 VIOP Tespit Modu

```
Input → VIOP / FUTURES SAFETY → VIOP_DetectionMode
→ VIOP_DETECT_AUTO (0) → Broker sembol özelliklerinden otomatik tespit
→ VIOP_FORCE_ON  (1)   → Zorla açık
→ VIOP_FORCE_OFF (2)   → Zorla kapalı
```

## 9.3 Seans Kontrolü

```
Input → VIOP / FUTURES SAFETY
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `VIOP_EnableSessionControl` | `true` | Seans kontrolünü açar |
| `VIOP_UseBrokerSessionTimes` | `true` | Brokerın seans saatlerini kullanır |
| `VIOP_UseFixedTimesFallback` | `true` | Broker seansı yoksa sabit yedek kullanır |
| `VIOP_Open_Hour` | 9 | Açılış saati |
| `VIOP_Open_Min` | 20 | Açılış dakikası |
| `VIOP_Close_Hour` | 18 | Kapanış saati |
| `VIOP_Close_Min` | 10 | Kapanış dakikası |
| `VIOP_GapWaitMinutes` | 5 | Seans açılışı sonrası gap bekleme (dakika) |

## 9.4 Vade Sonu (Expiry) Koruması

```
Input → VIOP / FUTURES SAFETY
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `VIOP_EnableExpiryProtection` | `true` | Vade sonu korumasını açar |
| `VIOP_BlockNewHoursBeforeExpiry` | 48 | Vadeden kaç saat önce yeni girişleri bloklar |
| `VIOP_ForceCloseBeforeExpiry` | `false` | Vadeden önce pozisyonları kapatmaya çalışır |
| `VIOP_ForceCloseMinutesBeforeExpiry` | 30 | Kapatma kaç dakika önce başlar |
| `VIOP_BlockOptionSymbols` | `true` | Opsiyon sembollerini bloker |

```
⚠️ VIOP_ForceCloseBeforeExpiry = true yaparsanız
   Pozisyonlar vadeden önce kapatılmaya çalışılır ve ZARAR gerçekleşebilir.
```

## 9.5 Rollover (Vade Geçişi) Modu

```
Input → VIOP / FUTURES SAFETY → VIOP_RolloverMode
→ VIOP_ROLLOVER_OFF           (0) → Kapalı
→ VIOP_ROLLOVER_SUGGEST       (1) → Sadece öneri (varsayılan)
→ VIOP_ROLLOVER_AUTO_SWITCH   (2) → Otomatik yeni vadeye geçiş
```

```
Input → VIOP / FUTURES SAFETY
→ VIOP_RolloverSearchDays  → 180 → Vade arama gün sayısı
→ VIOP_AutoSwitchHoursBeforeExpiry → 1 → Kaç saat önce otomatik switch
```

## 9.6 VIOP İşlem Sırası:

```
1. Seans açık mı kontrol et
2. Seans dışıysa yeni girişleri blokla
3. Seans açılışında gap var mı kontrol et
4. Gap varsa VIOP_GapWaitMinutes kadar bekle
5. Vadeye yaklaşım var mı kontrol et
6. Vade kritikse yeni girişleri blokla
7. Rollover gerekiyorsa otomatik switch dene
```

---

# BÖLÜM 10 — ONNX VE ML ENTEGRASYONU

## 10.1 ONNX Nedir?

ONNX = Open Neural Network Exchange  
Robotun **harici eğitilmiş makine öğrenmesi modelini** MT5 içinde çalıştırmasını sağlar.  
Model, piyasa rejimini (trend/range), yönü ve güven skorlarını tahmin edebilir.

## 10.2 ONNX'i Açma

```
Input → ML / LIVE MARKET LEARNING → ML_ONNX_Enable
→ false → ONNX KAPALI (varsayılan — ilk testler için)
→ true  → ONNX AÇIK (demo test şart)
```

## 10.3 Model Dosyasını Yerleştirme

```
MT5 Data Folder/
├── MQL5/
│   └── Files/
│       └── nexus_regime_v2.onnx   ← Bu dosya burada olmalı
```

Varsayılan model dosyası adı:
```
Input → ML / LIVE MARKET LEARNING → ML_ONNX_ModelFile
→ "nexus_regime_v2.onnx" (varsayılan)
```

## 10.4 Model Parametreleri

```
Input → ML / LIVE MARKET LEARNING
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `ML_FeatureCount` | 16 | Modelin girdi özelliği sayısı |
| `ML_OutputCount` | 4 | Modelin çıktı sayısı |
| `ML_MinTrendProb` | 0.62 | Minimum trend olasılık eşiği |
| `ML_MinDirectionProb` | 0.58 | Minimum yön olasılık eşiği |
| `ML_Weight` | 0.35 | Modelin karar ağırlığı (0-1) |
| `ML_UpdateMs` | 500 | Model güncelleme aralığı (milisaniye) |

## 10.5 Model Yükleme Ayarları

```
Input → ML / LIVE MARKET LEARNING
→ ML_AutoModelReload → true  → Modeli otomatik yeniden yükler
→ ML_AutoModelReloadSec → 300 → Yeniden yükleme aralığı (saniye)

→ ML_FallbackHeuristic → true → Model çalışmazsa yedek mantık kullanır

→ ML_ShadowOnly → false → true olursa model sadece GÖZLEM modunda çalışır
   (gerçek işlem yapmaz, sadece puan verir — test için ideal)
```

## 10.6 ONNX Entegrasyon Adımları

### Adım 1: Model Hazırlama
```
1. TensorFlow / PyTorch / scikit-learn ile model eğitin
2. Modeli ONNX formatına dönüştürün
3. Girdi/çıktı boyutlarını ML_FeatureCount ve ML_OutputCount ile eşleştirin
4. Model dosyasını .onnx olarak kaydedin
```

### Adım 2: Modeli Yükleme
```
1. Model dosyasını MQL5/Files klasörüne kopyalayın
2. ML_ONNX_Enable = true yapın
3. ML_FeatureCount ve ML_OutputCount'ı modelinize göre ayarlayın
4. Robotu yeniden başlatın
5. Journal'da model yüklendi mi kontrol edin
```

### Adım 3: Test Etme
```
1. ML_ShadowOnly = true ile başlayın (gerçek işlem yok)
2. ShadowTrade sistemiyle sonuçları izleyin
3. Model performansı yeterliyse ML_ShadowOnly = false yapın
```

### Adım 4: İzleme
```
Journal'da ONNX çıktılarını izleyin:
→ Modelin trend/reverse tahminleri
→ Güven skorları
→ Olasılık eşik karşılaştırmaları
```

## 10.7 ONNX Model Yapısı (Örnek)

```
Varsayılan model: 16 girdi özelliği, 4 çıktı
Girdi özellikleri (örnek):
→ RSI(14), ATR(14), Volume, Spread, Price momentum, 
  Moving Average farkları, Volatility, vb.

Çıktılar:
→ 0: Trend olasılığı (0-1)
→ 1: Reverse olasılığı (0-1)  
→ 2: Direction (0=BUY, 1=SELL)
→ 3: Confidence (0-1)
```

---

# BÖLÜM 11 — SHADOW TRADE JOURNAL SİSTEMİ

## 11.1 Shadow Trade Nedir?

Shadow Trade = Gölge İşlem  
Robot **gerçek emir açmadan** hayali/gölge işlem sonuçlarını takip eder.  
**Gerçek pozisyona dönüştürmeden** strateji performansını izleyebilirsiniz.

## 11.2 Shadow Trade'i Açma

```
Input → SHADOW TRADE JOURNAL (NO LIVE ORDERS)
→ ShadowTrade_Enable → true (varsayılan açık)
```

## 11.3 Shadow Trade Parametreleri

| Input | Varsayılan | Açıklama |
|---|---|---|
| `ShadowTrade_MaxAgeSec` | 300 | Maksimum gölge yaşı (saniye) |
| `ShadowTrade_TargetATR` | 1.00 | Hedef ATR çarpanı |
| `ShadowTrade_RiskATR` | 0.75 | Risk ATR çarpanı |
| `ShadowTrade_RearmSec` | 60 | Yeniden kurulum saniyesi |
| `ShadowTrade_WriteCSV` | `true` | Sonuçları CSV dosyasına yaz |

## 11.4 CSV Kaydı

```
ShadowTrade_WriteCSV = true ise:
→ MQL5/Files/ klasöründe CSV dosyası oluşur
→ Gerçek işlem yapmadan strateji performansı izlenir
```

## 11.5 Kullanım Senaryoları

```
✅ YENİ BİR STRATEJİYİ test etmek istiyorum ama gerçek para kaybetmek istemiyorum
   → ShadowTrade + ML_ShadowOnly = true
   
✅ ONNX modelimin performansını izlemek istiyorum
   → ShadowTrade + ML_ShadowOnly = true
   
✅ Farklı bir yön motorunu denemek istiyorum
   → ShadowTrade + yeni motor seçimi
   
✅ Riskli bir ayar kombinasyonunu önceden görmek istiyorum
   → ShadowTrade açık, gerçek işlem kapalı
```

---

# BÖLÜM 12 — RESET SİSTEMLERİ

## 12.1 Global Profit/Loss Reset

```
Input → MAIN TRADING
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `GlobalProfitPct` | 2.0 | Kâr reset yüzdesi (equity/bakiye değişimi) |
| `GlobalLossPct` | 2.0 | Zarar reset yüzdesi |
| `MaxResetCount` | 9999 | Maksimum reset sayısı |
| `WithdrawalNeutralForLossReset` | `true` → Para çekme işlemlerini reset'e dahil etmez |
| `AllowResetWhenPaused` | `true` → Robot duraklatılmışken bile reset çalışabilir |

## 12.2 Reset Sonrası Davranış

```
Input → TREND ENGINE → TPProjGlobalResetStart
→ TPP_GRESET_KEEP_PEAK_LOGIC (0) → Peak mantığını korur (varsayılan)
→ TPP_GRESET_FIXED_LOT         (1) → Sabit lot ile başlar
→ TPP_GRESET_PROJECTED_LOT     (2) → Projeksiyon lot ile başlar
```

```
Input → TREND ENGINE
→ TPProjAfterProfitReset → Reset sonrası kâr davranışı (varsayılan: KEEP_PEAK)
→ TPProjAfterLossReset   → Reset sonrası zarar davranışı (varsayılan: KEEP_PEAK)
```

## 12.3 Günlük Kâr/Zarar Kilidi

```
Input → DAILY PROFIT / LOSS LOCK
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `DailyProfitLockEnable` | `false` | Günlük kâr kilidini açar |
| `DailyProfitTargetPct` | 1.0 | Günlük kâr hedefi (%) |
| `DailyLossLockEnable` | `false` | Günlük zarar kilidini açar |
| `DailyLossTargetPct` | 1.0 | Günlük zarar limiti (%) |
| `DailyLockScope` | `DGS_ACCOUNT` | Kapsam: ACCOUNT / ROBOT |
| `DailyClockMode` | `DGC_BROKER` | Saat modu: BROKER / LOCAL |
| `DailyRestartHour` | 9 | Yeniden başlama saati |
| `DailyRestartMinute` | 30 | Yeniden başlama dakikası |

### Günlük Kilit Nasıl Çalışır:
```
1. Günlük kâr hedefine ulaşılır
2. Robot yeni girişleri KİTLER (kilitler)
3. Mevcut pozisyonlar açık kalır
4. Belirlenen saatte robot otomatik başlar
```

## 12.4 Zaman Bazlı Kapanış

```
Input → TIME-BASED RESET
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `EnableForcedReset` | `false` | Zorla reset (çevrim süresi çok uzarsa) |
| `ForcedResetHours` | 24 | Zorla reset saati |
| `EnableTimeLimitReset` | `false` | Zaman limit reseti |
| `TimeLimitMinutes` | 60 | Pozisyon yaşam limiti (dakika) |
| `TimeResetAction` | `TR_CLOSE_ALL` | Limit sonrası eylem |
| `PauseAfterTimeLimit` | `true` → Limit sonrası duraklatma |

### TimeResetAction Seçenekleri:
```
→ TR_CLOSE_ALL    (0) → Tümünü kapat
→ TR_CLOSE_PROFIT (1) → Sadece kârlıları kapat
→ TR_CLOSE_LOSS   (2) → Sadece zararlıları kapat
```

## 12.5 Auto Cost Limits (Maliyet Otomasyonu)

```
Input → AUTO COST LIMITS
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `EnableAutoSpread` | `true` | Otomatik spread kontrolü |
| `AutoSpreadSpikePct` | 30.0 | Spread ani yükseliş yüzdesi |
| `AutoSlippagePct` | 50.0 | Slippage tolerans yüzdesi |

## 12.6 Reset Sayacı ve Lot Kesme İlişkisi

```
Reset sayısı arttıkça lot kademeli olarak KESİLİR:

Reset 0-100   → Lot %100
Reset 101-200 → Lot %90 (10% kesme)
Reset 201-300 → Lot %80 (20% kesme)
Reset 301-400 → Lot %70 (30% kesme)
...
Minimum Lot → %30 (LotPenaltyMinPct = 30.0)
```

---

# BÖLÜM 13 — ÇOKLU GRAFİK VE PERFORMANS

## 13.1 Aynı Robotu Birden Fazla Grafikte Kullanma

### MagicChartSuffix Kullanımı:

```
Her grafikte benzersiz bir suffix atayın:
Grafik 1 (EURUSD): MagicChartSuffix = "" (boş, varsayılan)
Grafik 2 (GBPUSD): MagicChartSuffix = "2"
Grafik 3 (USDJPY): MagicChartSuffix = "3"
```

```
⚠️ Aynı suffix'i iki grafikte kullanmak POZİSYON ve PANEL
   HAFIZASINI KARIŞTIRIR.
```

## 13.2 Performans Optimizasyonu

```
Input → CPU / LATENCY OPTIMIZATION
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `CPU_Optimization` | `true` | CPU optimizasyonunu açar |
| `CPU_SignalRefreshMs` | 120 | Sinyal yenileme aralığı (ms) |

```
⚠️ CPU_SignalRefreshMs ÇOK KÜÇÜK ayarlanırsa:
   → Panel ve tick hesapları SIKLAŞIR
   → CPU yükü ARTAR
   
⚠️ CPU_SignalRefreshMs ÇOK BÜYÜK ayarlanırsa:
   → Tepki GEÇİKEBİLİR
   → Fırsatlar KAÇIRILABILIR
```

## 13.3 DOM (Depth of Market) Kullanımı

```
Input → DOM / DEPTH OF MARKET
```
| Input | Varsayılan | Açıklama |
|---|---|---|
| `DOM_Enable` | `false` | DOM kullanımı (broker desteği gerektirir) |
| `DOM_TopLevels` | 5 | Gösterilecek seviye sayısı |
| `DOM_FreshMs` | 1500 | Yenileme aralığı (ms) |
| `DOM_Weight` | 0.35 | DOM'un karar ağırlığı |

```
⚠️ DOM_Enable = true yaparsanız ama broker Market Book DESTEKLEMİYORSA:
   → Beklenen katkı ALINAMAZ
   → Gereksiz CPU yükü oluşur
   → Sadece ihtiyaçta açın
```

## 13.4 Çoklu Grafik İşlem Sırası

```
1. VPS'te MT5'i kurun
2. Her sembol için ayrı grafik açın
3. Her grafiğe robota benzersiz MagicChartSuffix verin
4. Her robotun ayarlarını sembole göre ayarlayın
5. Master panel olarak bir grafik seçin
6. Diğerlerini Slave olarak çalıştırın
```

---

# BÖLÜM 14 — SORUN GİDERME

## 14.1 Robot İşlem Açmıyor

```
Kontrol Listesi:
✅ Tools → Options → Expert Advisors → Allow automated trading → AÇIK
✅ EnableGlobalTrading = true
✅ EnableBuy = true veya EnableSell = true
✅ Spread çok yüksek mi? (MaxAllowedSpread kontrol)
✅ Haber kilidi var mı? (NF_Enable ve haber zamanı)
✅ Haftalık saat filtresi kapalı mı? (EnableWeeklySchedule)
✅ Günlük kâr/zarar kilidi çalıştı mı?
✅ VIOP seansı dışında mı?
✅ MagicChartSuffix benzersiz mi?
```

## 14.2 Panelde Değer Değişiyor Gibi Ama Geri Dönüyor

```
Sebep: Panel Global Variables hafızası eski değeri geri basıyor

Çözüm:
1. MagicChartSuffix değiştirin ("1", "2", vb.)
2. Global Variables'ı temizleyin (View → Global Variables → Delete All)
3. Grafiği kapatıp yeniden açın
4. Robotu grafikten çıkarıp yeniden ekleyin
```

## 14.3 Grid Çok Sık İşlem Açıyor

```
Kontrol Listesi:
✅ VG_StepValue değerini ARTIRIN (200 → 300 → 500)
✅ VG_BuyStepValue ve VG_SellStepValue ayrı ayrı kontrol
✅ Spread çok düşük mü? (artificial trigger riski)
✅ MinDist_Points değerini kontrol edin
✅ VG_RangeSamples değerini artırın
```

## 14.4 TP-PROJ Lot Beklenenden Büyük

```
Kontrol Listesi:
✅ TP hedefi çok büyük mü?
✅ Peak modu ve mevcut zarar açığı kontrol
✅ Hacim rejimi: SOLVER veya NET_VOLUME_TARGET daha güvenli
✅ Mevcut aynı yön lot kapsamını kontrol edin
✅ Bullet_FreezeTPProjLotOnLossStreak açık mı?
```

## 14.5 Haber Sırasında İşlem Devam Ediyor

```
Kontrol Listesi:
✅ NF_Enable = true mi?
✅ NF_PauseTrading = true mi?
✅ NF_HedgeBeforeNews veya NF_CloseAllBeforeNews ayarlarını kontrol edin
✅ Haber para birimi filtrelemesini kontrol edin
✅ MT5 Economic Calendar güncel mi?
```

## 14.6 Netting Hesapta Hedge Açılmıyor

```
Sebep: Netting hesap doğası gereği hedge fonksiyonları SINIRLIDIR

Çözüm:
1. Netting hesapta hedge fonksiyonları KAPALI veya BLOCK_NEW davranışına döner
2. Hedge için HEDGING hesap açın
3. VG_NettingSingleSide = true olduğundan emin olun
```

---

# BÖLÜM 15 — AYAR SENARYOLARI

## 📋 SENARYO 1: Temkinli İlk Demo Test

```
HESAP TİPİ:     Hedging demo
LOT:            FixedLot = 0.01, VG_LotValue = 0.01
GRID STEP:      VG_StepValue = 300 (geniş başlangıç)
TREND LOT:      BulletLotMode = BLM_AUTO veya BLM_MANUEL
HABER:          NF_Enable = AÇIK, ama Hedge/Close All KAPALI
ML/ONNX:        ML_ONNX_Enable = KAPALI
SHADOW:         ShadowTrade_Enable = AÇIK (izleme için)
AUTO TUNE:      EnableBulletAutoTune = KAPALI
DRAWDOWN:       EnableAutoDDHedge = KAPALI
ZAMAN:          EnableWeeklySchedule = KAPALI
TEST SÜRESİ:    Minimum 2 hafta (farklı piyasa koşulları)
```

## 📋 SENARYO 2: Sadece Sanal Grid Testi

```
HESAP TİPİ:     Hedging demo (Netting'te VG_NettingSingleSide = true)
GRID:           VG_Enable = true, VG_TPAuthority = true
TREND:          Trend girişleri KAPALI veya motoru Grid odaklı test
LOT:            VG_LotMode = GLM_FIXED, VG_LotValue = 0.01
STEP:           VG_StepMode = GST_FIXED_POINTS, VG_StepValue = 300
TP:             VG_TPMode = GTP_SPREAD_MULT, VG_TPValue = 2.0
HABER:          NF_Enable = AÇIK
TREND ADAPTİF:  VG_TrendAdaptiveDirection = true
PYRAMID:        VG_PyramidBuy = false, VG_PyramidSell = false
```

## 📋 SENARYO 3: Trend/TP-PROJ Ağırlıklı Test

```
HESAP TİPİ:     Hedging demo
LOT:            BulletLotMode = BLM_PROJECT
TP-PROJ:        TPProjVolumeRegime = TPP_REG_SOLVER
START MODE:     TPProjStartMode = TPP_START_PROJECTED_LOT
RESET:          TPProjAfterProfitReset = TPP_GRESET_KEEP_PEAK_LOGIC
RESET:          TPProjAfterLossReset = TPP_GRESET_KEEP_PEAK_LOGIC
KORUMA:         Bullet_RepeatLossGuardEnable = AÇIK
KORUMA:         Bullet_FreezeTPProjLotOnLossStreak = AÇIK
KONSENSÜS:      Bullet_TrendConsensusEnable = AÇIK, MinVotes = 2
ENTRY:          Bullet_EntryQualityEnable = AÇIK, MinScore = 40
```

## 📋 SENARYO 4: Agresif (Yüksek Risk — Sadece Deneyimliler İçin)

```
⚠️ Bu ayarlar yüksek risklidir. Sadece uzun demo test sonrası düşünülmelidir.

LOT:            Sabit lot 0.05+
GRID STEP:      VG_StepValue = 100 (sık grid)
HABER:          NF_Enable = AÇIK + NF_HedgeBeforeNews = AÇIK
ONNX:           ML_ONNX_Enable = AÇIK
TP-PROJ:        TPProjVolumeRegime = TPP_REG_TARGET_DEFICIT
PYRAMID:        VG_PyramidBuy = AÇIK, VG_PyramidSell = AÇIK
ESCAPE FUND:    VG_EscapeFundEnable = AÇIK
TIME LOT BOOST: EnableTimedLotBoost = AÇIK
VIOP:           VIOP_ForceCloseBeforeExpiry = AÇIK
```

## 📋 SENARYO 5: VIOP / Futures Trading

```
HESAP TİPİ:     Hedging (zorunlu)
SEMBOL:         6E, 6B, XU030, VI30 vb.
VIOP:           VIOP_DetectionMode = VIOP_DETECT_AUTO
SEANS:          VIOP_EnableSessionControl = true
SEANS:          VIOP_UseBrokerSessionTimes = true
SEANS:          VIOP_UseFixedTimesFallback = true
VIOP:           VIOP_Open_Hour = 9, VIOP_Open_Min = 20
VIOP:           VIOP_Close_Hour = 18, VIOP_Close_Min = 10
VADE:           VIOP_EnableExpiryProtection = true
VADE:           VIOP_BlockNewHoursBeforeExpiry = 48
VADE:           VIOP_ForceCloseBeforeExpiry = false (önce öner)
ROLLOVER:       VIOP_RolloverMode = VIOP_ROLLOVER_SUGGEST
GAP:            VIOP_GapWaitMinutes = 5
```

---

# BÖLÜM 16 — 372 INPUT KISA REFERANS

## 16.1 Tüm Ayar Grupları (42 Grup)

| # | Grup Adı | Input Sayısı |
|---|---|---|
| 1 | ASYMMETRIC EXPECTANCY GOVERNOR | 7 |
| 2 | AUTO COST LIMITS | 3 |
| 3 | AUTO TUNING | 11 |
| 4 | BASIC LOT SIZE | 3 |
| 5 | CLASSIC LIVE PHASE-ENERGY ENGINE | 10 |
| 6 | CPU / LATENCY OPTIMIZATION | 2 |
| 7 | DAILY PROFIT / LOSS LOCK | 8 |
| 8 | DIRECTION ENGINE SELECTOR | 10 |
| 9 | DIRECTION EXTRA CHECKS | 13 |
| 10 | DIRECTION SMART CHECK | 10 |
| 11 | DIRECTIONAL TRUTH META FILTER | 8 |
| 12 | DISPLAY | 2 |
| 13 | DOM / DEPTH OF MARKET | 4 |
| 14 | DRAWDOWN HEDGE | 5 |
| 15 | EARLY TREND CHECK | 10 |
| 16 | FINAL DIRECTION DECISION | 1 |
| 17 | FIRST TOUCH PROBABILITY ENGINE | 8 |
| 18 | **GRID ENGINE** | **38** |
| 19 | HYPERACTIVE EDGE GOVERNOR | 12 |
| 20 | LOT CUT AFTER RESETS | 3 |
| 21 | MAIN TRADING | 14 |
| 22 | ML / LIVE MARKET LEARNING | 12 |
| 23 | ML TRAINING DATA LOGGER | 7 |
| 24 | NEWS FILTER | 13 |
| 25 | NEXUS DIRECTION INTELLIGENCE | 3 |
| 26 | REOPEN RULE | 1 |
| 27 | RISK STYLE | 1 |
| 28 | SAME SIDE MIN DISTANCE | 4 |
| 29 | SHADOW TRADE JOURNAL | 6 |
| 30 | SOUND ALERTS | 6 |
| 31 | TIME LOT BOOST | 4 |
| 32 | TIME-BASED RESET | 6 |
| 33 | TRADE ID NUMBERS | 10 |
| 34 | TREND DETECTION CONSENSUS | 7 |
| 35 | TREND ENGINE | 28 |
| 36 | TREND OR RANGE CHECK | 16 |
| 37 | TREND SAME-DIRECTION LOSS SAFETY | 6 |
| 38 | TREND/RANGE DATA SOURCE | 6 |
| 39 | VEMA-X LIVE FLOW ARCHITECTURE | 3 |
| 40 | VIOP / FUTURES SAFETY | 17 |
| 41 | VIRTUAL TAKE PROFIT | 2 |
| 42 | WEEKLY TRADING HOURS | 32 |
| | **TOPLAM** | **372** |

## 16.2 En Önemli 50 Input (Mutlaka Bilinmesi Gerekenler)

| Öncelik | Input | Grup | Varsayılan | Açıklama |
|---|---|---|---|---|
| 🔴 KRİTİK | `EnableGlobalTrading` | MAIN | `true` | Robotun genel çalışma izni |
| 🔴 KRİTİK | `EnableBuy` | MAIN | `true` | BUY izni |
| 🔴 KRİTİK | `EnableSell` | MAIN | `true` | SELL izni |
| 🔴 KRİTİK | `FixedLot` | BASIC | `0.01` | Trend sabit lot |
| 🔴 KRİTİK | `VG_LotValue` | GRID | `0.01` | Grid sabit lot |
| 🔴 KRİTİK | `VG_StepValue` | GRID | `200.0` | Grid kademe mesafesi |
| 🔴 KRİTİK | `VG_TPValue` | GRID | `2.0` | Grid TP değeri |
| 🔴 KRİTİK | `GlobalProfitPct` | MAIN | `2.0` | Kâr reset yüzdesi |
| 🔴 KRİTİK | `GlobalLossPct` | MAIN | `2.0` | Zarar reset yüzdesi |
| 🔴 KRİTİK | `DirectionEngineDefault` | ENGINE | `VEMA` | Yön motoru seçimi |
| 🟠 ÖNEMLİ | `BulletLotMode` | TREND | `BLM_AUTO` | Lot hesaplama modu |
| 🟠 ÖNEMLİ | `TPProjVolumeRegime` | TREND | `SOLVER` | TP-PROJ hacim rejimi |
| 🟠 ÖNEMLİ | `VG_LotMode` | GRID | `GLM_FIXED` | Grid lot modu |
| 🟠 ÖNEMLİ | `VG_TPMode` | GRID | `SPREAD_MULT` | Grid TP modu |
| 🟠 ÖNEMLİ | `VG_Enable` | GRID | `true` | Grid aktif/pasif |
| 🟠 ÖNEMLİ | `Bullet_TrendConsensusEnable` | CONSENSUS | `true` | Trend konsensüs |
| 🟠 ÖNEMLİ | `Bullet_SameSideLossLimit` | LOSS SAFET | `3` | Aynı yön zarar limiti |
| 🟠 ÖNEMLİ | `NF_Enable` | NEWS | `false` | Haber filtresi |
| 🟠 ÖNEMLİ | `DailyProfitLockEnable` | DAILY | `false` | Günlük kâr kilidi |
| 🟠 ÖNEMLİ | `DailyLossLockEnable` | DAILY | `false` | Günlük zarar kilidi |
| 🟠 ÖNEMLİ | `PanelLanguage` | DISPLAY | `LANG_EN` | Panel dili |
| 🟠 ÖNEMLİ | `MagicChartSuffix` | TRADE ID | `""` | Grafik ayrım etiketi |
| 🟠 ÖNEMLİ | `MagicBuy` | TRADE ID | `2001` | BUY magic numarası |
| 🟠 ÖNEMLİ | `MagicSell` | TRADE ID | `2002` | SELL magic numarası |
| 🟡 FAYDALI | `ML_ONNX_Enable` | ML | `false` | ONNX kullanımı |
| 🟡 FAYDALI | `ShadowTrade_Enable` | SHADOW | `true` | Gölge işlem sistemi |
| 🟡 FAYDALI | `EnableAutoDDHedge` | DD HEDGE | `false` | Drawdown hedge |
| 🟡 FAYDALI | `EnableWeeklySchedule` | WEEKLY | `false` | Haftalık saat filtresi |
| 🟡 FAYDALI | `VIOP_EnableSessionControl` | VIOP | `true` | VIOP seans kontrolü |
| 🟡 FAYDALI | `VG_PyramidBuy` | GRID | `false` | BUY piramit |
| 🟡 FAYDALI | `VG_PyramidSell` | GRID | `false` | SELL piramit |
| 🟡 FAYDALI | `EnableBulletAutoTune` | AUTO TUNE | `false` | Otomatik ayar |
| 🟡 FAYDALI | `Bullet_ProfitLockEnable` | TREND | `true` | Kâr kilitleme |
| 🟡 FAYDALI | `Bullet_BonusTPEnable` | TREND | `true` | Bonus TP |
| 🟡 FAYDALI | `EnableAlternatingTP` | VIRTUAL TP | `true` | Alternatif TP |
| 🟡 FAYDALI | `DI_Enable` | DI | `true` | DI yön kontrolü |
| 🟡 FAYDALI | `TMI_Enable` | TMI | `true` | Erken trend kontrolü |
| 🟡 FAYDALI | `AWR_Enable` | AWR | `true` | Trend/Range ayrımı |
| 🟡 FAYDALI | `NDI_Enable` | NDI | `true` | NDI katmanı |
| 🟡 FAYDALI | `DTE_Enable` | DTE | `true` | Meta filter |
| 🟡 FAYDALI | `AEG_Enable` | AEG | `true` | Asimetrik beklenti |
| 🟡 FAYDALI | `HEG_Enable` | HEG | `true` | Edge governor |
| 🟡 FAYDALI | `DOM_Enable` | DOM | `false` | DOM kullanımı |
| 🟡 FAYDALI | `CPU_Optimization` | CPU | `true` | CPU optimizasyonu |
| 🟡 FAYDALI | `SoundAlertsEnabled` | SOUND | `true` | Sesli uyarılar |
| 🟡 FAYDALI | `Bullet_RepeatLossGuardEnable` | LOSS SAFET | `true` | Zarar güvenliği |
| 🟡 FAYDALI | `MinDist_Enable` | MIN DIST | `true` | Minimum mesafe |
| 🟡 FAYDALI | `AllowReopenNeutral` | REOPEN | `true` | Yeniden açma |
| 🟡 FAYDALI | `EnableAutoSpread` | AUTO COST | `true` | Otomatik spread |
| 🟡 FAYDALI | `LotPenaltyStepResets` | LOT CUT | `100` | Reset lot kesme |
| 🟡 FAYDALI | `InpPanelScale` | DISPLAY | `1.0` | Panel ölçeği |

---

# SON KONTROL LİSTESİ

## 🤖 Kurulum Öncesi

- [ ] MT5 platformu kuruldu
- [ ] Hedging demo hesap açıldı
- [ ] Hesap tipi (Hedging/Netting) kararı verildi
- [ ] İşlem yapılacak sembol belirlendi
- [ ] .ex5 dosyası MQL5/Experts klasörüne kopyalandı
- [ ] VPS hazır (uzun süreli kullanım için)

## ⚙️ İlk Çalıştırma

- [ ] Robot grafik üzerine eklendi
- [ ] Journal'da başlatma mesajları kontrol edildi
- [ ] Algo Trading izni verildi
- [ ] PanelLanguage = LANG_TR (Türkçe) ayarlandı
- [ ] EnableGlobalTrading = true
- [ ] EnableBuy = true, EnableSell = true
- [ ] FixedLot = 0.01, VG_LotValue = 0.01

## 🛡️ Koruma Ayarları

- [ ] SpreadProtection ve MaxAllowedSpread ayarlandı
- [ ] MinDist_Enable açık ve uygun mesafe var
- [ ] Bullet_RepeatLossGuardEnable açık
- [ ] Bullet_SameSideLossLimit = 3 (varsayılan uygun)
- [ ] Bullet_FreezeTPProjLotOnLossStreak açık
- [ ] GlobalProfitPct ve GlobalLossPct belirlendi
- [ ] DailyProfitLock ve DailyLossLock ayarlandı

## 📰 Haber ve Zaman

- [ ] NF_Enable açılacak mı karar verildi
- [ ] NF_MinutesBefore/After ayarlandı
- [ ] NF_CurrencyFilter ayarlandı
- [ ] EnableWeeklySchedule açılacak mı karar verildi
- [ ] Haftalık saatler ayarlandı

## 🤖 VIOP (Futures Kullanacaksanız)

- [ ] VIOP_DetectionMode ayarlandı
- [ ] VIOP seans saatleri doğru
- [ ] VIOP_EnableExpiryProtection açık
- [ ] VIOP_RolloverMode belirlendi

## 🧠 ML/ONNX (Kullanacaksanız)

- [ ] ONNX model dosyası MQL5/Files klasöründe
- [ ] ML_FeatureCount ve ML_OutputCount modele uygun
- [ ] ML_ShadowOnly = true ile ön test yapıldı
- [ ] ML_DataLog_Enable = true (veri toplama)
- [ ] ShadowTrade_Enable = true (izleme)

## 📊 Grid Ayarları

- [ ] VG_Enable açık/kapalı kararı
- [ ] VG_LotMode ve VG_LotValue belirlendi
- [ ] VG_StepMode ve VG_StepValue belirlendi
- [ ] VG_TPMode ve VG_TPValue belirlendi
- [ ] VG_TPAuthority açık
- [ ] VG_NettingSingleSide (Netting hesap için) ayarlandı
- [ ] VG_PyramidBuy/Sell (ileri düzey) kararı

## 🔄 Test Süreci

- [ ] Strategy Tester'da ilk test tamamlandı
- [ ] Demo hesapta minimum 2 hafta test edildi
- [ ] Farklı piyasa koşullarında test (haberli gün, yatay gün, trend günü)
- [ ] Shadow trade sonuçları izlendi
- [ ] Küçük sabit lot ile gerçek hesap öncesi test

## 📱 Panel ve Performans

- [ ] Panel ölçeği uygun ayarlandı
- [ ] MagicChartSuffix benzersiz (çoklu grafik için)
- [ ] CPU_Optimization açık
- [ ] DOM_Enable sadece gerekirse açık
- [ ] Ses dosyaları yerinde (opsiyonel)

## ✅ Gerçek Hesap Geçiş

- [ ] Tüm demo testler tamamlandı
- [ ] Küçük sabit lot ile başlanacak
- [ ] Tek sembol ile başlanacak
- [ ] Günlük K/Z takip edilecek
- [ ] Haftalık performans değerlendirmesi yapılacak
- [ ] Ayarları birer birer değiştirip sonuç izlenecek

---

## 📞 Son Söz

```
Robotun en güçlü güvenlik aracı:

✅ Doğru lot
✅ Doğru STEP  
✅ Doğru hesap tipi
✅ Doğru saat/haber filtresi
✅ Gerçek broker koşullarında yapılan test

KURAL: Bir ayarı değiştirdikten sonra
sonucunu görmeden ikinci ayarı değiştirmeyin.
```

---

*Bu rehber, Algotrade Nexus Pro 7.35 Güncel Kullanım Kılavuzu'ndan (09.07.2026) derlenmiştir.*  
*Robot versiyonu: 7.35 | Build: REAL ARCHITECTURE R21 | Toplam Input: 372 | Ayar Grubu: 42*
